define('constant',[],function(){return{BGM_ALIAS:"bgm",SE_ALIAS:"se",VOICE_ALIAS:"voice",VOICE_STAMP_ALIAS:"StampVoice_",VOICE_ENEMY_ALIAS:"enemy_voice",MAX_NUM_LOAD_VOICE_STAMP:10,SE_SAMPLE_ALIAS:"sample",VOICE_SAMPLE_ALIAS:"sample",SE_ENHANCE_SUCCESS:"se/success_s_se_1.mp3",SE_ENHANCE_SUCCESS_HIGH:"se/success_l_se_1.mp3",SE_ENHANCE_LEVEL_UP:"se/levelup_arm_se_1.mp3",SE_ENHANCE_GAUGE:"se/gauge_se_1.mp3",SE_ENHANCE_GAUGE_OFFSET:140,SE_ENHANCE_GAUGE_FREQUENCY:3,EVENT_ANIMATION_START:"animationstart webkitAnimationStart",EVENT_ANIMATION_END:"animationend webkitAnimationEnd",SE_NEXT_SCENE:"se/serif_se_1.mp3",EVENT_TYPE:{TREASURERAID:1,LIMITED:2,TEAMRAID:3,DUNGEON:4,ADVENT:5,BIOGRAPHY:6,SKY:7,MINI:8,ARCARUM:9,DEFENDORDER:10,SOLOTREASURE:11,SEASON:12,REVIVAL:13,SEQUENCERAID:14,TOWER:15,TEAMFORCE:16,INTERLUDE:17}}});
define('lib/sound-util',[],function(){var e=null;function r(){if(e)return e;var r,n=document.createElement("audio");return n.canPlayType&&((r={}).mp3=!!n.canPlayType("audio/mpeg;").replace(/no/,""),r.ogg=!!n.canPlayType('audio/ogg; codecs="vorbis"').replace(/no/,""),r.wav=!!n.canPlayType('audio/wav; codecs="1"').replace(/no/,""),r.aac=!!n.canPlayType('audio/mp4; codecs="mp4a.40.2"').replace(/no/,"")),n=null,e=r,r}return{getAudioCapabilities:r,isSupportedHTMLAudio:function(){return!!r()},isSupportedWebAudio:function(){return window.webkitAudioContext||window.mozAudioContext||window.AudioContext},findMediaType:function(e){switch(e){case"mp3":return"audio/mpeg";case"ogg":return"audio/ogg";case"wav":return"audio/wav";case"aac":case"m4a":return"audio/mp4";default:return""}},readLAMEHeader:function(e){var r={},n=new Uint8Array(e),a=0;function o(e){return n.subarray(a,a+=e)}if(73===n[0]&&68===n[1]&&51===n[2]){r.id3v2=!0,a+=5;for(var t=n[a++],i=0,u=0;u<4;u++)i<<=7,i|=n[a++];a+=i,64&t&&(a+=10)}r.frameHeaderOffset=a;var c=o(4);if(255!==c[0]||(224&c[1])!=224)return r;var d=(24&c[1])>>3,f=function(e,r,n){var a=0;if(3===e?3===r?a=[0,32,64,96,128,160,192,224,256,288,320,352,384,416,448][n]:2===r?a=[0,32,48,56,64,80,96,112,128,160,192,224,256,320,384][n]:1===r&&(a=[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320][n]):(2===e||0===e)&&(3===r?a=[0,32,48,56,64,80,96,112,128,144,160,176,192,224,256][n]:(2===r||1===r)&&(a=[0,8,16,24,32,40,48,56,64,80,96,112,128,144,160][n])),!a)throw Error("unknown bit-rate");return a}(d,(6&c[1])>>1,(240&c[2])>>4),p=function(e,r){var n=0;if(3===e?n=[44100,48e3,32e3][r]:2===e?n=[22050,24e3,16e3][r]:0===e&&(n=[11025,12e3,8e3][r]),!n)throw Error("unknown sample-rate");return n}(d,(12&c[2])>>2),l=function(e,r){var n=0;if(!(n=3===e?3===r?21:36:3===r?13:21))throw Error("unknown info-offset");return n}(d,(192&c[3])>>6);a+=l-4,r.bitRate=f,r.sampleRate=p;var w=o(4);if(!(88===w[0]&&105===w[1]&&110===w[2]&&103===w[3]||73===w[0]&&110===w[1]&&102===w[2]&&111===w[3]))return r;a+=115,a+=22;var s=o(3),v=s[0]<<4|(240&s[1])>>4,m=(15&s[1])<<8|s[2];return r.encoderDelay=v,r.padding=m,r}}});
define('esm',{load(e,r,d){if("undefined"==typeof window)try{d()}catch(e){d.error(e)}else window.dynamicImport(e).then(e=>d(e)).catch(e=>d.error(e))}});

define('lib/shellapp',["esm!lib/shellapp.esm.js"],e=>{let{default:l}=e;return l});
define('util/event',["underscore"],function(e){var t={};return t.on=t.addEventListener=function(e,t){this._eventListeners=this._eventListeners||{},this._eventListeners[e]=this._eventListeners[e]||[],this._eventListeners[e].push(t)},t.removeEventListener=function(t,n){n._once&&this.removeEventListener(t,n._once),this._eventListeners&&(this._eventListeners[t]&&(this._eventListeners[t]=e.reject(this._eventListeners[t],function(e){return!n||e===n||e===n._once})),e.isEmpty(this._eventListeners[t])&&delete this._eventListeners[t],e.isEmpty(this._eventListeners)&&(this._eventListeners=null,delete this._eventListeners))},t.removeAllEventListeners=function(t){var n=this;n._eventListeners&&(t?e.each(n._eventListeners[t],function(e){n.removeEventListener(t,e)}):e.each(n._eventListeners,function(e,t){n.removeAllEventListeners(t)}))},t.off=function(e,t){t?this.removeEventListener(e,t):this.removeAllEventListeners(e)},t.hasEventListener=function(t,n){return!!this._eventListeners&&!!e.find(this._eventListeners[t],function(e){return!n||e===n})},t.once=function(e,t){var n=this;t._once=function(){n.removeEventListener(e,t._once),t.apply(n,arguments)},n.addEventListener(e,t._once)},t.trigger=function(t){var n=this;n._eventListeners&&e.each(n._eventListeners[t],function(e){e.call(n)})},t});
define('util/function',["jquery"],function(e){return{returnTrue:function(){return!0},returnFalse:function(){return!1},returnEmptyObject:function(){return{}},returnResolvedPromise:function(){return new e.Deferred().resolve().promise()},returnRejectedPromise:function(){return new e.Deferred().reject().promise()}}});
define('lib/sound-player',["jquery","underscore","lib/sound-util","lib/shellapp","util/event","util/function"],function(e,n,t,i,o,s){var r,u,a,l="silent",c=/^\^?bgm/,d=/^\^?se/,f=/^\^?voice/,m=window.Game.ua&&"Android"===window.Game.ua.os.name,p=Game.ua.hasModelName(/SH-04H|KYT33/i)||Game.useShellAppWebAudio,_=window.Game.ua&&"iOS"===window.Game.ua.os.name,y=_&&Game.ua.versionCompare(Game.ua.os.version,"13.4")>=0,v={};(function(){this.ready=s.returnFalse,this.destroy=s.returnFalse,this.getInstances=s.returnEmptyObject,this.load=s.returnRejectedPromise,this.play=s.returnRejectedPromise,this.repeat=s.returnRejectedPromise,this.stop=s.returnFalse,this.isPlaying=s.returnFalse,this.setPlaying=s.returnFalse,this.mute=s.returnFalse,this.unmute=s.returnFalse,this.setVolume=s.returnFalse,this.replay=s.returnFalse,this.once=s.returnFalse,this.requiresUserAction=s.returnFalse,this.reset=s.returnFalse,this.createContext=s.returnFalse,this.destroyContext=s.returnFalse,this.getState=s.returnFalse}).call(v);var h=n.clone(v),g=function(i){i._instances={},i._loadedSources={},i._bindingCallbackList={};var o=new e.Deferred;return i._setup?o.resolve():(i._setup=!0,function(r){if(r.HTMLAudioPlugin.MAX_INSTANCES=4,r.Sound.initializeDefaultPlugins()){var u=new r.LoadQueue(!1);u.installPlugin(r.Sound),u.setMaxConnections(5),i.ready=function(){return r.Sound.isReady()},i.destroy=function(e){i._instances[e]&&(delete i._instances[e],r.Sound.removeSound(e)),i._loadedSources[e]&&delete i._loadedSources[e]},i.getInstances=function(){return i._instances},i.load=function(n,t){if((t=t||{}).src)o=t.src;else{var o;o=(t.dir?t.dir+"/":"")+(t.file||n)}if(i._loadedSources[n]===o)return new e.Deferred().resolve().promise();var s=new e.Deferred,a=function(e){e.item.id===n&&e.item.src===o&&(c(),i._loadedSources[n]=o,s.resolve())},l=function(e){e.item.id===n&&e.item.src===o&&(c(),delete i._loadedSources[n],s.reject())},c=function(){u.removeEventListener("fileload",a),u.removeEventListener("error",l)};u.addEventListener("fileload",a),u.addEventListener("error",l);var d=u._numItems;return u.loadFile({id:n,src:o,type:r.LoadQueue.SOUND,cache:!0}),d==u._numItems&&(c(),delete i._loadedSources[n],s.reject()),s.promise()},i.play=function(e,t){return i.load(e,t).done(function(){var o=i._instances[e]=i._instances[e]||r.Sound.createInstance(e),s=t.interrupt||r.Sound.INTERRUPT_NONE;n.each(i._bindingCallbackList[e],function(n,t){i.once(e,t,function(){n(o)})}),delete i._bindingCallbackList[e];var u=t.delay||0,a=t.offset||0,l=n.isNumber(t.loop)?t.loop:t.loop?-1:0,c=t.volume;o.play(s,u,a,l,c)})},i.repeat=function(e,n){return i.load(e,n).done(function(){var t=i._instances[e]=i._instances[e]||r.Sound.createInstance(e);if(t){var o=n.interrupt||r.Sound.INTERRUPT_NONE,s=n.delay||0,u=n.offset||0,a=n.volume;t.play(o,s,u,-1,a)}})},i.stop=function(e){var n=i._instances[e];n&&n.stop()},i.isPlaying=function(e){var n=i._instances[e];return n&&n.playState===r.Sound.PLAY_SUCCEEDED},i.mute=function(e,n){var t=i._instances[e];t&&t.setMute(!0)},i.unmute=function(e,n){var t=i._instances[e];t&&t.setMute(!1)},i.setVolume=function(e,t,o){if(!n.isUndefined(t)){var s=i._instances[e];s&&s.setVolume(t)}},i.pause=function(e){var n=i._instances[e];n&&n.pause()},i.resume=function(e){var n=i._instances[e];n&&n.resume()},i.duration=function(e){var n,t;let o=null!==(n=i._instances[e])&&void 0!==n?n:i._loadedSources[e]&&r.Sound.createInstance(e);if(o)return 1e3*(null===(t=Object.values(Object.values(o).find(e=>e)).find(e=>e&&"object"==typeof e&&e.duration))||void 0===t?void 0:t.duration)},i.position=function(e){var n=i._instances[e];if(n)return 1==window.Game.setting.cjs_mode?new Date().getTime()-window.sTime:n.getPosition()},i.replay=function(e){var n=i._instances[e];n&&(0!=n._remainingLoops?n.play(r.Sound.INTERRUPT_NONE,0,0,-1):n.play())},i.once=function(e,n,t){var o=i._instances[e];o?(t._once=function(){o.removeEventListener(n,t._once),t.apply(o,arguments)},o.addEventListener(n,t._once)):(i._bindingCallbackList[e]=i._bindingCallbackList[e]||{},i._bindingCallbackList[e][n]=function(i){t.apply(i,[e,n,t])})},i.reset=function(){r.Sound.reset(!0),i._instances={},i._loadedSources={},i._bindingCallbackList={},u=null},i.createContext=function(){r.WebAudioPlugin.playEmptySound()},i.destroyContext=function(){r.WebAudioPlugin.reset()},i.getState=function(){return r.WebAudioPlugin.getState()},i.requiresUserAction=s.returnFalse,t.isSupportedWebAudio()?(r.WebAudioPlugin.playEmptySound(),setTimeout(function(){(null==r.WebAudioPlugin.context||0===r.WebAudioPlugin.context.currentTime)&&(i.requiresUserAction=s.returnTrue,r.Sound.activePlugin instanceof r.WebAudioPlugin&&window.addEventListener("touchstart",function e(){null!=r.WebAudioPlugin.context&&(window.removeEventListener("touchstart",e,!0),r.WebAudioPlugin.playEmptySound())},!0)),o.resolve()},100)):o.resolve()}}(window.createjs)),o.promise()},S=function(n){var t=new e.Deferred;n.ready=s.returnTrue,n.setup=s.returnResolvedPromise,n.load;var o=n.play,r=n.repeat,u=n.stop,a=n.pause,l=n.resume,p=n.setVolume,y=n.isPlaying,v=n.setPlaying;if(m){var h={};n.isPlaying=function(e){return e.match(c)?h.bgm:e.match(d)?h.se:e.match(f)?h.voice:void y.call(n,e)},n.setPlaying=function(e,t){e.match(c)?h.bgm=t:e.match(d)?h.se=t:e.match(f)?h.voice=t:v.call(n,e,t)},n.load=function(n,t){return n.match(f)&&i.loadVoice(n),new e.Deferred().resolve().promise()},n.play=function(t,s){var r=function(){return h.se=!0,i.playSoundEffect(t),new e.Deferred().resolve().promise()};return"se"===s.alias&&t.match(f)?r():t.match(c)?(h.bgm=!0,i.playMusic(t),new e.Deferred().resolve().promise()):t.match(d)?r():t.match(f)?(h.voice=!0,i.playVoice(t,s&&s.force),new e.Deferred().resolve().promise()):(i.pauseMusic(),o.call(n,t,s).done(function(){n.once(t,"complete",function(){i.resumeMusic()})}))},n.repeat=function(t,o){return t.match(c)?(h.bgm=!0,i.playMusic(t,0,-1),new e.Deferred().resolve().promise()):t.match(d)?(h.se=!0,i.playSoundEffect(t),new e.Deferred().resolve().promise()):t.match(f)?(h.voice=!0,i.playVoice(t,o&&o.force),new e.Deferred().resolve().promise()):(i.pauseMusic(),r.call(n,t,o).done(function(){n.once(t,"complete",function(){i.resumeMusic()})}))},n.stop=function(e,t){e.match(c)?(h.bgm=!1,i.stopMusic()):e.match(d)?h.se=!1:e.match(f)?(h.voice=!1,i.stopVoice()):(i.resumeMusic(),u.call(n,e,t))},n.pause=function(e,t){e.match(c)?(h.bgm=!1,i.pauseMusic()):e.match(d)?h.se=!1:e.match(f)?(h.voice=!1,i.pauseVoice()):(i.resumeMusic(),a.call(n,e,t))},n.resume=function(e,t){e.match(c)?(h.bgm=!1,i.resumeMusic()):e.match(d)?h.se=!1:e.match(f)?(h.voice=!1,i.resumeVoice()):(i.pauseMusic(),l.call(n,e,t))},n.setVolume=function(e,t){e.match(c)?i.setMusicVolume(t):e.match(d)?i.setSEVolume(t):e.match(f)?i.setVoiceVolume(t):p.call(n,e,t)}}else _&&(n.setVolume=function(e,t){e.match(c)?i.setMusicVolume(t):e.match(d)?i.setSEVolume(t):e.match(f)&&i.setVoiceVolume(t),p.call(n,e,t)});return t.promise()};(function(){this.setup=n.partial(g,this)}).call(h),!p&&(m||_)&&(i.isShellApp()?(r=h.setup,h.setup=function(){return r.call(h).always(n.partial(S,h))}):i.setOnShellAppReady(function(){var e;e=h.setup,h.setup=function(){return e.call(h).always(n.partial(S,h))}}));var b={};return n.extend(b,o),(function(){var o=this;o._directory={},o._alias={},o._masterVolume=1,o._localVolume={},o._disabled={},o._muted={},o._sounds={},o._reservedSounds={},o._errorSounds={},o._destroyTimer={},o._isPlayed={},o._isSkipped={},o._destroy=function(e){h.destroy(e),clearTimeout(o._destroyTimer[e]),delete o._destroyTimer[e],delete o._sounds[e],delete o._reservedSounds[e],delete o._errorSounds[e],delete o._isPlayed[e]},o._registerDestroy=function(e){clearTimeout(o._destroyTimer[e]),o._destroyTimer[e]=setTimeout(function(){o._destroy(e)},5e3)},o._unregisterDestroy=function(e){clearTimeout(o._destroyTimer[e]),delete o._destroyTimer[e]},o._each=function(e,t){n.each(h.getInstances(),function(n,i){i.match(e)&&t(i,n)})},o._isPlayable=function(e){return!(!e||e==l||o.isDisabled(e))},o._handleComplete=function(){o.isLoaded()&&o.trigger("complete")},o._loadAndCall=function(t,s){(s=s||{}).dir=s.dir||o.getDirectory(t);var r=new e.Deferred;if(!i.isShellApp()){if(n.has(o._sounds,t))return r.resolve().promise();if(n.has(o._errorSounds,t))return r.reject().promise()}return o.load(t,s)},o._setGain=function(e,n){h.setVolume(e,o.getLocalVolume(e),n),o.isMuted(e)?h.mute(e,n):h.unmute(e,n)},o.isSupportedHTMLAudio=function(){return t.isSupportedHTMLAudio()},o.isSupportedWebAudio=function(){return t.isSupportedWebAudio()},o.isSupportedNativeAudio=function(){return m&&i.isShellApp()&&!Game.useShellAppWebAudio},o.isSupported=function(){return o.isSupportedHTMLAudio()||o.isSupportedWebAudio()||o.isSupportedNativeAudio()},o.setup=function(t){var i=new e.Deferred;return o._setup?i.resolve():(o._setup=!0,h.setup().done(function(){h.requiresUserAction()&&(t?n.each(h.getInstances(),function(e,n){o.isPlayed(n)&&h.replay(n)}):window.addEventListener("touchstart",function e(){window.removeEventListener("touchstart",e,!0),n.each(h.getInstances(),function(e,n){o.isPlayed(n)&&h.replay(n)})},!0)),i.resolve()}).fail(function(){i.reject()})),i.promise()},o.destroy=function(e){e=o._alias[e]||e||"",o._each(e,function(e,n){h.stop(e),o._destroy(e)}),h.stop(e)},o.registerDestroy=function(e){e=o._alias[e]||e||"",o._each(e,function(e,n){h.stop(e),o._registerDestroy(e)}),h.stop(e)},o.unregisterDestroy=function(e){e=o._alias[e]||e||"",o._each(e,function(e){o._unregisterDestroy(e)})},o.setDirectory=function(e,n){n||(n=e,e=""),e=o._alias[e]||e||"",o._directory[e]=n,o.destroy(e)},o.getDirectory=function(e){e=o._alias[e]||e||"";var t=n.find(n.keys(o._directory),function(n){return e.match(n)});return o._directory[t]||""},o.enable=function(e){e=o._alias[e]||e||"",delete o._disabled[e],o.unregisterDestroy(e),i.isShellApp()&&(o.isEnabled("bgm/")&&i.setMusicMute(0),o.isEnabled("se/")&&i.setSEMute(0),o.isEnabled("voice/")&&i.setVoiceMute(0))},o.disable=function(e){e=o._alias[e]||e||"",o._disabled[e]=!0,o.registerDestroy(e),i.isShellApp()&&(e?e.match(c)?i.setMusicMute(1):e.match(d)?i.setSEMute(1):e.match(f)&&i.setVoiceMute(1):i.setMute(1))},o.isEnabled=function(e){return!o.isDisabled(e)},o.isDisabled=function(e){return e=o._alias[e]||e||"",n.some(o._disabled,function(n,t){return e.match(t)&&n})},o.skip=function(e){e=o._alias[e]||e||"",o._isSkipped[e]=!0},o.unskip=function(e){e=o._alias[e]||e||"",delete o._isSkipped[e]},o.isSkipped=function(e){return e=o._alias[e]||e||"",n.some(o._isSkipped,function(n,t){return e.match(t)&&n})},o.isMuted=function(e){return e=o._alias[e]||e||"",n.some(o._muted,function(n,t){return e.match(t)&&n})},o.mute=function(e){e=o._alias[e]||e||"",o._muted[e]=!0,o._each(e,function(e,n){h.mute(e)}),h.mute(e)},o.unmute=function(e){e=o._alias[e]||e||"",delete o._muted[e],delete o._muted[""],o._each(e,function(e,n){h.unmute(e)}),h.unmute(e)},o.getVolume=function(e){e=o._alias[e]||e||"";var n=o.getMasterVolume();return e?n*o.getLocalVolume(e):n},o.setVolume=function(e,t){n.isUndefined(t)?(t=e,o.setMasterVolume(t)):o.setLocalVolume(e,t)},o.getMasterVolume=function(){return o._masterVolume},o.setMasterVolume=function(e){n.isUndefined(e)||(o._masterVolume=e)},o.getLocalVolume=function(e){e=o._alias[e]||e||"";var t=n.find(n.keys(o._localVolume),function(n){return e.match(n)});return t?o._localVolume[t]:1},o.setLocalVolume=function(e,t){n.isUndefined(t)||(e=o._alias[e]||e||"",o._localVolume[e]=t,o._each(e,function(e,n){h.setVolume(e,t)}),h.setVolume(e,t))},o.hasAlias=function(e){return n.has(o._alias,e)},o.getPlayingId=function(e){return o.isPlaying(e)?o._alias[e]:""},o.setAlias=function(e,n){o._alias[n]=e},o.unsetAlias=function(e){o._alias[e]=null,delete o._alias[e]},o.setAliasAndPlay=function(e,n,t){o._isPlayable(e)||o.stop(n);var i=o._alias[n];e&&(o.setAlias(e,n),i==e&&e.match(d)?o.play(n,t):o.stopAndPlay(i,e,t))},o.setAliasAndRepeat=function(e,n,t){o._isPlayable(e)||o.stop(n);var i=o._alias[n];e&&(o.setAlias(e,n),i!=e?o.stopAndRepeat(i,e,t):o.isPlaying(n)||o.repeat(n,t))},o.isPlayed=function(e){return(e=o._alias[e]||e||"")&&o._isPlayed[e]},o.isPlaying=function(e){return(e=o._alias[e]||e||"")&&o._sounds[e]&&h.isPlaying(e)},o.setPlaying=function(e,n){return(e=o._alias[e]||e||"")&&h.setPlaying(e,n)},o.load=function(n,t){return o.isSkipped(n)||!t.force&&!o._isPlayable(n)||o._reservedSounds[n]||o._sounds[n]||o._errorSounds[n]?new e.Deferred().resolve().promise():(o._reservedSounds[n]=n,h.load(n,t).done(function(){o._sounds[n]=n,delete o._reservedSounds[n],delete o._errorSounds[n],t.ignoreComplete||o._handleComplete()}).fail(function(){o._errorSounds[n]=n,delete o._reservedSounds[n],t.ignoreComplete||o._handleComplete()}))},n.each(["play","repeat"],function(e){o[e]=function(n,t){if(t=t||{},n=o._alias[n]||n||"",!o.isSkipped(n)&&(t.force||o._isPlayable(n)))return null==t.volume&&(t.volume=o.getLocalVolume(n)),o._isPlayed[n]=!0,o._loadAndCall(n,t).done(function(){o._isPlayed[n]&&h[e](n,t).done(function(){o._setGain(n,t)})})}}),n.each(["stop"],function(e){o[e]=function(n,t){n=o._alias[n]||n||"",o._isPlayed[n]=!1,h[e](n,t)}}),o.resume=function(e,n){if(n=n||{},e=o._alias[e]||e||""){if(o.isSkipped(e)||!n.force&&!o._isPlayable(e))return;return null==n.volume&&(n.volume=o.getLocalVolume(e)),o._isPlayed[e]=!0,o._loadAndCall(e,n).done(function(){o._isPlayed[e]&&(h.resume(e,n),o._setGain(e,n))})}o._each("",function(e){e&&o._isPlayed[e]&&o.resume(e,n)})},o.pause=function(e,n){(e=o._alias[e]||e||"")?h.pause(e,n):o._each("",function(e){e&&o.pause(e)})},o.duration=function(e){return h.duration(e)},o.position=function(e){return h.position(e)},o.stopAndPlay=function(e,n,t){if(e=o._alias[e]||e||"",n=o._alias[n]||n||"",t=t||{},!o.isSkipped(n)){if(t.force||o._isPlayable(n))return o._isPlayed[e]=!1,o._isPlayed[n]=!0,o._loadAndCall(n,t).always(function(){e!==n&&o._isPlayed[e]||h.stop(e,t)}).done(function(){o._isPlayed[n]&&(null==t.volume&&(t.volume=o.getLocalVolume(n)),h.play(n,t).done(function(){o._setGain(n,t)}))});o.stop(e,t)}},o.stopAndRepeat=function(e,n,t){if(e=o._alias[e]||e||"",n=o._alias[n]||n||"",t=t||{},!o.isSkipped(n)){if(t.force||o._isPlayable(n))return o._isPlayed[e]=!1,o._isPlayed[n]=!0,o._loadAndCall(n,t).always(function(){e===n&&o._isPlayed[e]||h.stop(e,t)}).done(function(){o._isPlayed[n]&&(null==t.volume&&(t.volume=o.getLocalVolume(n)),h.repeat(n,t).done(function(){o._setGain(n,t)}))});o.stop(e,t)}},o.loadManifest=function(t,s){if(!h.ready())return o.trigger("complete"),new e.Deferred().reject();s=s||{};var r=n.filter(t,function(e){var n=s.force||!o.isDisabled(e.id),t=i.isShellApp()||!o._sounds[e.id]&&!o._reservedSounds[e.id];return e.id&&e.src&&t&&n});return n.isEmpty(r)?(o._handleComplete(),new e.Deferred().resolve().promise()):e.when.apply(null,t.map(function(n){var t=e.Deferred();return s.dir=s.dir||o.getDirectory(n.id),s.ignoreComplete=!0,o.load(n.id,Object.assign(s,n)).always(t.resolve),t})).then(function(){o._handleComplete()})},o.getPath=function(e){var n=o.getDirectory(e);return(n?n+"/":"")+e},o.prefetch=function(e){return e.map(function(e){return new Promise(function(n,t){var i=new XMLHttpRequest;i.addEventListener("error",t),i.addEventListener("load",n),i.open("GET",o.getPath(e),!0)})})},o.loadFile=function(e,n){return o.loadFiles([e],n)},o.loadFiles=function(e,t){var i=n.map(n.uniq(n.filter(e,function(e){return e&&e!==l})),function(e){return{id:e,src:o.getPath(e)}});return o.loadManifest(i,t)},o.isLoaded=function(e){return(e=o._alias[e]||e||"")?n.has(o._sounds,e)||!o._isPlayable(e):n.isEmpty(n.difference(n.keys(o._reservedSounds),n.keys(o._sounds)))},o.clearInstances=function(e){var t=(e=e||{}).exclude||"";n.each(h.getInstances(),function(e,n){h.isPlaying(n)||t&&n.match(t)||o._destroy(n)})},o.once=function(e,n,t){return h.once(e,n,t)},o.reset=function(){h.reset()},o.createContext=function(){return h.createContext()},o.destroyContext=function(){return h.destroyContext()},o.getState=function(){return h.getState()},o.destroySoundExceptForInfiniteLoop=function(){n.each(h.getInstances(),function(e,n){var t=h.isPlaying(n),i=-1===e._remainingLoops;t&&!i&&o.destroy(n)})}}).call(b),b.isSupportedWebAudio()||b.setup(!1),document.hidden?(u="hidden",a="visibilitychange"):document.mozHidden?(u="mozHidden",a="mozvisibilitychange"):document.msHidden?(u="msHidden",a="msvisibilitychange"):document.webkitHidden&&(u="webkitHidden",a="webkitvisibilitychange"),u&&a&&document.addEventListener(a,function(){document[u]?b.mute():b.unmute()}),(Game.ua.isIOS()||Game.ua.isIPad())&&Game.ua.versionCompare(Game.ua.getOSVersion(),"15")>=0?(window.addEventListener("visibilitychange",function(){"visible"===document.visibilityState?(b.createContext(),b.resume(),b.unmute()):(b.mute(),b.destroySoundExceptForInfiniteLoop(),b.destroyContext())}),window.addEventListener("beforeunload",function(){b.mute(),b.destroyContext()})):(window.addEventListener("blur",function(){1!=+Game.setting.is_enable_pc_inactive_sound_play&&b.mute()}),n.each(["pagehide","beforeunload"],function(e){window.addEventListener(e,function(){b.mute()})}),n.each(["focus","pageshow"],function(e){window.addEventListener(e,function(){b.unmute()})})),window.addEventListener("unload",function(){y?b.reset():b.mute()}),b});
define('lib/sound',["jquery","underscore","lib/sound-player"],function(n,e,d){var o,r={};function a(n){e.each(d,function(e,d){r[d]=function(){return n[d].apply(n,arguments)}})}return window!==window.parent?window.parent.SoundPlayer?window.parent.readySoundPlayer?a(window.parent.SoundPlayer):(window.parent.loadingSoundPlayer=window.parent.loadingSoundPlayer||new n.Deferred,o=window.parent.pendingSoundPlayer=[],e.each(d,function(n,e){r[e]=function(){o.push([e,arguments])}}),window.parent.loadingSoundPlayer.done(function(){var n;a(window.parent.SoundPlayer),n=window.parent.pendingSoundPlayer,e.each(n,function(n){var e=n[0],d=n[1];r[e].apply(r,d)}),delete window.parent.pendingSoundPlayer})):a(d):(a(d),(window.loadingSoundPlayer=window.loadingSoundPlayer||new n.Deferred).resolve(),window.readySoundPlayer=!0),r});
define('util/navigate',["underscore","backbone"],function(e,n){function r(e){return/=/.test(e)?e.split("&").reduce(function(e,n){var r=n.split("=");return e[o(r[0])]=(""+r[1]).replace(/!/g,"/"),e},{}):null}function t(e){var n=[];for(var r in e)n.push(a(r)+"="+(""+e[r]).replace(/\//g,"!").replace(/#/g,""));return n.join("&")}function o(e){return e.replace(/_[a-z]/g,function(e){return e.toUpperCase().slice(1)})}function a(e){return e.replace(/[a-z][A-Z]/g,function(e){return e[0]+"_"+e[1].toLowerCase()})}var i=function(e,r){var t=window.location;r.refresh?(n.history.stop(),t.hash=e,t.reload()):n.History.started?("object"!=typeof(r=r||{})||"trigger"in r||(r.trigger=!0),n.history.navigate(e,r)):t.hash=e},c=function(e,r){var t=window.location;r.refresh?(n.history.stop(),t.href=e,t.reload()):t.href=e},u=function(e){if(window.Game&&window.Game.ajaxConnecting){var n=$(document);n.on("ajaxStop",function r(){n.off("ajaxStop",r),e()})}else e()};return{parseHashParam:r,serializeHashParam:t,extendHashParam:function(n,o){return e.compose(t,function(n){return e.extend(n,o)},r)(n)},hash:function(n,r){r=r||{};var t=e.partial(i,n,r);r.sync?u(t):t()},href:function(n,r){r=r||{};var t=e.partial(c,n,r);r.sync?u(t):t()},sync:u,hashParam:{parse:function(e){let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"!";return/=/.test(e)?e.split("&").reduce((e,r)=>{let[t,...a]=r.split("=");return a.length&&(e[o(t)]=String(a.join("=")).split(n).join("/")),e},{}):null},serialize:function(e){let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"!";return Object.entries(e).map(e=>{let[r,t]=e,o=a(r),i=String(t).replace(/\//g,n).replace(/#/g,"");return"".concat(o,"=").concat(encodeURIComponent(encodeURIComponent(i)))}).join("&")}}}});
define('util/ajax',["underscore"],function(t){let e=JSON.parse(document.getElementById("server-props").textContent);var n,i=function(){function t(t){this.ajaxLimits={},this.startNum=t.length-1}return t.prototype.add=function(t){this.check(t)||(this.ajaxLimits[t]=1)},t.prototype.remove=function(t){this.check(t)&&(this.ajaxLimits[t]=0)},t.prototype.check=function(t){return 1===this.ajaxLimits[t]},t.prototype.getRequestString=function(t){var e=t.indexOf("?");return e<0&&(e=t.length),t.substring(this.startNum,e)},new t(e.baseUri)}(),o=function(){this.initialize.apply(this,arguments)};(n=o.prototype).initialize=function(){return this._pool={},this._index=0,this},n.add=function(t){var e=this._pool,n=this._index++;t._index=n,e[n]=t,i.add(t._requestKey)},n.remove=function(t){t?(i.remove(t._requestKey),delete this._pool[t._index]):this._pool={}},n.abort=function(e){e?(e._isManuallyAborted=!0,e.abort(),this.remove(e)):(t.each(this._pool,function(t){i.remove(t._requestKey),t._isManuallyAborted=!0,t.abort()}),this.remove())};var r=function(){return new o},s=r();return{createXHRPool:r,addXHR:function(t){s.add(t)},removeXHR:function(t){s.remove(t)},abortXHR:function(t){s.abort(t)},isManuallyAbortedXHR:function(t){return t._isManuallyAborted&&"abort"===t.statusText},controlXHR:function(t,e){return t._requestKey=i.getRequestString(e),i.check(t._requestKey)}}});
define('util/local-storage',["underscore"],function(e){var t,n,r=window.localStorage,u={},o=function(){};(u.isSupported=function(){if(!r)return!1;try{if(r.setItem("_","_"),!r.getItem("_"))return!1;return r.removeItem("_"),!0}catch(e){return!1}},u.isSupported())?(u.get=u.getItem=function(e){return r.getItem(e)},u.remove=u.removeItem=function(e){return r.removeItem(e),this},u.set=u.setItem=function(e,t){try{return r.setItem(e,t),!0}catch(e){return e.code,!1}},u.clear=function(){return r.clear(),!0},u.getObject=function(e){return JSON.parse(u.get(e))},u.setObject=function(e,t){return u.set(e,JSON.stringify(t))},u.each=function(e){for(var t=0,n=r.length;t<n;t++){var u=r.key(t),o=r.getItem(u);e.call(this,o,u)}},u.map=function(e){for(var t=[],n=0,u=r.length;n<u;n++){var o=r.key(n),c=r.getItem(o),i=e.call(this,c,o);t.push(i)}return t}):e.each(["get","remove","set","clear","getObject","setObject","each","map"],function(e){u[e]=function(){return o(),!1}});var c=0;u.maxBytes=function(t){return e.isUndefined(t)?c:c=Number(t)};var i="default";u.namespace=function(e){return i=e},u.contentKey=function(e){return i+"."+e},u.checksumKey=function(e){return i+"-checksum."+e},u.countKey=function(e){return i+"-count."+e},u.timeKey=function(e){return i+"-time."+e},u.isContentKey=function(e){return 0==e.indexOf(i+".")},u.originalKeyOfContent=function(e){return e.slice(i.length+1)};var m=function(){var t=u.map(function(e,t){return t});return e.filter(t,function(e){return u.isContentKey(e)})},f=function(e,t){var n,r,o,c,i,m=0;for(n=0,o=e.length;n<o&&m<t;n++)c=e[n],m+=u.get(c).length;if(m<t)return!1;for(r=0;r<n;r++)c=e[r],i=u.originalKeyOfContent(c),u.removeContent(i),u.removeChecksum(i),u.removeTime(i),u.removeCount(i);return!0};return e.each(["get","set","remove"],function(e){u[e+"Checksum"]=function(t,n){return u[e](u.checksumKey(t),n)},u[e+"Time"]=function(t,n){return u[e](u.timeKey(t),n)},u[e+"Count"]=function(t,n){return u[e](u.countKey(t),n)}}),u.getContent=function(e){return u.updateTime(e),u.updateCount(e),n(u.get(u.contentKey(e)))},u.hasContent=function(e){return!!u.get(u.contentKey(e))},u.setContent=function(n,r){var o,i=r.length;if(c&&c<i)return!1;u.updateTime(n),u.updateCount(n);var a=t(r);return!!u.set(u.contentKey(n),a)||((o=i,f(e.sortBy(m(),function(e){var t=u.originalKeyOfContent(e);return Number(u.getCount(t))}),o))?u.set(u.contentKey(n),a):(u.removeContent(n),!1))},u.removeContent=function(e){return u.removeChecksum(e),u.removeTime(e),u.removeCount(e),u.remove(u.contentKey(e))},u.updateTime=u.updateAccessTime=function(e){return u.setTime(e,new Date().getTime())},u.updateCount=u.updateAccessCount=function(e){var t=Number(u.getCount(e))||0;return u.setCount(e,t+1)},u.verifyChecksum=function(e,t){return u.hasContent(e)?u.getChecksum(e)==t:(u.removeChecksum(e),u.removeTime(e),u.removeCount(e),!1)},u.clearExpired=function(t){var n=m();if(!e.isEmpty(n)){var r=e.map(n,function(e){return u.originalKeyOfContent(e)}),o=e.sortBy(r,function(e){return u.getTime(e)})[0];u.getTime(o)<t&&u.clear()}},u});

define('util/language-message',["esm!util/language-message.esm.js"],e=>{let{default:s}=e;return s});
define('util/language-message-submenu',["util/language-message"],function(e){var s={list:null};return{setMessage:function(e){_.isNull(s.list)?s.list=e:_.isNull(e)||_.extend(s.list,e)},getMessage:function(e,l){void 0===l&&(l=1);var a="ja"==Game.lang||1==l?"msg":"msgs";return s.list[e][a]||""},clearMessage:function(){s.list=null},replaceMessage:function(e,s,l){void 0===l&&(l=1);var a=this.getMessage(e,l);return _.each(s,function(e,s){a=a.replace(_.isNumber(s)?"%s":s,e)}),a=a.replace(/\\n/g,"\n")},pluralMessage:e.pluralMessage,numberToAlphabet:e.numberToAlphabet}});
define('lib/mobage-jssdk',["jquery","underscore"],function(e,n){var t=!1,o=!1,r=null,i=null,s=null,u=null,a={},c={};function f(t,o,r,i){var s=window.Game,u=new e.Deferred;function a(e){var a=("0000"+n.random(1,99999)).slice(-5),c="t="+new Date().getTime()+"&uid="+s.userId+"&code="+a;t+=(t.indexOf("?")>=0?"&":"?")+c;var f=new XMLHttpRequest;if(f.open("POST",t),f.setRequestHeader("Content-Type","application/json;charset=UTF-8"),s.shellAppFlag&&(f.setRequestHeader("X-MOBAGE-SHELLAPP",1),e)){var l=e.getVersionName(),d=Number(e.getVersionCode());"1.0"===l&&d&&d>0&&(l+=".0."+d),f.setRequestHeader("X-MOBAGE-SHELLAPP-VERSION",l)}f.setRequestHeader("X-VERSION",s.version),f.onreadystatechange=function(){if(4===f.readyState){if(200<=f.status&&f.status<300){var e=f.response;u.resolve(e),r&&r(e)}else{var n,o=f.statusText;u.reject(o),n="[JSSDK] response status "+f.status+(" error Type "+(0===f.status?"F":"B"))+" random code "+a,s.reportError(n,t,null,null,null,function(){i&&i(f,o,a)})}f.onreadystatechange=Function()}},f.send(JSON.stringify(o))}return s.shellAppFlag?require(["lib/shellapp"],function(e){a(e)}):a(),u.promise()}function l(e){"null"!==e&&require(["util/navigate"],function(n){var t=0===e.indexOf("#")?e:"#top";n.hash(t,{refresh:!0})})}var d=c.callAfterReady=function(e){e&&(o?e():document.addEventListener("mobageReady",function(){o=!0,e()}))};c.requireOnceJSSDKClient=function(e){if(e&&!t){t=!0;var n=document.createElement("script");n.type="text/javascript",n.async=!0,n.src=e,document.getElementsByTagName("script")[0].parentNode.appendChild(n)}},c.mobageInit=function(e){if(!e)return null;d(function(){if(r!==e.clientId||i!==e.redirectUri){r=e.clientId,i=e.redirectUri;try{window.mobage.init(e)}catch(e){r=null,i=null}}})},c.mobageGetConnectedStatus=function(n,t,o){var r=new e.Deferred;return d(function(){window.mobage.oauth.getConnectedStatus(n,function(e,n){n?(r.resolve(n),t&&t(n)):(r.reject(e),o&&o(e))})}),r.promise()};var g=c.mobageConnect=function(t,o,r){var i=new e.Deferred;return t=n.defaults(t,{customTheme:"grbl",appearanceVersion:"1"}),d(function(){window.mobage.oauth.connect(t,function(e,n){e?(i.reject(e),r&&r(e)):(i.resolve(n),o&&o(n))})}),i.promise()},p=c.login=function(e,t,o,r){var s=window.Game,u=t&&t.response||{},a={code:u.code,state:u.state,session_state:u.session_state},c=e&&e.redirectUri||i;return n.isUndefined(o)&&(o=l),n.isUndefined(r)&&(r=function(e,n,t){s.view?s.view.trigger("data_error",[e.status,t]):alert(s.message.connectionError)}),f(c,a,o,r)},m=c.tryLogin=function(t,o,r,i){n.isUndefined(r)&&(r=l);var s=new e.Deferred;return p(t,o,function(e){"#authentication/failed_empty"===e||"#authentication/failed_exist"===e?(s.reject(),i&&i()):(s.resolve(),r&&r(e))},function(e,n,t){s.reject(),i&&i()}),s.promise()};c.singleLogin=function(n,t,o){var r=new e.Deferred;return g(n,function(e){p(n,e,t,o).done(function(e){r.resolve(e)}).fail(function(e){r.reject(e)}).always(function(){var n=e&&e.response&&e.response.session_state;n&&h(n)})},function(e){r.reject(e)}),r.promise()};var v=c.trySingleLogin=function(n,t,o){var r=new e.Deferred;return g(n,function(e){m(n,e,t,o).done(function(e){r.resolve(e)}).fail(function(e){r.reject(e)}).always(function(){var n=e&&e.response&&e.response.session_state;n&&h(n)})},function(e){r.reject(e)}),r.promise()},w=c.mobageLogout=function(n,t,o){y().done(function(){var r=new e.Deferred;return d(function(){window.mobage.oauth.logout(n,function(e,n){e?(r.reject(e),o&&o(e)):(r.resolve(n),t&&t(n))})}),r.promise()})},b=c.logout=function(e,t,o){y().done(function(){return n.isUndefined(t)&&(t=l),n.isUndefined(o)&&(o=null),f("logout",e,t,o)})};c.singleLogout=function(n,t,o){var r=new e.Deferred;return w(n,function(e){b(n,t,o).done(function(e){r.resolve(e)}).fail(function(e){r.reject(e)})},function(e){r.reject(e)}),r.promise()},c.mobageSubscribeLogin=function(e,t){n.isUndefined(t)&&(t=function(n){v({state:e})}),d(function(){if(s!==e){s=e;var n="oauth.loginRequired",o=a[n];o&&window.mobage.event.unsubscribe(o),a[n]=window.mobage.event.subscribe(n,function(){t&&t(n)})}})};var h=c.mobageSubscribeLogout=function(e,t){n.isUndefined(t)&&(t=function(n){b({platform:"mobage",session_state:e})}),d(function(){if(u!==e){u=e;var n="oauth.sessionStateChange",o=a[n];o&&window.mobage.event.unsubscribe(o),a[n]=window.mobage.event.subscribe(n,e,function(e){"changed"===e&&t&&t(n)})}})},y=c.checkAbilityToLogout=function(){var n=e.Deferred();if(!Game.ua.isMbga())return n.resolve().promise();function t(e){e.get("result")?n.resolve():(requireESM(["view/popup","util/language-message"],function(e,n){new e({className:"pop-cannot-logout",title:n.getMessage("logout_error_01"),body:n.getMessage("logout_error_02"),flagBtnClose:1,flagBtnOk:0}).render().popShow()}),n.reject())}return require(["model/token-data"],function(e){var n=new(e.extend({urlRoot:Game.baseUri+"logout/logout_check"}));n.stopListening(n,"sync"),n.listenToOnce(n,"sync",t),n.fetch()}),n.promise()};return c});
define('model/data',["underscore","backbone","util/ajax","lib/shellapp","util/local-storage","util/language-message","util/language-message-submenu","lib/mobage-jssdk"],function(e,t,r,o,a,i,s,n){var l=[],u=!1;return t.Model.extend({initialize:function(){this.listenTo(this,"error",this.error),this.error=this.getErrorStorageValue()},parse:function(r){if(r){var a=r.local_notification;o.isShellApp()&&!e.isEmpty(a)&&o.setLocalNotification(a);var g=r.redirect;g&&e.isString(g)&&(Game.view.stopListening(this),0===r.redirect.indexOf("#")?window.location.hash=g.slice(1):window.location.href=g,r.refresh&&(t.history.stop(),window.location.reload()));var c=r.auth_status,d=window.clientData;if("require_auth"===c){if(Game.ua.isMbga()){if(d&&d.state){var h=e.clone(d.state);l.push(r),n.mobageGetConnectedStatus({state:h}).done(function(t){d.state=r.state,t.response.state=d.state,n.login(d,t,function(){l.shift(),e.isEmpty(l)&&window.location.reload()})}).fail(function(e){window.location.reload()})}}else Game.ua.isGreeLogin()?u||(u=!0,GREE.oauth.getConnectedStatus(function(e,r){if(e){var o;u=!1,(o=new(t.Model.extend({urlRoot:Game.baseUri+"authentication/greejs"}))).set({id_token:e.id_token}),o.save(null,{success:function(){window.location.reload()},error:function(){location.href=Game.baseUri+"#error"}})}r&&window.location.reload()})):Game.ua.isDMM()?u||(u=!0,new(t.Model.extend({urlRoot:Game.baseUri+"authentication/dmm_already_logged_game_login"}))().save(null,{success:function(){window.location.reload()},error:function(){location.href=Game.baseUri+"#error"}})):window.location.hash="#top"}!1===e.isUndefined(Game.treasure)&&!1===e.isUndefined(r.display_list)&&Game.treasure.updateList(r.display_list);var p=r.popup;if(!e.isEmpty(p))return Game.view.trigger("loadEnd"),Game.view.trigger("popup_error",{data:p}),Game.view.stopListening(this),this.off(),{errorPopFlag:!0,isCapthcaPop:"pop-c-a-i"===p.element_name};var m=r.option;if(m){var f=m.adjust_conversions;o.isShellApp()&&!e.isEmpty(f)&&e.each(f,function(e){o.sendAdjustEvent(e.cvpoint)})}m&&!e.isEmpty(m.langMsg)&&(m.submenu_view?s.setMessage(m.langMsg):i.setMessage(m.langMsg))}return r},error:function(t,o,i){if(!r.isManuallyAbortedXHR(o)&&(404===o.status&&null===o.getResponseHeader("Content-Length")&&(o.status=0),409!=o.status&&410!=o.status)){var s=("0000"+e.random(1,99999)).slice(-5),n="[DataModel] response status "+o.status,l=0===o.status?"F":"B";i.ignoreError?Game.reportError(n,t.url()||i.url):0===this.error&&a.isSupported()?(Game.reportError(n+this.getXHRErrorMsg(l,"POPUP",s),t.url()||i.url),Game.view.trigger("data_error",[o.status,s]),this.setErrorStorageValue(1)):(Game.reportError(n+this.getXHRErrorMsg(l,"PAGE",s),t.url()||i.url),Game.view.trigger("page_error"),this.removeErrorStorageValue())}},sync:function(e,r,o){return(o=o||{}).cache=o.cache||!1,t.Model.prototype.sync.apply(this,arguments)},setErrorStorageValue:function(e){var t=this.getStorageKey();a.set("model_error_hash",t),a.set(t,e)},getErrorStorageValue:function(){return a.get(this.getStorageKey())||0},removeErrorStorageValue:function(){a.remove("model_error_hash"),a.remove(this.getStorageKey())},getStorageKey:function(){return location.hash+"_model_error"},getXHRErrorMsg:function(e,t,r){return" error Type "+e+"-"+t+" random code "+r}})});
define('model/token-data',["jquery","underscore","backbone","model/data","util/ajax"],function(e,t,n,i,r){return i.extend({defaults:function(){return{special_token:null}},initialize:function(){i.prototype.initialize.apply(this)},setToken:function(){this.set(this.security.attributes),this.set({special_token:Math.floor(1e4*Math.random())})},save:function(n,r,s){null==n||"object"==typeof n?(u=n,s=r):(u={})[n]=r,(s=s||{}).url=s.url||this.url(),s.url=s.url+"?_="+new Date().getTime();var u,a=t.bind(i.prototype.save,this,u,s);if(!this._cflExists())return a();var c=this;this.func=a;var o=this.saveDeferred=new e.Deferred,f=this.saveDeferred.promise();return f.abort=function(){delete c.func,o.reject(),o=null,f.abort=function(){}},this.security=new(i.extend({urlRoot:Game.baseUri+"security/csrf"})),this.listenToOnce(this,"change:special_token",this._check),this.listenToOnce(this.security,"change",this.setToken),this.security.fetch(),f},_check:function(){var e=this;if(void 0==this.func);else{var t=this.func();t.done(function(){e.saveDeferred.resolve(e)}).fail(function(){e.saveDeferred.reject()}),e.saveDeferred.fail(function(){r.abortXHR(t)}).always(function(){e.saveDeferred=null})}},_cflExists:function(){var e=this._getSegment(this.url());return!!Function("return "+t.unescape(Game.cfl))()[e]},_getSegment:function(e){var t=Game.baseUri.length-1,n=e.indexOf("?");return n<0&&(n=e.length),e.substring(t,n).replace(/(\/$|.json)/,"")}})});
define('setting',["jquery","underscore","lib/sound","util/navigate","model/token-data"],function(e,n,t,i,o){var r=window.Game=window.Game||{},u=window.CanvasRenderingContext2D;if(u){var s=u.prototype.drawImage;s&&(u.prototype.drawImage=function(e,t,i,o,r,u,d,a,c){if(n.isUndefined(a)&&n.isUndefined(c))try{return s.apply(this,arguments)}catch(e){}else{var l=t+o<e.width?o:e.width-t,f=i+r<e.height?r:e.height-i;try{return s.call(this,e,t,i,l,f,u,d,a,c)}catch(e){}}})}var d=function(e,n,t){var i=e.split("/");return i.slice(0,3).join("/")+"/"+i.slice(3).join("/").replace(n,t)},a=function(n,i){var o=new e.Deferred,u=r.setting,s=u.sound_flag=Number(n),d=s&&(u.bgm_mode||u.se_mode||u.voice_mode);return(0==+u.effect_mode||0==+d)&&(s=u.sound_flag=0),s?e.when(t.setup(i)).then(function(){t.enable()}).then(function(){o.resolve()}):e.when(t.disable()).done(function(){o.resolve()}),o},c=function(n,i){var o=new e.Deferred;switch(r.setting[n.replace(/(\/$)|(\^)/g,"")+"_mode"]=Number(i)){case 0:e.when(t.setDirectory(n,d(r.soundUri,/sound[^\/]*/,"sound")),t.disable(n)).done(function(){o.resolve()});break;case 2:e.when(t.setDirectory(n,d(r.soundUri,/sound[^\/]*/,"sound")),t.enable(n)).done(function(){o.resolve()})}return o},l=function(e){return 0!=r.setting.effect_mode&&(t.isSupportedWebAudio()||t.isSupportedNativeAudio())||(e=0),c("^bgm/",e)},f=function(e){return 0!=r.setting.effect_mode&&(t.isSupportedWebAudio()||t.isSupportedNativeAudio())||(e=0),c("^se/",e)},g=function(e){return 0!=r.setting.effect_mode&&(t.isSupportedWebAudio()||t.isSupportedNativeAudio())||(e=0),c("^voice/",e)},m=function(e,n){return r.setting[e.replace(/\/$/,"")+"_volume"]=n,t.setLocalVolume(e,n/100)},v=function(e){m("bgm/",e)},p=function(e){m("se/",e)},b=function(e){m("voice/",e)};return{initialize:function(n){var t=new e.Deferred;return e.when(l(r.setting.bgm_mode),f(r.setting.se_mode),g(r.setting.voice_mode),v(r.setting.bgm_volume),p(r.setting.se_volume),b(r.setting.voice_volume),a(r.setting.sound_flag)).done(function(){t.resolve()}),t},enableSound:a,enableBGM:l,enableSE:f,enableVoice:g,setBGMVolume:v,setSEVolume:p,setVoiceVolume:b,saveSetting:function(e){n.extend(r.setting,e);var t=new(o.extend({urlRoot:r.baseUri+"setting/save"}));return t.set(e,{silent:!0}),t.save()}}});
define('util/backbone-singleton',["underscore","backbone"],function(n,t){var e=function(t,e){return e=e||n.reject(n.keys(t.prototype),function(n){return"_"==n[0]}),t.prototype.constructor=function(){return t._instance?t._instance:(t._instance=this,t.prototype.constructor.apply(this,arguments))},t.getInstance=function(){return this._instance=this._instance||new t,this._instance},n.each(e,function(n){t[n]=function(){var e=t.getInstance();return e[n].apply(e,arguments)}}),t};return t.Model.makeSingleton=function(n){e(this,n)},{makeSingleton:e}});
define('model/data-loader',["jquery","underscore","backbone","util/backbone-singleton"],function(e,r,c){var n={},s=c.Model.extend({clear:function(e){e?r.has(n,e)&&delete n[e]:n={}},load:function(c,s){var o=this;if(s=s||{},(s=r.defaults(s,{cache:!0})).cache&&r.has(n,c))return s.success&&s.success.call(o,n[c]),o.trigger("complete"),new e.Deferred().resolve().promise();var a=new e.Deferred;return e.ajax({url:Game.baseUri+c,cache:!1,success:function(e){s.success&&s.success.apply(o,arguments),s.cache&&(n[c]=e),a.resolve(),o.trigger("complete")},error:function(){s.error&&s.error.apply(o,arguments),a.reject()}}),a.promise()}});return s.makeSingleton(["load","clear","on","off","once"]),s});
define('lib/get-adjust-zoom-value',[],function(){let n={MAX:150,MIN:67},e=JSON.parse(document.getElementById("server-props").textContent);return function(t){if(e.isShellApp)return t;let i=window.screen||{},r=Math.round(i.width/i.height*100);return 67>Math.round(window.innerWidth/window.innerHeight*100)||r>n.MAX||r<n.MIN?t:t*(.67*window.innerHeight/window.innerWidth)}});
define('lib/device-detector-lite',[],function(){return{isIOS:function(){return/ios/.test(navigator.userAgent.toLowerCase())},isAndroid:function(){return navigator.userAgentData?"android"===navigator.userAgentData.platform.toLowerCase():/android/.test(navigator.userAgent.toLowerCase())},isSteamApp:function(){return/gbf-steam-app/i.test(navigator.userAgent)}}});
define('lib/get-device-ratio',["lib/get-adjust-zoom-value","lib/device-detector-lite"],function(e,i){return function(){let n=JSON.parse(document.getElementById("server-props").textContent),t=i.isIOS(),o=i.isAndroid(),d=n.isSteamApp;var r=window.innerWidth/320;if(t&&!n.isShellApp)r=1;else if(d)r=window.innerWidth/1136;else if(n.isPcPlatform){if(0===n.forceWindowSize){if(n.isLoggedIn){var s=n.pcSidebarWidth;r=(window.outerWidth-s-33)/704}else r=window.innerWidth/704;r<=1?r=1:r>2&&(r=2)}else r=n.forceWindowSize}else if(n.isAndApp){if(n.isTutorialFinish){var l=window.localStorage&&JSON.parse(window.localStorage.getItem("gbf_pcsbm"));r=l&&!0==l.is_open?window.innerWidth/704:window.innerWidth/384}else r=window.innerWidth/320}else if(o)return e(r);return r}});
define('model/sound',["jquery","underscore","backbone","constant","lib/sound","model/data","model/data-loader","util/local-storage"],function(e,t,n,a,s,i,o,u){var l="silent",r="se/btn_se/btn_se_03.mp3",p=[{se:l,classes:["prt-silent-se","btn-silent-se","btn-help-topic-title","btn-command-forward"]},{se:"se/queststart_se_1.mp3",classes:["se-quest-start"]},{se:"se/target_se_1.mp3",classes:["btn-targeting"]},{se:"se/book_open_se_1.mp3",classes:["btn-story"]},{se:"se/stamp_se_1.mp3",classes:["btn-stamp-ok"]},{se:"se/btn_se/btn_se_02.mp3",classes:["btn-usual-cancel","btn-usual-text-cancel","btn-usual-cancel-small","btn-usual-close","btn-head-close","btn-deck-cancel","btn-cancel","btn-close","btn-help-close","btn-command-back","btn-log","btn-ability-unavailable","btn-summon-unavailable","btn-tutorial-disable","btn-play uncleared"]},{se:"se/menu_open_se_1.mp3",classes:["btn-head-pop","btn-open"]},{se:"se/menu_close_se_1.mp3",classes:["btn-head-close"]},{se:"se/btn_se/btn_se_04.mp3",classes:["se-start","btn-result","btn-start","btn-tutorial-start"]},{se:"se/btn_se/btn_se_05.mp3",classes:["btn-attack-start"]},{se:"se/btn_se/btn_se_01.mp3",classes:["se-ok","btn-select-balloon","btn-usual-ok"]},{se:r,classes:["btn-shine","btn-ability-available","btn-summon-available","btn-archive-item","btn-treasure-item"]}],c=[{se:"se/sell_se_1.mp3",classes:["pop-sell-result"]}];let _="specified-se";var d=n.Model.extend({loadSound:function(e,t){return t=t||{},s.loadFile(e,t)},loadBGM:function(e,t){return(t=t||{}).alias=t.alias||a.BGM_ALIAS,this.loadSound(e,t)},loadSE:function(e,t){return(t=t||{}).alias=t.alias||a.SE_ALIAS,this.loadSound(e,t)},loadVoice:function(e,t){return(t=t||{}).alias=t.alias||a.VOICE_ALIAS,this.loadSound(e,t)},playSound:function(e,n){var a;(n=n||{}).force&&s.setup(!0),n.alias?(a=n.loop?s.setAliasAndRepeat:s.setAliasAndPlay,a=t.partial(a,e,n.alias,n)):(a=n.loop?s.repeat:s.play,a=t.partial(a,e,n)),n.force?s.setup(!0).done(a):a()},playBGM:function(e,t){return(t=t||{}).alias=t.alias||a.BGM_ALIAS,t.loop=!0,t.force&&(t.force=!1,delete t.force),this.playSound(e,t)},playSE:function(e,t){return(t=t||{}).alias=t.alias||a.SE_ALIAS,this.playSound(e,t)},playVoice:function(e,t){return(t=t||{}).alias=t.alias||a.VOICE_ALIAS,this.playSound(e,t)},stopBGM:function(e){e?s.stop(e):s.stop(a.BGM_ALIAS)},stopSE:function(e){e?s.stop(e):(s.stop(a.SE_ALIAS),s.stop(a.SE_SAMPLE_ALIAS))},stopVoice:function(e){if(e)s.stop(e);else{s.stop(a.VOICE_ALIAS),s.stop(a.VOICE_SAMPLE_ALIAS);for(var t=0;t<a.MAX_NUM_LOAD_VOICE_STAMP;t++)s.stop(a.VOICE_STAMP_ALIAS+t)}},destroyBGM:function(e){e?s.destroy(e):s.destroy(a.BGM_ALIAS)},unsetBGM:function(e){s.unsetAlias(e||a.BGM_ALIAS)},unsetSE:function(e){s.unsetAlias(e||a.SE_ALIAS)},unsetVoice:function(e){s.unsetAlias(e||a.VOICE_ALIAS)},isPlayingBGM:function(e){return s.isPlaying(e||a.BGM_ALIAS)},isPlayingSE:function(e){return s.isPlaying(e||a.SE_ALIAS)},isPlayingVoice:function(e){return s.isPlaying(e||a.VOICE_ALIAS)},getPlayingBGM:function(){return s.getPlayingId(a.BGM_ALIAS)},setPlayingVoice:function(e){return s.setPlaying(a.VOICE_ALIAS,e)},skipVoice:function(){return s.skip("^voice/")},unskipVoice:function(){return s.unskip("^voice/")},skipSE:function(){return s.skip("^se/")},unskipSE:function(){return s.unskip("^se/")},_getLocationId:function(e){var t=this;return new(i.extend({urlRoot:window.Game.baseUri+"rest/user/location_id"}))().fetch({ignoreError:!0}).done(function(n){e&&e.call(t,n)})},_getPreLocationId:function(e){var t=this;return new(i.extend({urlRoot:window.Game.baseUri+"user/pre_location_id"}))().fetch({ignoreError:!0}).done(function(n){e&&e.call(t,n)})},_getShipId:function(e,t){var n=this;return new(i.extend({urlRoot:window.Game.baseUri+"rest/guild_airship/ship_type"+(e?"/"+e:"")}))().fetch({ignoreError:!0}).done(function(e){t&&t.call(n,e)})},_getJukebox:function(e,t){var n=this;return new(i.extend({urlRoot:window.Game.baseUri+"rest/guild_airship/bgm_file"+(e?"/"+e:"")}))().fetch({ignoreError:!0}).done(function(e){t&&t.call(n,e)})},_getJukeboxNew:function(e,t){var n=this;return new(i.extend({urlRoot:window.Game.baseUri+"rest/jukebox/bgm_file"+(e?"/"+e:"")}))().fetch({ignoreError:!0}).done(function(e){t.call(n,e)})},_getSoundData:function(e,n,a){var s=this;return t.isFunction(n)&&(a=n,n=null),o.load(e,{success:function(e){if(a){var i=e.data;t.isObject(i)&&!t.isArray(i)&&(i=i[n]),t.isArray(i)&&(i=i[t.random(i.length-1)]),a.call(s,i)}}})},playTownBGM:function(e){var t=this;if(!(e=e||"")&&u.isSupported()){var n=u.get("mypage_char_bgm"+Game.localstorageExtensions[Game.ua.platformName()]);if(n&&"default"!=n){t.playBGM("bgm/"+n);return}}return t._getSoundData("rest/sound/town_bgm?data="+e,e,function(e){t.playBGM(e)})},playQuestMapBGM:function(e,n,a){var s=this;"normal"==e?e+=Date.now():"event"===e?e+=Date.now():e||(e="empty"+Date.now());var i=t.filter([e?"location_id="+e:null,n?"quest_id="+n:null,a?"event_id="+a:null],t.identity).join("&");return s._getSoundData("rest/sound/quest_map_bgm?"+i,function(e){s.playBGM(e)})},playQuestMapBgmByFromPage:function(e){var t=+e||0;0===t?d.playQuestMapBGM("normal"):1===t?d.playQuestMapBGM():d.playQuestMapBGM("event",void 0,t)},playQuestSupporterBGM:function(e,n){var a=this,s=t.filter([e?"location_id="+e:null,n?"quest_id="+n:null],t.identity).join("&");return a._getSoundData("rest/sound/quest_supporter_bgm?"+s,function(e){a.playBGM(e)})},playShipBGM:function(e,t){var n=this;return e?n._getSoundData("rest/sound/ship_bgm?data="+e,e,function(e){n.playBGM(e)}):n._getShipId(t,function(e){e?n.playShipBGM(e):n.playTownBGM()})},playGuildBGM:function(e,t){var n=this;if(!e)return n._getJukebox(t,function(e){e&&n.playGuildBGM(e)});this.playBGM("bgm/"+e+".mp3")},playJukeboxDefaultBGM:function(){return this.playBGM("bgm/13_event_generalpurpose_00.mp3")},playJukeboxBGM:function(e,t){var n=this;if(!e)return n._getJukeboxNew(t,function(e){e&&n.playJukeboxBGM(e)});this.playBGM("bgm/"+e+".mp3")},playTutorialQuestBGM:function(){return this.playBGM("bgm/02_field_01.mp3")},playTutorialTownBGM:function(){return this.playBGM("bgm/11_kaze_reel_00.mp3")},playShopBGM:function(){return this.playBGM("bgm/11_kaze_reel_00.mp3")},playResultBGM:function(){return this.playBGM("bgm/05_gatcha_02.mp3")},playEventBGM:function(){return this.playBGM("bgm/12_baltz_06.mp3")},playLimitedBGM:function(e){return this.playBGM("2009"==e?"bgm/31_garonzo_02.mp3":"bgm/02_field_02.mp3")},loadMypageVoiceData:function(e,t){this._getSoundData("rest/sound/"+t+"?data="+e,e)},getMypageNpcBgmData:function(e,t){var n=this;this._getSoundData("rest/sound/mypage_npc_bgm?data="+e,e,function(e){t.call(n,e)})},playSoundArrayInOrder:function(e,n){var a=this;return o.load("rest/sound/"+n+"?data="+e,{success:function(s){var i,o=s.data;t.isObject(o)&&!t.isArray(o)&&(o=o[e]),a.currentVoiceId===e&&o.length-1>a.currentVoiceIndex?a.currentVoiceIndex++:(a.currentVoiceId=e,a.currentVoiceIndex=0),i=t.isArray(o)?o[a.currentVoiceIndex]:o,a.playVoice(i,{force:"archive_voice"===n})}})},loadArchiveVoiceData:function(e){this._getSoundData("rest/sound/archive_voice?data="+e,e)},playWinVoice:function(e){var t=this;t._getSoundData("rest/sound/win_voice?data="+e,e,function(e){t.playVoice(e)})},playDyingVoice:function(e){var t=this;t._getSoundData("rest/sound/dying_voice?data="+e,e,function(e){t.playVoice(e)})},playSpecialSkillGaugeVoice:function(e){var t=this;t._getSoundData("rest/sound/special_skill_gauge_voice?data="+e,e,function(e){t.playVoice(e)})},playFormationVoice:function(e,t){var n=this;n._getSoundData("rest/sound/formation_voice?data="+e+"&npc_id="+t,e,function(e){n.playVoice(e)})},playGachaVoice:function(e){var t=this;t._getSoundData("rest/sound/gacha_voice?data="+e,e,function(e){t.playVoice(e)})},playEvolutionVoice:function(e){var t=this;t._getSoundData("rest/sound/evolution_voice?data="+e,e,function(e){t.playVoice(e)})},playSampleSE:function(e){var t=this;t._getSoundData("rest/sound/sample_se",function(e){t.playSE(e,{alias:a.SE_SAMPLE_ALIAS})})},playSampleVoice:function(e){var t=this;t._getSoundData("rest/sound/sample_voice",function(e){t.playVoice(e,{alias:a.VOICE_SAMPLE_ALIAS})})},playRecastMaxSE:function(){return this.playSE("se/ougi_gauge_se_1.mp3")},playSlideSE:function(){return this.playSE("se/btn_se/btn_se_02.mp3")},playEquipSE:function(){return this.playSE("se/equip_se_1.mp3")},playChangeWeaponSE:function(){return this.playSE("se/set_sw_se_1.mp3")},playSortSE:function(){return this.playSE("se/sort_se_1.mp3")},playNextSceneSE:function(e){var t=e||a.SE_NEXT_SCENE;return this.playSE(t,{alias:a.SE_NEXT_SCENE})},playExpGaugeSE:function(){return this.playSound("se/gauge_se_1.mp3",{offset:.15})},playAssistSE:function(){return this.playSound("se/help_se_1_01.mp3")},playAssistJoinedSE:function(){return this.playSE("se/help_se_2.mp3")},playBattleReadySE:function(){return this.playSE("se/ready_se_1.mp3")},playOpenAccordionSE:function(){return this.playSE("se/page_se_1.mp3")},playCloseAccordionSE:function(){return this.playSE("se/page_back_se_1.mp3")},playOpenMenuSE:function(){return this.playSE("se/menu_open_se_1.mp3")},playCloseMenuSE:function(){return this.playSE("se/menu_close_se_1.mp3")},playGetItemSE:function(){return this.playSE("se/itemget_04_se_1.mp3")},playGetTreasureSE:function(){return this.playSE("se/itemget_03_se_1.mp3")},playRankUpSE:function(){return this.playSE("se/rankup_se_1.mp3")},playLevelUpSE:function(){return this.playSE("se/levelup_se_1.mp3")},playPopSE:function(){return this.playSE("se/popup_se_1.mp3")},playQuestForwardButtonSE:function(){return this.playSE("se/btn_se/btn_se_01.mp3")},playSuccessSE:function(){return this.playSE("se/success_s_se_1.mp3")},playGreatSuccessSE:function(){return this.playSE("se/success_l_se_1.mp3")},playPushStampSE:function(){return this.playSE("se/stamp_se_1.mp3")},playRecoverySE:function(){return this.playSE("se/item_use_se_1.mp3")},playJournalSE:function(){return this.playSE("se/journal_se.mp3")},playButtonSE:function(e){var n=this;if(e.hasClass(_)&&e.data(_)){this.playSE(e.data(_));return}e.hasClass("btn-disable-sound")||(e.hasClass("btn-switch-sound")||e.hasClass("btn-bgm-change"))&&e.hasClass("soundOn")||t.some(p,function(a){return t.some(a.classes,function(t){return!!e.hasClass(t)&&(a.se!==l&&n.playSE(a.se),!0)})})||n.playSE(r)},playPopShowSE:function(e){var n=this;t.some(c,function(a){return t.some(a.classes,function(t){return!!e.hasClass(t)&&(n.playSE(a.se),!0)})})}},{DEFAULT_BUTTON_SE:r,CLASS_PLAY_SPECIFIED_SE:_});return d.makeSingleton(),d});
define('constant/mypage_an',[],function(){return{TOP:1,MENU:2,SOUND:3,PARTY:4,ENHANCE:5,COOP:6,MULTI_BATTLE_LIST:7,FREE_QUEST_LIST:8,GACHA:9,CHARA:10,SETTING:11,PASS:12,PRESENT:13,NOTICE:14,SUPPORT:15,TOWN:16,QUEST:17,MULTI_BATTLE:18,AP:19,BP:20,MINI_GACHA_BANNER:21,CAMPAIGN:22,SERAPHIC:23,ARCARUM:24,GUIDE:25,CASINO:26,FRONTIER:27,BEGINNER_COMIC:28,COMIC:29,MENU_PARTY:101,MENU_ENHANCE:102,MENU_COOP:103,MENU_GACHA:104,MENU_QUEST:105,MENU_PROFILE:106,MENU_ARCHIVE:107,MENU_GUILD:108,MENU_ITEM:109,MENU_SHOP:110,MENU_PRESENT:111,MENU_LIST:112,MENU_CONTAINER:113,MENU_FRIEND:114,MENU_WORLD:115,MENU_SETTING:116,MENU_HELP:117,CAMPAIGN_TRIAL_BATTLE:202,CAMPAIGN_SIDE_STORY:203,CAMPAIGN_PREMIUM:204,CAMPAIGN_ALCHEMY:205,CAMPAIGN_SERAPHIC:206,CAMPAIGN_BEGINNER_COMIC:207,CAMPAIGN_GBVSR:208,CAMPAIGN_RELINK:209,TOWN_GUILD:301,TOWN_SHOP:302,TOWN_ARCHIVE:303,MINI_COACHING:401,MINI_GUIDE:402,MINI_MISSION:403}});
define('util/touch',["jquery","underscore","util/function","flexslider"],function(e,t,n){var o="ontouchstart"in window,a="onmousedown"in window,u=o?"touchstart":"mousedown",c=o?"touchmove":"mousemove",i=o?"touchend":"mouseup";if(e.event.special.cgtouchstart={bindType:u,delegateType:u},e.event.special.cgtouchmove={bindType:c,delegateType:c},e.event.special.cgtouchend={bindType:i,delegateType:i},Game.cgtouchstartEvent=u,Game.ua.isPcPlatformHasTouch=(Game.ua.isPcPlatform()||Game.ua.isAndApp())&&o&&a,!o||Game.ua.isPcPlatformHasTouch){var s=e(window),r=Math.max(document.documentElement.clientWidth,window.innerWidth||0),d=Math.max(document.documentElement.clientHeight,window.innerHeight||0),m={mousedown:"touchstart",mousemove:"touchmove",mouseup:"touchend"},h={};t.each(m,function(e,t){var n=h[e]=document.createEvent("UIEvent");n.initUIEvent(e,!0,!0,window,1),n.touches=n.targetTouches=n.changedTouches=[{}]});var f=function(t){if(Game.ua.isJssdkSideMenu()){var n=e(Game.gameContainer.selector);r=(n.offset().left+n.width())*n.css("zoom")}return t.clientX<0||r<t.clientX||t.clientY<0||d<t.clientY},l=function(e){var n=e.type;if(f(e)&&(n="mouseup"),o&&"mouseup"===e.type&&"undefined"!=typeof TouchEvent&&"undefined"!=typeof Touch){var a=h.touchstart.target,u={identifier:0,target:a};t.each(["clientX","clientY","pageX","pageY","screenX","screenY"],function(t){u[t]=e[t]}),c=new TouchEvent("touchend",{changedTouches:[new Touch(u)]}),a.dispatchEvent(c)}else{var c=h[m[n]];t.each(["clientX","clientY","pageX","pageY","screenX","screenY"],function(t){c.touches[0][t]=c[t]=e[t]}),(a="mouseup"===n?h.touchstart.target:e.target)&&(c.touches[0].target=a,c.touches[0].identifier=0,c.changedTouches=c.touches,a.dispatchEvent(c))}},p=function(e){f(e)?v(e):l(e)},v=function(e){s.off("mousemove",p),s.off("mouseup",v),l(e)};if(s.on("mousedown",function(e){(!o||"CANVAS"===e.target.tagName)&&(f(e)||(s.on("mousemove",p),s.on("mouseup",v),l(e)))}),!o){var g=e.flexslider;e.flexslider=function(e,t){window.ontouchstart=n.returnFalse,g.call(this,e,t),delete window.ontouchstart},e.flexslider.defaults=g.defaults}}window.UAParser&&(Game.ua.isIOS()||Game.ua.isIPad())&&Game.ua.versionCompare(Game.ua.getOSVersion(),"15")>=0&&document.addEventListener("pointerdown",function(t){var n=new Date,o=t.pageX,a=t.pageY,u=function(t){document.removeEventListener("pointerup",u);var c=new Date-n,i=Math.abs(o-t.pageX),s=Math.abs(a-t.pageY);c>300||i>5||s>5||e(t.target).trigger(e.Event("hacktap",{x:t.x,y:t.y}))};document.addEventListener("pointerup",u)})});
define('view/popup',["underscore","backbone","model/sound"],function(e,t,s){return t.View.extend({el:"#pop",defaults:{className:null,title:null,body:null,flagBtnCancel:0,flagBtnOk:0,flagBtnClose:0,btnOkClassName:null,btnCancelClassName:null,btnCloseClassName:null,btnOkText:null,btnCancelText:null,btnCloseText:null,showStartCallback:null,showEndCallback:null,maskSubMenu:null,btnTreasure:0,treasureId:null,treasureName:"",treasureSelected:!1,treasureAddClassPopRegistration:""},events:{"tap .btn-usual-ok":"onPushOk","tap .btn-usual-cancel":"onPushCancel","tap .btn-usual-close":"onPushClose","tap .btn-treasure-registration":"onTapRegisterBtn"},initialize:function(){this.destroyedPop=!1,this.options=this.options||{},this.options.targetObj&&$(this.options.targetObj).length&&(this.el=this.options.targetObj),e.isUndefined(this.options.maskSubMenu)||!0!==this.options.maskSubMenu||(this.el="#submenu-pop"),this.setElement(this.el),this.options=e.defaults(this.options,this.defaults)},render:function(){null===(t=this.el)||void 0===t||t.classList.add("popup-view-root"),Game.footer&&Game.footer.mainView&&Game.footer.mainView.isTreasurePUOpen&&!0!==this.options.maskSubMenu&&Game.footer.mainView.destroy();var t,s=!e.isUndefined(Game.footer)&&Game.treasure&&Game.treasure.list;return this.options.treasureId=s&&this.options.treasureId||null,this.options.btnTreasure=this.options.treasureId?this.options.btnTreasure:0,this.options.treasureName=this.options.treasureId&&this.options.treasureName?this.options.treasureName:"",e.isNull(this.options.treasureId)||this.stopListening(Game.footer.mainView,"treasurePopupClose").listenTo(Game.footer.mainView,"treasurePopupClose",this.updateTreasureBtn),this.$el.html(e.template($("#popup").html(),this.options)),this.updateTreasureBtn(),this},renderBody:function(e){var t=this.$el.find("#popup-body");e.forEach(function(e){t.append(e.$el)})},activeOKButton:function(e){this.$el.find(".btn-usual-ok").toggleClass("disable btn-silent-se",!e)},updateTreasureBtn:function(){var t=+this.options.treasureId;if(!e.isUndefined(Game.footer)&&Game.treasure&&Game.treasure.list&&t){var s=Game.treasure.list.length>0&&e.some(Game.treasure.list,function(e){return+e.item_id===t}),i=this.$el.find(".prt-treasure-registration"),a=i.find(".btn-treasure-registration");i.toggleClass("max",Game.treasure.isSetMax()&&!1===s),a.toggleClass("selected",s)}},popShow:function(e,t){this.options.showStartCallback&&this.options.showStartCallback(),clearTimeout(0);var i,a=this.options.maskSubMenu?$(".mask_submenu"):$(".mask");if(!1===this.options.maskSubMenu){var n=$("#wrapper").height();a.height()<n&&a.css("height",n)}var o=$("#wrapper").find(".cnt-quest-scene").find(".prt-log-display"),r=o.length>0&&"block"===o.css("display");if(!0===r){var p=o.height()+$("#wrapper .prt-quest-header").height();a.height()<p&&a.css("height",p)}a.css("display","block");var u=this.$el.find(".pop-usual"),l=this;s.playPopShowSE(u);var h=this.options.showEndCallback;h&&u.oneTransitionEnd(function(){u.off("transitionend webkitTransitionEnd"),h()},300);var d=$(window).height(),m=this.options.maskSubMenu?d:Game.ua.isSteamApp()?Number($(".contents").height()):Number($("html").height()),g=Game.getZoom(),c=this.options.maskSubMenu?0:Game.get$ScrollParent().scrollTop();Game.ua.isJssdk()&&(m=Number($(Game.gameContainer.selector).height())),!0===r&&(m=p);var f=50*+g;0<$("#debug").length&&(f=f+ +$("#debug").height()+30),i=void 0!==e?t:(((d=Math.min(m*g,d))-u.height()*g)/2+c)/g,u.css({display:"block",top:i+"px"}).delay(100).queue(function(){if(e)$(this).removeClass("pop-hide").addClass("pop-show");else{var t=i,s=t+u.height(),a=Game.ua.isChromeApp()&&f<100?100:f,n=m-a;s>n+(Game.ua.isSteamApp()?Game.get$ScrollParent().scrollTop():0)&&(t=n-u.height()),t<0&&(t=0);var o=+m-+u.height()-+f;if(o<0){var r=Math.abs(o),p=$("#wrapper").css("margin-bottom").replace(/px/g,"");l.updatedWrapperMargin=!0,l.updateWrapperMargin(1,+p+r+50)}i!=t?(u.css("top",t+"px"),setTimeout(function(){u.removeClass("pop-hide").addClass("pop-show")},100)):$(this).removeClass("pop-hide").addClass("pop-show")}}),this.trigger("popShow")},popClose:function(){var e=this;this.updateWrapperMargin(0,0),this.$el.find(".pop-usual").removeClass("pop-show").addClass("pop-hide").oneTransitionEnd(function(){$(this).css("display","none"),e.popOff(),e.trigger("popClose")},300)},popRemove:function(e){var t=this;this.trigger("removeStart"),this.updateWrapperMargin(0,0),this.$el.find(".pop-usual").removeClass("pop-show").addClass("pop-hide").oneTransitionEnd(function(){if(1!=e){var s=t.options.maskSubMenu?".mask_submenu":".mask";$(this).add(s).css("display","none")}t.trigger("removeEnd"),$(this).off("transitionend webkitTransitionEnd"),t.destroy()},300)},locationUnclaimed:function(e){this.popRemove(),t.history.navigate("#quest/assist/unclaimed",!0)},popOff:function(){this.off(),this.undelegateEvents(),this.stopListening()},popDelete:function(t){var s=e.defaults(t||{},{isHideMask:!0});this.$el.find(".pop-usual").removeClass("pop-show").addClass("pop-hide"),s.isHideMask&&$(this).add(".mask").css("display","none"),$(this).off("transitionend webkitTransitionEnd"),this.off(),this.undelegateEvents(),this.stopListening(),this.updateWrapperMargin(0,0)},destroy:function(){this.$el.empty(),this.trigger("popEmptyEnd"),this.popOff(),this.destroyedPop=!0},onPushOk:function(){this.trigger("ok")},onPushCancel:function(){this.trigger("cancel")},onPushClose:function(){this.trigger("close")},onTapRegisterBtn:function(e){this.options.treasureId&&Game.footer.mainView.handleRegistration($(e.currentTarget),this.options.treasureId,this.options.treasureName,{addClassPopRegistration:this.options.treasureAddClassPopRegistration||""})},updateWrapperMargin:function(e,t){this.updatedWrapperMargin&&(this.defaultWrapperMarginBottom||(this.defaultWrapperMarginBottom=$("#wrapper").css("margin-bottom").replace(/px/g,"")),0===e?$("#wrapper").css("margin-bottom",this.defaultWrapperMarginBottom+"px"):$("#wrapper").css("margin-bottom",t+"px"))},popShowUpdatedWrapperMargin:function(){var e=$("#wrapper"),t=this.$el.find(".pop-usual"),s=parseInt(e.css("margin-bottom"),10),i=parseInt(t.css("top"),10),a=e.innerHeight(),n=50+i+t.height()-a;n<s||(this.updatedWrapperMargin=!0,this.updateWrapperMargin(1,n))}},{SKIN:{VALENTINE:"valentineday",WHITE:"whiteday",HALLOWEEN:"pop-season-event1",CHRISTMAS:"pop-season-event2"},applyDecorators:function(e){return e.reduce(function(e,t){return t(e)},this)}})});
define('view/chat/form',["jquery","underscore","backbone","view/popup","util/language-message"],function(e,t,i,n,s){var a="#pop-chat",o="submit",r=i.View.extend({el:"#general-chat .chat-form",events:{"tap #chat-input:not(.disable)":"userFocus","tap #chat-send:not(.disable)":"checkMessage"},initialize:function(){this.$input=this.$el.find("#chat-input"),this.$send=this.$el.find("#chat-send"),this.setupInput()},setupInput:function(e){(e=e||this.$input).keyup(function(e){if(13===e.keyCode)return!1}),e.keypress(function(e){if(13===e.keyCode)return!1})},disable:function(){this.$send.addClass("disable"),this.$input.addClass("disable"),this.disableInput()},disableInput:function(){this.$input.attr("disabled","disabled")},enable:function(){this.$send.removeClass("disable"),this.$input.removeClass("disable"),this.enableInput()},enableInput:function(){this.$input.removeAttr("disabled")},clearInput:function(){this.$input.val("")},userFocus:function(e){e.stopPropagation(),this.trigger("userfocus")},checkMessage:function(e){if(this.trigger("sendButtonTapped"),this.inputComment=this.$input.val().replace("%%br%%",""),this.inputComment&&this.inputComment.match(/\S/)){if(this.inputComment.length>140){var t=s.replaceMessage("guild_main_150",[140]);this.trigger("submissionExcessError",t);return}}else{this.clearInput();var t=s.getMessage("guild_main_149");this.trigger("submissionEmptyError",t);return}this.trigger(o,{comment:this.inputComment}),this.clearInput(),e&&(e.preventDefault(),Game.ua.isJssdk()||e.stopPropagation())},errorChat:function(t){var i=this,n=new p({err_msg:t});n.on(o,function(e){i.trigger(o,e)}),n.render();var s=e("#frm-message.frm-message");this.setupInput(s)},popErrorDialog:function(e){e||(e=s.getMessage("guild_main_148"));var t=new n({el:a,className:"common-pop-error",title:s.getMessage("guild_main_145"),body:e,flagBtnCancel:0,flagBtnOk:1});t.on("ok",function(){t.popRemove()}),t.render().popShow()},popIntervalErrorDialog:function(){this.popErrorDialog(s.getMessage("guild_main_146"))},popCompletionDialog:function(){var e=new n({el:a,className:"send-chat",title:s.getMessage("guild_main_103"),body:s.getMessage("guild_main_106"),flagBtnCancel:0,flagBtnOk:1});e.on("ok",function(){e.popRemove()}),e.render().popShow()},destroy:function(){this.off(),this.undelegateEvents(),this.stopListening()}}),p=r.extend({el:"",$frmMessage:null,template:t.template(e("#tpl-chat-pop").html()),initialize:function(){var e=this.options.err_msg;this.create(e)},render:function(){return this.renderPopup(),this.$frmMessage=e("#frm-message"),this},create:function(e){var t=this;(void 0==e||""==e)&&(e=s.getMessage("guild_main_107")),!0==e&&(e="");var i={inputText:this.inputComment,errflag:!0,msg:e,count_max:140};this.popView=new n({el:a,className:"ready-chat",title:s.getMessage("guild_main_108"),body:this.template(i),flagBtnCancel:1,flagBtnOk:1}),this.popView.on("ok",function(){t.popView.popOff(),t.popView.popRemove(),t.checkMessage()}),this.popView.on("cancel",function(){t.popView.popRemove()})},renderPopup:function(){this.popView.render().popShow(),this.setElement(".ready-chat")}});return r});
define('collection/data',["backbone","underscore","util/ajax"],function(e,t,r){return e.Collection.extend({initialize:function(e,t){this.listenToOnce(this,"error",this.error)},parse:function(e){if(e){var r=e.redirect;r&&t.isString(r)&&(0===e.redirect.indexOf("#")?window.location.hash=r.slice(1):window.location.href=r)}return e},error:function(e,t,n){!r.isManuallyAbortedXHR(t)&&(404===t.status&&null===t.getResponseHeader("Content-Length")&&(t.status=0),409==t.status||410==t.status||(Game.reportError("[DataCollection] response status "+t.status,e.url()||n.url),n.ignoreError||Game.view.trigger("data_error")))},sync:function(t,r,n){return(n=n||{}).cache=n.cache||!1,e.Collection.prototype.sync.apply(this,arguments)}})});
define('collection/chat/stamp',["collection/data"],function(e){var t={0:55,1:140,2:140},n={0:5,1:20,2:0};return e.extend({method:"",stampPerPage:20,recentStampMax:20,url:function(){return Game.baseUri+this.method},getStampLengthThreshold:function(e){return t[+e]},getRecentStampThreshold:function(e){return n[+e]}})});
define('view/chat/stamp',["jquery","underscore","backbone","view/popup","collection/chat/stamp","model/sound","util/local-storage","flexslider","util/language-message"],function(t,e,s,i,a,p,n,o,l){var r="#pop-chat",m="pop-ready-stamp",h=!1,c="submit",u=s.View.extend({el:"#general-chat .chat-stamp",events:{"tap #chat-stamp:not(.disable)":"fetchStampCollection"},initialize:function(e){e=e||{},this.isGeneralChat=e.isGeneralChat||!1,this.$stamp=t("#chat-stamp"),!1===this.isGeneralChat&&(this.events={}),this.stampCollectionRequest=new(a.extend({method:"rest/profile/stamp_list/"}))},fetchStampCollection:function(){var t=this;this.stampCollectionRequest.fetch().fail(function(){t.trigger("error")}).done(function(){t.popStampList()})},disable:function(){this.$stamp.addClass("disable")},enable:function(){this.$stamp.removeClass("disable")},popStampList:function(){var t=this;this.stampCollection=this.stampCollection||this.stampCollectionRequest.models[0].attributes,this.stampPopupView=new d({stampList:this.stampCollection.stamp_list,stampPageMode:+this.stampCollection.stamp_page_mode,stampLength:this.stampCollectionRequest.getStampLengthThreshold(+this.stampCollection.stamp_page_mode),recentStampMax:this.stampCollectionRequest.getRecentStampThreshold(+this.stampCollection.stamp_page_mode),isGeneralChat:this.isGeneralChat}),this.listenToOnce(this.stampPopupView,c,function(e){t.trigger(c,e)});var e=!(2!==this.currentChannel);this.stampPopupView.render(e)},popIntervalErrorDialog:function(){var t=new i({el:r,className:"common-pop-error",title:l.getMessage("guild_main_145"),body:l.getMessage("guild_main_146"),flagBtnCancel:0,flagBtnOk:1});this.listenToOnce(t,"ok",function(){t.popRemove()}),t.render().popShow()},popCompletionDialog:function(){var t=new i({el:r,className:"send-stamp",title:l.getMessage("guild_main_103"),body:l.getMessage("guild_main_114"),flagBtnCancel:0,flagBtnOk:1,btnOkClassName:"btn-stamp-ok"});this.listenToOnce(t,"ok",function(){t.popRemove()}),t.render().popShow()},content_close:function(){this.closePopStamp(),this.destroy()},closePopStamp:function(){this.stampPopupView&&this.stampPopupView.popView&&this.stampPopupView.closePopup()},destroy:function(){this.off(),this.undelegateEvents(),this.stopListening()}}),d=s.View.extend({el:"",postFlag:!1,postStampId:0,events:{"tap .prt-popup-body .img-stamp":"postStamp","tap .prt-popup-footer .btn-usual-ok":"closePopup","tap .prt-popup-footer .btn-usual-cancel":"closePopup"},initialize:function(t){this.isGeneralChat=t.isGeneralChat,this.stampPageMode=+t.stampPageMode,this.fullStampList=t.stampList,this.stampLength=t.stampLength,this.recentStampMax=t.recentStampMax;var s=this;this.stampList=e.filter(t.stampList,function(t){return+t.priority<=s.stampLength}),this.stampList=e.sortBy(this.stampList,function(t){return+t.priority})},render:function(t){this.renderPopup(m,t);var e=this,s=this.popView.$el.find(".prt-stamp-wrapper .lis-stamp-slider");return s.css("display","none"),this.popView.$el.find(".prt-stamp-image").flexslider({selector:".prt-stamp-wrapper > .lis-stamp-slider",animation:"slide",animationLoop:!1,slideshow:!1,prevText:"",nextText:"",start:function(){s.css("display","block")},before:function(){setTimeout(function(){e.postFlag=!0},1)},after:function(){e.postFlag=!1}}),this.$el.find("."+m).css("top",Game.get$ScrollParent().scrollTop()/Game.getZoom()+20+"px"),this},postStamp:function(e){if(!0===this.isGeneralChat){if(!0===h)return;h=!0,setTimeout(function(){h=!1},5e3)}this.postFlag||(this.postFlag=!0,p.playPushStampSE(),this.postStampId=t(e.currentTarget).data("stamp-id"),n.isSupported()&&this.prepareLatestStamp(this.postStampId),this.closePopup())},getRecentStamps:function(){var t,s,i=[];if(this.recentStamps=this.recentStamps||[],(t=n.getItem("recentStamps"))&&(t=JSON.parse(t)),!t){for(s=0;s<this.stampLength;s++)i[s]=0;n.setObject("recentStamps",i),t=i}for(s=0;s<this.stampLength;s++)this.recentStamps[s]=e.find(this.fullStampList,function(e){return+e.id===t[s]}),void 0===this.recentStamps[s]&&(this.recentStamps[s]={id:"0"});return this.recentStamps},prepareLatestStamp:function(t){this.preparedLatestStamp=t},setLatestStamp:function(){var t,s,i,a,p=[];if(null!==(t=this.preparedLatestStamp||null)){for(i=this.getRecentStamps(),s=e.filter(i,function(e){return+e.id!==t}),a=this.stampLength;a--;)void 0===s[a]&&(s[a]={id:"0"}),p[a+1]=+s[a].id;p[0]=t,n.setObject("recentStamps",p)}},renderPopup:function(s,a){var p=this,o={};o.stampList=this.stampList,o.enabledRecentStamps=n.isSupported(),o.enabledRecentStamps?(o.recentStamps=this.getRecentStamps(),o.showRecentStamps=this.judgeShowRecentStamp(o.recentStamps)):o.showRecentStamps=!1,o.recentStampMax=this.recentStampMax,o.showIcoVoiceStamp=a||!1,this.popView=new i({el:r,className:m,title:l.getMessage("guild_main_147"),body:e.template(t("#tpl-stamp").html(),o),flagBtnCancel:1,flagBtnOk:0}),this.stopListening(this.popView),this.listenToOnce(this.popView,"removeEnd",function(){p.postFlag&&(p.trigger(c,{stamp_id:p.postStampId}),p.setLatestStamp())}),this.popView.render().popShow(),this.setElement("."+s)},judgeShowRecentStamp:function(t){return void 0!==e.find(t,function(t){return+t.id>0})},closePopup:function(){this.popView.popRemove()}});return u});
define('util/language',["underscore"],function(n){var a=function(n){return Game.lang===n};return{isJapanese:n.partial(a,"ja"),isEnglish:n.partial(a,"en")}});
define('model/chat',["jquery","underscore","backbone","util/language"],function(e,t,a,n){var i=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];return a.Model.extend({PAGE_DEFAULT:1,LIMIT_DEFAULT:30,infoModel:null,commentListModel:null,postFormModel:null,postStampModel:null,fetchInfo:function(){return this.infoModel.fetch()},fetchCommentList:function(){var a=this,n=new e.Deferred;return this.commentListModel.fetch().done(function(e){var i=[];e&&e.list&&(!1===t.isUndefined(e.skin_coop)&&(a.skinCoop=+e.skin_coop,0===a.skinCoop&&t.each(e.list,function(e){e.user_image=e.no_skin_image})),i=t.chain(e.list).sortBy(function(e){return Number(e.id||e.timestamp||e.created_at)}).map(function(e){return a.parseComment(e)}).value()),n.resolve(i,e)}).fail(function(e){n.reject(e)}),n},postForm:function(e){return this.postFormModel.clear().set(e).save()},postStamp:function(e){return this.postStampModel.clear().set(e).save()},parseComment:function(e){if(e.userId&&e.timestamp&&e.nickname&&e.userImage&&e.commentData)return e.chatTime=this.toChatTime(e.timestamp),t.isObject(e.commentData.content)&&(e.commentData.content=e.commentData.content[Game.lang]),e.commentData.isStamp&&!this.isImgTag(e.commentData.content)&&(e.commentData.content=this.toStampTag(e.commentData.content)),Game.ua.isGlobalUser()&&(null===(n=e.commentData)||void 0===n?void 0:n.isHideGlobal)&&(e.commentData.content=e.commentData.replaceText[Game.lang]),Game.ua.isGlobalUser()&&e.userImageIsHideGlobal&&(e.userImage=e.userImageOriginal),e;if(!e.user_id||!e.chat_time||!e.user_name||!e.user_image||!e.user_comment)throw Error("Lack of required param, param are ",e);var a,n,i=t.isObject(e.user_comment.text)?e.user_comment.text[Game.lang]:e.user_comment.text;if(e.user_comment.is_stamp){var m=Game.imgUri.replace(/img(_low|_mid)?/,"img");i=i.replace(/http.+\/assets(_en)?\/img/,m)}return!0===this.isGuildChannel&&(i=i.replace(/%%br%%/g,"<br>")),(null===(a=e.user_comment)||void 0===a?void 0:a.isHideGlobal)&&Game.ua.isGlobalUser()&&(i=e.user_comment.replaceText[Game.lang]),e.userImageIsHideGlobal&&Game.ua.isGlobalUser()&&(e.user_image=e.userImageOriginal),t.isObject(e.chat_time)&&(e.chat_time=e.chat_time[Game.lang]),{id:e.id,userId:e.user_id,platformId:e.platform_id,chatTime:e.chat_time,nickname:e.user_name,userImage:e.user_image,categoryId:e.category_id,chatId:e.chat_id,commentFrom:e.comment_from,commentData:{isStamp:e.user_comment.is_stamp,content:i},systemEvent:e.system_type,logType:e.log_type||1}},toStampTag:function(e){return'<img src="'+(Game.imgUri+"/sp/assets/stamp/full/")+e+'" alt="" class="img-stamp">'},isImgTag:function(e){return e.indexOf("<img")>=0},toDoubleDigit:function(e){return e<10?"0"+e:e},toTime24:function(e,t){return e+":"+this.toDoubleDigit(t)},toTime12:function(e,t){var a=e,n=e<12?"a.m.,":"p.m.,";return(e>12?a=e-12:0===e&&(a=12),0===t)?0===e?"12 midnight,":12===e?"12 noon,":a+" "+n:a+":"+this.toDoubleDigit(t)+" "+n},toChatTime:function(e){var t=new Date(e),a=t.getMonth(),m=t.getDate(),o=t.getHours(),s=t.getMinutes();switch(!0){case n.isJapanese():default:return a+1+"/"+m+" "+this.toTime24(o,s);case n.isEnglish():return this.toTime12(o,s)+" "+i[a]+" "+m+" (JST)"}}})});
define('model/chat/guild',["jquery","underscore","backbone","model/data","model/token-data","model/chat"],function(o,e,i,t,n,m){return m.extend({infoModel:new(t.extend({urlRoot:Game.baseUri+"rest/guild/main/guild_info"})),postFormModel:new(n.extend({urlRoot:Game.baseUri+"guild_main/comment"})),postStampModel:new(n.extend({urlRoot:Game.baseUri+"guild_main/stamp"})),coopRoomLinkModel:new(n.extend({urlRoot:Game.baseUri+"coopraid/room_key"})),skycoopRoomLinkModel:new(n.extend({urlRoot:Game.baseUri+"sky/coopraid/room_key"})),initialize:function(o){var e=o&&o.page?o.page:this.PAGE_DEFAULT,i=o&&o.limit?o.limit:this.LIMIT_DEFAULT;this.isGuildChannel=!0,this.commentListModel=new(t.extend({urlRoot:Game.baseUri+"guild/main/comment_list/"+e+"/"+i}))},jumpToCoopRoom:function(o){return this.coopRoomLinkModel.set({room_key:o}).save()},jumpToSkycoopRoom:function(o){return this.skycoopRoomLinkModel.set({room_key:o}).save()}})});
define('model/chat/raid',["jquery","underscore","backbone","model/data","model/token-data","model/chat"],function(e,t,o,n,d,l){return l.extend({infoModel:null,commentListModel:null,postFormModel:new(d.extend({urlRoot:Game.baseUri+"rest/multiraid/comment"})),postStampModel:new(d.extend({urlRoot:Game.baseUri+"rest/multiraid/stamp"}))})});
define('model/chat/coop',["jquery","underscore","backbone","model/data","model/token-data","model/chat"],function(e,o,t,i,a,n){return n.extend({infoModel:new(i.extend({urlRoot:Game.baseUri+"coopraid/room_kind_and_id"})),postFormModel:new(a.extend({urlRoot:Game.baseUri+"coopraid/comment"})),postStampModel:new(a.extend({urlRoot:Game.baseUri+"coopraid/stamp"})),initialize:function(e){var o=e&&e.page?e.page:this.PAGE_DEFAULT,t=e&&e.limit?e.limit:this.LIMIT_DEFAULT;this.commentListModel=new(i.extend({urlRoot:Game.baseUri+"coopraid/chat_list/"+o+"/"+t}))}})});
define('model/chat/lobby',["backbone","model/data","model/token-data","model/chat"],function(e,t,o,a){return a.extend({postFormModel:new(o.extend({urlRoot:Game.baseUri+"lobby/comment"})),postStampModel:new(o.extend({urlRoot:Game.baseUri+"lobby/stamp"})),initialize:function(e){var o=e&&e.page?e.page:this.PAGE_DEFAULT,a=e&&e.limit?e.limit:this.LIMIT_DEFAULT;this.commentListModel=new(t.extend({urlRoot:Game.baseUri+"lobby/chat_list/"+o+"/"+a}))}})});
!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define('socketio',[],e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.io=e()}}(function(){var define,module,exports;return function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}({1:[function(_dereq_,module,exports){module.exports=_dereq_("./lib/")},{"./lib/":2}],2:[function(_dereq_,module,exports){var url=_dereq_("./url");var parser=_dereq_("socket.io-parser");var Manager=_dereq_("./manager");var debug=_dereq_("debug")("socket.io-client");module.exports=exports=lookup;var cache=exports.managers={};function lookup(uri,opts){if(typeof uri=="object"){opts=uri;uri=undefined}opts=opts||{};var parsed=url(uri);var source=parsed.source;var id=parsed.id;var io;if(opts.forceNew||opts["force new connection"]||false===opts.multiplex){debug("ignoring socket cache for %s",source);io=Manager(source,opts)}else{if(!cache[id]){debug("new io instance for %s",source);cache[id]=Manager(source,opts)}io=cache[id]}return io.socket(parsed.path)}exports.protocol=parser.protocol;exports.connect=lookup;exports.Manager=_dereq_("./manager");exports.Socket=_dereq_("./socket")},{"./manager":3,"./socket":5,"./url":6,debug:10,"socket.io-parser":46}],3:[function(_dereq_,module,exports){var url=_dereq_("./url");var eio=_dereq_("engine.io-client");var Socket=_dereq_("./socket");var Emitter=_dereq_("component-emitter");var parser=_dereq_("socket.io-parser");var on=_dereq_("./on");var bind=_dereq_("component-bind");var object=_dereq_("object-component");var debug=_dereq_("debug")("socket.io-client:manager");var indexOf=_dereq_("indexof");var Backoff=_dereq_("backo2");module.exports=Manager;function Manager(uri,opts){if(!(this instanceof Manager))return new Manager(uri,opts);if(uri&&"object"==typeof uri){opts=uri;uri=undefined}opts=opts||{};opts.path=opts.path||"/socket.io";this.nsps={};this.subs=[];this.opts=opts;this.reconnection(opts.reconnection!==false);this.reconnectionAttempts(opts.reconnectionAttempts||Infinity);this.reconnectionDelay(opts.reconnectionDelay||1e3);this.reconnectionDelayMax(opts.reconnectionDelayMax||5e3);this.randomizationFactor(opts.randomizationFactor||.5);this.backoff=new Backoff({min:this.reconnectionDelay(),max:this.reconnectionDelayMax(),jitter:this.randomizationFactor()});this.timeout(null==opts.timeout?2e4:opts.timeout);this.readyState="closed";this.uri=uri;this.connected=[];this.encoding=false;this.packetBuffer=[];this.encoder=new parser.Encoder;this.decoder=new parser.Decoder;this.autoConnect=opts.autoConnect!==false;if(this.autoConnect)this.open()}Manager.prototype.emitAll=function(){this.emit.apply(this,arguments);for(var nsp in this.nsps){this.nsps[nsp].emit.apply(this.nsps[nsp],arguments)}};Manager.prototype.updateSocketIds=function(){for(var nsp in this.nsps){this.nsps[nsp].id=this.engine.id}};Emitter(Manager.prototype);Manager.prototype.reconnection=function(v){if(!arguments.length)return this._reconnection;this._reconnection=!!v;return this};Manager.prototype.reconnectionAttempts=function(v){if(!arguments.length)return this._reconnectionAttempts;this._reconnectionAttempts=v;return this};Manager.prototype.reconnectionDelay=function(v){if(!arguments.length)return this._reconnectionDelay;this._reconnectionDelay=v;this.backoff&&this.backoff.setMin(v);return this};Manager.prototype.randomizationFactor=function(v){if(!arguments.length)return this._randomizationFactor;this._randomizationFactor=v;this.backoff&&this.backoff.setJitter(v);return this};Manager.prototype.reconnectionDelayMax=function(v){if(!arguments.length)return this._reconnectionDelayMax;this._reconnectionDelayMax=v;this.backoff&&this.backoff.setMax(v);return this};Manager.prototype.timeout=function(v){if(!arguments.length)return this._timeout;this._timeout=v;return this};Manager.prototype.maybeReconnectOnOpen=function(){if(!this.reconnecting&&this._reconnection&&this.backoff.attempts===0){this.reconnect()}};Manager.prototype.open=Manager.prototype.connect=function(fn){debug("readyState %s",this.readyState);if(~this.readyState.indexOf("open"))return this;debug("opening %s",this.uri);this.engine=eio(this.uri,this.opts);var socket=this.engine;var self=this;this.readyState="opening";this.skipReconnect=false;var openSub=on(socket,"open",function(){self.onopen();fn&&fn()});var errorSub=on(socket,"error",function(data){debug("connect_error");self.cleanup();self.readyState="closed";self.emitAll("connect_error",data);if(fn){var err=new Error("Connection error");err.data=data;fn(err)}else{self.maybeReconnectOnOpen()}});if(false!==this._timeout){var timeout=this._timeout;debug("connect attempt will timeout after %d",timeout);var timer=setTimeout(function(){debug("connect attempt timed out after %d",timeout);openSub.destroy();socket.close();socket.emit("error","timeout");self.emitAll("connect_timeout",timeout)},timeout);this.subs.push({destroy:function(){clearTimeout(timer)}})}this.subs.push(openSub);this.subs.push(errorSub);return this};Manager.prototype.onopen=function(){debug("open");this.cleanup();this.readyState="open";this.emit("open");var socket=this.engine;this.subs.push(on(socket,"data",bind(this,"ondata")));this.subs.push(on(this.decoder,"decoded",bind(this,"ondecoded")));this.subs.push(on(socket,"error",bind(this,"onerror")));this.subs.push(on(socket,"close",bind(this,"onclose")))};Manager.prototype.ondata=function(data){this.decoder.add(data)};Manager.prototype.ondecoded=function(packet){this.emit("packet",packet)};Manager.prototype.onerror=function(err){debug("error",err);this.emitAll("error",err)};Manager.prototype.socket=function(nsp){var socket=this.nsps[nsp];if(!socket){socket=new Socket(this,nsp);this.nsps[nsp]=socket;var self=this;socket.on("connect",function(){socket.id=self.engine.id;if(!~indexOf(self.connected,socket)){self.connected.push(socket)}})}return socket};Manager.prototype.destroy=function(socket){var index=indexOf(this.connected,socket);if(~index)this.connected.splice(index,1);if(this.connected.length)return;this.close()};Manager.prototype.packet=function(packet){debug("writing packet %j",packet);var self=this;if(!self.encoding){self.encoding=true;this.encoder.encode(packet,function(encodedPackets){for(var i=0;i<encodedPackets.length;i++){self.engine.write(encodedPackets[i])}self.encoding=false;self.processPacketQueue()})}else{self.packetBuffer.push(packet)}};Manager.prototype.processPacketQueue=function(){if(this.packetBuffer.length>0&&!this.encoding){var pack=this.packetBuffer.shift();this.packet(pack)}};Manager.prototype.cleanup=function(){var sub;while(sub=this.subs.shift())sub.destroy();this.packetBuffer=[];this.encoding=false;this.decoder.destroy()};Manager.prototype.close=Manager.prototype.disconnect=function(){this.skipReconnect=true;this.backoff.reset();this.readyState="closed";this.engine&&this.engine.close()};Manager.prototype.onclose=function(reason){debug("close");this.cleanup();this.backoff.reset();this.readyState="closed";this.emit("close",reason);if(this._reconnection&&!this.skipReconnect){this.reconnect()}};Manager.prototype.reconnect=function(){if(this.reconnecting||this.skipReconnect)return this;var self=this;if(this.backoff.attempts>=this._reconnectionAttempts){debug("reconnect failed");this.backoff.reset();this.emitAll("reconnect_failed");this.reconnecting=false}else{var delay=this.backoff.duration();debug("will wait %dms before reconnect attempt",delay);this.reconnecting=true;var timer=setTimeout(function(){if(self.skipReconnect)return;debug("attempting reconnect");self.emitAll("reconnect_attempt",self.backoff.attempts);self.emitAll("reconnecting",self.backoff.attempts);if(self.skipReconnect)return;self.open(function(err){if(err){debug("reconnect attempt error");self.reconnecting=false;self.reconnect();self.emitAll("reconnect_error",err.data)}else{debug("reconnect success");self.onreconnect()}})},delay);this.subs.push({destroy:function(){clearTimeout(timer)}})}};Manager.prototype.onreconnect=function(){var attempt=this.backoff.attempts;this.reconnecting=false;this.backoff.reset();this.updateSocketIds();this.emitAll("reconnect",attempt)}},{"./on":4,"./socket":5,"./url":6,backo2:7,"component-bind":8,"component-emitter":9,debug:10,"engine.io-client":11,indexof:42,"object-component":43,"socket.io-parser":46}],4:[function(_dereq_,module,exports){module.exports=on;function on(obj,ev,fn){obj.on(ev,fn);return{destroy:function(){obj.removeListener(ev,fn)}}}},{}],5:[function(_dereq_,module,exports){var parser=_dereq_("socket.io-parser");var Emitter=_dereq_("component-emitter");var toArray=_dereq_("to-array");var on=_dereq_("./on");var bind=_dereq_("component-bind");var debug=_dereq_("debug")("socket.io-client:socket");var hasBin=_dereq_("has-binary");module.exports=exports=Socket;var events={connect:1,connect_error:1,connect_timeout:1,disconnect:1,error:1,reconnect:1,reconnect_attempt:1,reconnect_failed:1,reconnect_error:1,reconnecting:1};var emit=Emitter.prototype.emit;function Socket(io,nsp){this.io=io;this.nsp=nsp;this.json=this;this.ids=0;this.acks={};if(this.io.autoConnect)this.open();this.receiveBuffer=[];this.sendBuffer=[];this.connected=false;this.disconnected=true}Emitter(Socket.prototype);Socket.prototype.subEvents=function(){if(this.subs)return;var io=this.io;this.subs=[on(io,"open",bind(this,"onopen")),on(io,"packet",bind(this,"onpacket")),on(io,"close",bind(this,"onclose"))]};Socket.prototype.open=Socket.prototype.connect=function(){if(this.connected)return this;this.subEvents();this.io.open();if("open"==this.io.readyState)this.onopen();return this};Socket.prototype.send=function(){var args=toArray(arguments);args.unshift("message");this.emit.apply(this,args);return this};Socket.prototype.emit=function(ev){if(events.hasOwnProperty(ev)){emit.apply(this,arguments);return this}var args=toArray(arguments);var parserType=parser.EVENT;if(hasBin(args)){parserType=parser.BINARY_EVENT}var packet={type:parserType,data:args};if("function"==typeof args[args.length-1]){debug("emitting packet with ack id %d",this.ids);this.acks[this.ids]=args.pop();packet.id=this.ids++}if(this.connected){this.packet(packet)}else{this.sendBuffer.push(packet)}return this};Socket.prototype.packet=function(packet){packet.nsp=this.nsp;this.io.packet(packet)};Socket.prototype.onopen=function(){debug("transport is open - connecting");if("/"!=this.nsp){this.packet({type:parser.CONNECT})}};Socket.prototype.onclose=function(reason){debug("close (%s)",reason);this.connected=false;this.disconnected=true;delete this.id;this.emit("disconnect",reason)};Socket.prototype.onpacket=function(packet){if(packet.nsp!=this.nsp)return;switch(packet.type){case parser.CONNECT:this.onconnect();break;case parser.EVENT:this.onevent(packet);break;case parser.BINARY_EVENT:this.onevent(packet);break;case parser.ACK:this.onack(packet);break;case parser.BINARY_ACK:this.onack(packet);break;case parser.DISCONNECT:this.ondisconnect();break;case parser.ERROR:this.emit("error",packet.data);break}};Socket.prototype.onevent=function(packet){var args=packet.data||[];debug("emitting event %j",args);if(null!=packet.id){debug("attaching ack callback to event");args.push(this.ack(packet.id))}if(this.connected){emit.apply(this,args)}else{this.receiveBuffer.push(args)}};Socket.prototype.ack=function(id){var self=this;var sent=false;return function(){if(sent)return;sent=true;var args=toArray(arguments);debug("sending ack %j",args);var type=hasBin(args)?parser.BINARY_ACK:parser.ACK;self.packet({type:type,id:id,data:args})}};Socket.prototype.onack=function(packet){debug("calling ack %s with %j",packet.id,packet.data);var fn=this.acks[packet.id];fn.apply(this,packet.data);delete this.acks[packet.id]};Socket.prototype.onconnect=function(){this.connected=true;this.disconnected=false;this.emit("connect");this.emitBuffered()};Socket.prototype.emitBuffered=function(){var i;for(i=0;i<this.receiveBuffer.length;i++){emit.apply(this,this.receiveBuffer[i])}this.receiveBuffer=[];for(i=0;i<this.sendBuffer.length;i++){this.packet(this.sendBuffer[i])}this.sendBuffer=[]};Socket.prototype.ondisconnect=function(){debug("server disconnect (%s)",this.nsp);this.destroy();this.onclose("io server disconnect")};Socket.prototype.destroy=function(){if(this.subs){for(var i=0;i<this.subs.length;i++){this.subs[i].destroy()}this.subs=null}this.io.destroy(this)};Socket.prototype.close=Socket.prototype.disconnect=function(){if(this.connected){debug("performing disconnect (%s)",this.nsp);this.packet({type:parser.DISCONNECT})}this.destroy();if(this.connected){this.onclose("io client disconnect")}return this}},{"./on":4,"component-bind":8,"component-emitter":9,debug:10,"has-binary":38,"socket.io-parser":46,"to-array":50}],6:[function(_dereq_,module,exports){(function(global){var parseuri=_dereq_("parseuri");var debug=_dereq_("debug")("socket.io-client:url");module.exports=url;function url(uri,loc){var obj=uri;var loc=loc||global.location;if(null==uri)uri=loc.protocol+"//"+loc.host;if("string"==typeof uri){if("/"==uri.charAt(0)){if("/"==uri.charAt(1)){uri=loc.protocol+uri}else{uri=loc.hostname+uri}}if(!/^(https?|wss?):\/\//.test(uri)){debug("protocol-less url %s",uri);if("undefined"!=typeof loc){uri=loc.protocol+"//"+uri}else{uri="https://"+uri}}debug("parse %s",uri);obj=parseuri(uri)}if(!obj.port){if(/^(http|ws)$/.test(obj.protocol)){obj.port="80"}else if(/^(http|ws)s$/.test(obj.protocol)){obj.port="443"}}obj.path=obj.path||"/";obj.id=obj.protocol+"://"+obj.host+":"+obj.port;obj.href=obj.protocol+"://"+obj.host+(loc&&loc.port==obj.port?"":":"+obj.port);return obj}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{debug:10,parseuri:44}],7:[function(_dereq_,module,exports){module.exports=Backoff;function Backoff(opts){opts=opts||{};this.ms=opts.min||100;this.max=opts.max||1e4;this.factor=opts.factor||2;this.jitter=opts.jitter>0&&opts.jitter<=1?opts.jitter:0;this.attempts=0}Backoff.prototype.duration=function(){var ms=this.ms*Math.pow(this.factor,this.attempts++);if(this.jitter){var rand=Math.random();var deviation=Math.floor(rand*this.jitter*ms);ms=(Math.floor(rand*10)&1)==0?ms-deviation:ms+deviation}return Math.min(ms,this.max)|0};Backoff.prototype.reset=function(){this.attempts=0};Backoff.prototype.setMin=function(min){this.ms=min};Backoff.prototype.setMax=function(max){this.max=max};Backoff.prototype.setJitter=function(jitter){this.jitter=jitter}},{}],8:[function(_dereq_,module,exports){var slice=[].slice;module.exports=function(obj,fn){if("string"==typeof fn)fn=obj[fn];if("function"!=typeof fn)throw new Error("bind() requires a function");var args=slice.call(arguments,2);return function(){return fn.apply(obj,args.concat(slice.call(arguments)))}}},{}],9:[function(_dereq_,module,exports){module.exports=Emitter;function Emitter(obj){if(obj)return mixin(obj)}function mixin(obj){for(var key in Emitter.prototype){obj[key]=Emitter.prototype[key]}return obj}Emitter.prototype.on=Emitter.prototype.addEventListener=function(event,fn){this._callbacks=this._callbacks||{};(this._callbacks[event]=this._callbacks[event]||[]).push(fn);return this};Emitter.prototype.once=function(event,fn){var self=this;this._callbacks=this._callbacks||{};function on(){self.off(event,on);fn.apply(this,arguments)}on.fn=fn;this.on(event,on);return this};Emitter.prototype.off=Emitter.prototype.removeListener=Emitter.prototype.removeAllListeners=Emitter.prototype.removeEventListener=function(event,fn){this._callbacks=this._callbacks||{};if(0==arguments.length){this._callbacks={};return this}var callbacks=this._callbacks[event];if(!callbacks)return this;if(1==arguments.length){delete this._callbacks[event];return this}var cb;for(var i=0;i<callbacks.length;i++){cb=callbacks[i];if(cb===fn||cb.fn===fn){callbacks.splice(i,1);break}}return this};Emitter.prototype.emit=function(event){this._callbacks=this._callbacks||{};var args=[].slice.call(arguments,1),callbacks=this._callbacks[event];if(callbacks){callbacks=callbacks.slice(0);for(var i=0,len=callbacks.length;i<len;++i){callbacks[i].apply(this,args)}}return this};Emitter.prototype.listeners=function(event){this._callbacks=this._callbacks||{};return this._callbacks[event]||[]};Emitter.prototype.hasListeners=function(event){return!!this.listeners(event).length}},{}],10:[function(_dereq_,module,exports){module.exports=debug;function debug(name){if(!debug.enabled(name))return function(){};return function(fmt){fmt=coerce(fmt);var curr=new Date;var ms=curr-(debug[name]||curr);debug[name]=curr;fmt=name+" "+fmt+" +"+debug.humanize(ms);window.console&&console.log&&Function.prototype.apply.call(console.log,console,arguments)}}debug.names=[];debug.skips=[];debug.enable=function(name){try{localStorage.debug=name}catch(e){}var split=(name||"").split(/[\s,]+/),len=split.length;for(var i=0;i<len;i++){name=split[i].replace("*",".*?");if(name[0]==="-"){debug.skips.push(new RegExp("^"+name.substr(1)+"$"))}else{debug.names.push(new RegExp("^"+name+"$"))}}};debug.disable=function(){debug.enable("")};debug.humanize=function(ms){var sec=1e3,min=60*1e3,hour=60*min;if(ms>=hour)return(ms/hour).toFixed(1)+"h";if(ms>=min)return(ms/min).toFixed(1)+"m";if(ms>=sec)return(ms/sec|0)+"s";return ms+"ms"};debug.enabled=function(name){for(var i=0,len=debug.skips.length;i<len;i++){if(debug.skips[i].test(name)){return false}}for(var i=0,len=debug.names.length;i<len;i++){if(debug.names[i].test(name)){return true}}return false};function coerce(val){if(val instanceof Error)return val.stack||val.message;return val}try{if(window.localStorage)debug.enable(localStorage.debug)}catch(e){}},{}],11:[function(_dereq_,module,exports){module.exports=_dereq_("./lib/")},{"./lib/":12}],12:[function(_dereq_,module,exports){module.exports=_dereq_("./socket");module.exports.parser=_dereq_("engine.io-parser")},{"./socket":13,"engine.io-parser":25}],13:[function(_dereq_,module,exports){(function(global){var transports=_dereq_("./transports");var Emitter=_dereq_("component-emitter");var debug=_dereq_("debug")("engine.io-client:socket");var index=_dereq_("indexof");var parser=_dereq_("engine.io-parser");var parseuri=_dereq_("parseuri");var parsejson=_dereq_("parsejson");var parseqs=_dereq_("parseqs");module.exports=Socket;function noop(){}function Socket(uri,opts){if(!(this instanceof Socket))return new Socket(uri,opts);opts=opts||{};if(uri&&"object"==typeof uri){opts=uri;uri=null}if(uri){uri=parseuri(uri);opts.host=uri.host;opts.secure=uri.protocol=="https"||uri.protocol=="wss";opts.port=uri.port;if(uri.query)opts.query=uri.query}this.secure=null!=opts.secure?opts.secure:global.location&&"https:"==location.protocol;if(opts.host){var pieces=opts.host.split(":");opts.hostname=pieces.shift();if(pieces.length){opts.port=pieces.pop()}else if(!opts.port){opts.port=this.secure?"443":"80"}}this.agent=opts.agent||false;this.hostname=opts.hostname||(global.location?location.hostname:"localhost");this.port=opts.port||(global.location&&location.port?location.port:this.secure?443:80);this.query=opts.query||{};if("string"==typeof this.query)this.query=parseqs.decode(this.query);this.upgrade=false!==opts.upgrade;this.path=(opts.path||"/engine.io").replace(/\/$/,"")+"/";this.forceJSONP=!!opts.forceJSONP;this.jsonp=false!==opts.jsonp;this.forceBase64=!!opts.forceBase64;this.enablesXDR=!!opts.enablesXDR;this.timestampParam=opts.timestampParam||"t";this.timestampRequests=opts.timestampRequests;this.transports=opts.transports||["polling","websocket"];this.readyState="";this.writeBuffer=[];this.callbackBuffer=[];this.policyPort=opts.policyPort||843;this.rememberUpgrade=opts.rememberUpgrade||false;this.binaryType=null;this.onlyBinaryUpgrades=opts.onlyBinaryUpgrades;this.pfx=opts.pfx||null;this.key=opts.key||null;this.passphrase=opts.passphrase||null;this.cert=opts.cert||null;this.ca=opts.ca||null;this.ciphers=opts.ciphers||null;this.rejectUnauthorized=opts.rejectUnauthorized||null;this.open()}Socket.priorWebsocketSuccess=false;Emitter(Socket.prototype);Socket.protocol=parser.protocol;Socket.Socket=Socket;Socket.Transport=_dereq_("./transport");Socket.transports=_dereq_("./transports");Socket.parser=_dereq_("engine.io-parser");Socket.prototype.createTransport=function(name){debug('creating transport "%s"',name);var query=clone(this.query);query.EIO=parser.protocol;query.transport=name;if(this.id)query.sid=this.id;var transport=new transports[name]({agent:this.agent,hostname:this.hostname,port:this.port,secure:this.secure,path:this.path,query:query,forceJSONP:this.forceJSONP,jsonp:this.jsonp,forceBase64:this.forceBase64,enablesXDR:this.enablesXDR,timestampRequests:this.timestampRequests,timestampParam:this.timestampParam,policyPort:this.policyPort,socket:this,pfx:this.pfx,key:this.key,passphrase:this.passphrase,cert:this.cert,ca:this.ca,ciphers:this.ciphers,rejectUnauthorized:this.rejectUnauthorized});return transport};function clone(obj){var o={};for(var i in obj){if(obj.hasOwnProperty(i)){o[i]=obj[i]}}return o}Socket.prototype.open=function(){var transport;if(this.rememberUpgrade&&Socket.priorWebsocketSuccess&&this.transports.indexOf("websocket")!=-1){transport="websocket"}else if(0==this.transports.length){var self=this;setTimeout(function(){self.emit("error","No transports available")},0);return}else{transport=this.transports[0]}this.readyState="opening";var transport;try{transport=this.createTransport(transport)}catch(e){this.transports.shift();this.open();return}transport.open();this.setTransport(transport)};Socket.prototype.setTransport=function(transport){debug("setting transport %s",transport.name);var self=this;if(this.transport){debug("clearing existing transport %s",this.transport.name);this.transport.removeAllListeners()}this.transport=transport;transport.on("drain",function(){self.onDrain()}).on("packet",function(packet){self.onPacket(packet)}).on("error",function(e){self.onError(e)}).on("close",function(){self.onClose("transport close")})};Socket.prototype.probe=function(name){debug('probing transport "%s"',name);var transport=this.createTransport(name,{probe:1}),failed=false,self=this;Socket.priorWebsocketSuccess=false;function onTransportOpen(){if(self.onlyBinaryUpgrades){var upgradeLosesBinary=!this.supportsBinary&&self.transport.supportsBinary;failed=failed||upgradeLosesBinary}if(failed)return;debug('probe transport "%s" opened',name);transport.send([{type:"ping",data:"probe"}]);transport.once("packet",function(msg){if(failed)return;if("pong"==msg.type&&"probe"==msg.data){debug('probe transport "%s" pong',name);self.upgrading=true;self.emit("upgrading",transport);if(!transport)return;Socket.priorWebsocketSuccess="websocket"==transport.name;debug('pausing current transport "%s"',self.transport.name);self.transport.pause(function(){if(failed)return;if("closed"==self.readyState)return;debug("changing transport and sending upgrade packet");cleanup();self.setTransport(transport);transport.send([{type:"upgrade"}]);self.emit("upgrade",transport);transport=null;self.upgrading=false;self.flush()})}else{debug('probe transport "%s" failed',name);var err=new Error("probe error");err.transport=transport.name;self.emit("upgradeError",err)}})}function freezeTransport(){if(failed)return;failed=true;cleanup();transport.close();transport=null}function onerror(err){var error=new Error("probe error: "+err);error.transport=transport.name;freezeTransport();debug('probe transport "%s" failed because of error: %s',name,err);self.emit("upgradeError",error)}function onTransportClose(){onerror("transport closed")}function onclose(){onerror("socket closed")}function onupgrade(to){if(transport&&to.name!=transport.name){debug('"%s" works - aborting "%s"',to.name,transport.name);freezeTransport()}}function cleanup(){transport.removeListener("open",onTransportOpen);transport.removeListener("error",onerror);transport.removeListener("close",onTransportClose);self.removeListener("close",onclose);self.removeListener("upgrading",onupgrade)}transport.once("open",onTransportOpen);transport.once("error",onerror);transport.once("close",onTransportClose);this.once("close",onclose);this.once("upgrading",onupgrade);transport.open()};Socket.prototype.onOpen=function(){debug("socket open");this.readyState="open";Socket.priorWebsocketSuccess="websocket"==this.transport.name;this.emit("open");this.flush();if("open"==this.readyState&&this.upgrade&&this.transport.pause){debug("starting upgrade probes");for(var i=0,l=this.upgrades.length;i<l;i++){this.probe(this.upgrades[i])}}};Socket.prototype.onPacket=function(packet){if("opening"==this.readyState||"open"==this.readyState){debug('socket receive: type "%s", data "%s"',packet.type,packet.data);this.emit("packet",packet);this.emit("heartbeat");switch(packet.type){case"open":this.onHandshake(parsejson(packet.data));break;case"pong":this.setPing();break;case"error":var err=new Error("server error");err.code=packet.data;this.emit("error",err);break;case"message":this.emit("data",packet.data);this.emit("message",packet.data);break}}else{debug('packet received with socket readyState "%s"',this.readyState)}};Socket.prototype.onHandshake=function(data){this.emit("handshake",data);this.id=data.sid;this.transport.query.sid=data.sid;this.upgrades=this.filterUpgrades(data.upgrades);this.pingInterval=data.pingInterval;this.pingTimeout=data.pingTimeout;this.onOpen();if("closed"==this.readyState)return;this.setPing();this.removeListener("heartbeat",this.onHeartbeat);this.on("heartbeat",this.onHeartbeat)};Socket.prototype.onHeartbeat=function(timeout){clearTimeout(this.pingTimeoutTimer);var self=this;self.pingTimeoutTimer=setTimeout(function(){if("closed"==self.readyState)return;self.onClose("ping timeout")},timeout||self.pingInterval+self.pingTimeout)};Socket.prototype.setPing=function(){var self=this;clearTimeout(self.pingIntervalTimer);self.pingIntervalTimer=setTimeout(function(){debug("writing ping packet - expecting pong within %sms",self.pingTimeout);self.ping();self.onHeartbeat(self.pingTimeout)},self.pingInterval)};Socket.prototype.ping=function(){this.sendPacket("ping")};Socket.prototype.onDrain=function(){for(var i=0;i<this.prevBufferLen;i++){if(this.callbackBuffer[i]){this.callbackBuffer[i]()}}this.writeBuffer.splice(0,this.prevBufferLen);this.callbackBuffer.splice(0,this.prevBufferLen);this.prevBufferLen=0;if(this.writeBuffer.length==0){this.emit("drain")}else{this.flush()}};Socket.prototype.flush=function(){if("closed"!=this.readyState&&this.transport.writable&&!this.upgrading&&this.writeBuffer.length){debug("flushing %d packets in socket",this.writeBuffer.length);this.transport.send(this.writeBuffer);this.prevBufferLen=this.writeBuffer.length;this.emit("flush")}};Socket.prototype.write=Socket.prototype.send=function(msg,fn){this.sendPacket("message",msg,fn);return this};Socket.prototype.sendPacket=function(type,data,fn){if("closing"==this.readyState||"closed"==this.readyState){return}var packet={type:type,data:data};this.emit("packetCreate",packet);this.writeBuffer.push(packet);this.callbackBuffer.push(fn);this.flush()};Socket.prototype.close=function(){if("opening"==this.readyState||"open"==this.readyState){this.readyState="closing";var self=this;function close(){self.onClose("forced close");debug("socket closing - telling transport to close");self.transport.close()}function cleanupAndClose(){self.removeListener("upgrade",cleanupAndClose);self.removeListener("upgradeError",cleanupAndClose);close()}function waitForUpgrade(){self.once("upgrade",cleanupAndClose);self.once("upgradeError",cleanupAndClose)}if(this.writeBuffer.length){this.once("drain",function(){if(this.upgrading){waitForUpgrade()}else{close()}})}else if(this.upgrading){waitForUpgrade()}else{close()}}return this};Socket.prototype.onError=function(err){debug("socket error %j",err);Socket.priorWebsocketSuccess=false;this.emit("error",err);this.onClose("transport error",err)};Socket.prototype.onClose=function(reason,desc){if("opening"==this.readyState||"open"==this.readyState||"closing"==this.readyState){debug('socket close with reason: "%s"',reason);var self=this;clearTimeout(this.pingIntervalTimer);clearTimeout(this.pingTimeoutTimer);setTimeout(function(){self.writeBuffer=[];self.callbackBuffer=[];self.prevBufferLen=0},0);this.transport.removeAllListeners("close");this.transport.close();this.transport.removeAllListeners();this.readyState="closed";this.id=null;this.emit("close",reason,desc)}};Socket.prototype.filterUpgrades=function(upgrades){var filteredUpgrades=[];for(var i=0,j=upgrades.length;i<j;i++){if(~index(this.transports,upgrades[i]))filteredUpgrades.push(upgrades[i])}return filteredUpgrades}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./transport":14,"./transports":15,"component-emitter":9,debug:22,"engine.io-parser":25,indexof:42,parsejson:34,parseqs:35,parseuri:36}],14:[function(_dereq_,module,exports){var parser=_dereq_("engine.io-parser");var Emitter=_dereq_("component-emitter");module.exports=Transport;function Transport(opts){this.path=opts.path;this.hostname=opts.hostname;this.port=opts.port;this.secure=opts.secure;this.query=opts.query;this.timestampParam=opts.timestampParam;this.timestampRequests=opts.timestampRequests;this.readyState="";this.agent=opts.agent||false;this.socket=opts.socket;this.enablesXDR=opts.enablesXDR;this.pfx=opts.pfx;this.key=opts.key;this.passphrase=opts.passphrase;this.cert=opts.cert;this.ca=opts.ca;this.ciphers=opts.ciphers;this.rejectUnauthorized=opts.rejectUnauthorized}Emitter(Transport.prototype);Transport.timestamps=0;Transport.prototype.onError=function(msg,desc){var err=new Error(msg);err.type="TransportError";err.description=desc;this.emit("error",err);return this};Transport.prototype.open=function(){if("closed"==this.readyState||""==this.readyState){this.readyState="opening";this.doOpen()}return this};Transport.prototype.close=function(){if("opening"==this.readyState||"open"==this.readyState){this.doClose();this.onClose()}return this};Transport.prototype.send=function(packets){if("open"==this.readyState){this.write(packets)}else{throw new Error("Transport not open")}};Transport.prototype.onOpen=function(){this.readyState="open";this.writable=true;this.emit("open")};Transport.prototype.onData=function(data){var packet=parser.decodePacket(data,this.socket.binaryType);this.onPacket(packet)};Transport.prototype.onPacket=function(packet){this.emit("packet",packet)};Transport.prototype.onClose=function(){this.readyState="closed";this.emit("close")}},{"component-emitter":9,"engine.io-parser":25}],15:[function(_dereq_,module,exports){(function(global){var XMLHttpRequest=_dereq_("xmlhttprequest");var XHR=_dereq_("./polling-xhr");var JSONP=_dereq_("./polling-jsonp");var websocket=_dereq_("./websocket");exports.polling=polling;exports.websocket=websocket;function polling(opts){var xhr;var xd=false;var xs=false;var jsonp=false!==opts.jsonp;if(global.location){var isSSL="https:"==location.protocol;var port=location.port;if(!port){port=isSSL?443:80}xd=opts.hostname!=location.hostname||port!=opts.port;xs=opts.secure!=isSSL}opts.xdomain=xd;opts.xscheme=xs;xhr=new XMLHttpRequest(opts);if("open"in xhr&&!opts.forceJSONP){return new XHR(opts)}else{if(!jsonp)throw new Error("JSONP disabled");return new JSONP(opts)}}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./polling-jsonp":16,"./polling-xhr":17,"./websocket":19,xmlhttprequest:20}],16:[function(_dereq_,module,exports){(function(global){var Polling=_dereq_("./polling");var inherit=_dereq_("component-inherit");module.exports=JSONPPolling;var rNewline=/\n/g;var rEscapedNewline=/\\n/g;var callbacks;var index=0;function empty(){}function JSONPPolling(opts){Polling.call(this,opts);
this.query=this.query||{};if(!callbacks){if(!global.___eio)global.___eio=[];callbacks=global.___eio}this.index=callbacks.length;var self=this;callbacks.push(function(msg){self.onData(msg)});this.query.j=this.index;if(global.document&&global.addEventListener){global.addEventListener("beforeunload",function(){if(self.script)self.script.onerror=empty},false)}}inherit(JSONPPolling,Polling);JSONPPolling.prototype.supportsBinary=false;JSONPPolling.prototype.doClose=function(){if(this.script){this.script.parentNode.removeChild(this.script);this.script=null}if(this.form){this.form.parentNode.removeChild(this.form);this.form=null;this.iframe=null}Polling.prototype.doClose.call(this)};JSONPPolling.prototype.doPoll=function(){var self=this;var script=document.createElement("script");if(this.script){this.script.parentNode.removeChild(this.script);this.script=null}script.async=true;script.src=this.uri();script.onerror=function(e){self.onError("jsonp poll error",e)};var insertAt=document.getElementsByTagName("script")[0];insertAt.parentNode.insertBefore(script,insertAt);this.script=script;var isUAgecko="undefined"!=typeof navigator&&/gecko/i.test(navigator.userAgent);if(isUAgecko){setTimeout(function(){var iframe=document.createElement("iframe");document.body.appendChild(iframe);document.body.removeChild(iframe)},100)}};JSONPPolling.prototype.doWrite=function(data,fn){var self=this;if(!this.form){var form=document.createElement("form");var area=document.createElement("textarea");var id=this.iframeId="eio_iframe_"+this.index;var iframe;form.className="socketio";form.style.position="absolute";form.style.top="-1000px";form.style.left="-1000px";form.target=id;form.method="POST";form.setAttribute("accept-charset","utf-8");area.name="d";form.appendChild(area);document.body.appendChild(form);this.form=form;this.area=area}this.form.action=this.uri();function complete(){initIframe();fn()}function initIframe(){if(self.iframe){try{self.form.removeChild(self.iframe)}catch(e){self.onError("jsonp polling iframe removal error",e)}}try{var html='<iframe src="javascript:0" name="'+self.iframeId+'">';iframe=document.createElement(html)}catch(e){iframe=document.createElement("iframe");iframe.name=self.iframeId;iframe.src="javascript:0"}iframe.id=self.iframeId;self.form.appendChild(iframe);self.iframe=iframe}initIframe();data=data.replace(rEscapedNewline,"\\\n");this.area.value=data.replace(rNewline,"\\n");try{this.form.submit()}catch(e){}if(this.iframe.attachEvent){this.iframe.onreadystatechange=function(){if(self.iframe.readyState=="complete"){complete()}}}else{this.iframe.onload=complete}}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./polling":18,"component-inherit":21}],17:[function(_dereq_,module,exports){(function(global){var XMLHttpRequest=_dereq_("xmlhttprequest");var Polling=_dereq_("./polling");var Emitter=_dereq_("component-emitter");var inherit=_dereq_("component-inherit");var debug=_dereq_("debug")("engine.io-client:polling-xhr");module.exports=XHR;module.exports.Request=Request;function empty(){}function XHR(opts){Polling.call(this,opts);if(global.location){var isSSL="https:"==location.protocol;var port=location.port;if(!port){port=isSSL?443:80}this.xd=opts.hostname!=global.location.hostname||port!=opts.port;this.xs=opts.secure!=isSSL}}inherit(XHR,Polling);XHR.prototype.supportsBinary=true;XHR.prototype.request=function(opts){opts=opts||{};opts.uri=this.uri();opts.xd=this.xd;opts.xs=this.xs;opts.agent=this.agent||false;opts.supportsBinary=this.supportsBinary;opts.enablesXDR=this.enablesXDR;opts.pfx=this.pfx;opts.key=this.key;opts.passphrase=this.passphrase;opts.cert=this.cert;opts.ca=this.ca;opts.ciphers=this.ciphers;opts.rejectUnauthorized=this.rejectUnauthorized;return new Request(opts)};XHR.prototype.doWrite=function(data,fn){var isBinary=typeof data!=="string"&&data!==undefined;var req=this.request({method:"POST",data:data,isBinary:isBinary});var self=this;req.on("success",fn);req.on("error",function(err){self.onError("xhr post error",err)});this.sendXhr=req};XHR.prototype.doPoll=function(){debug("xhr poll");var req=this.request();var self=this;req.on("data",function(data){self.onData(data)});req.on("error",function(err){self.onError("xhr poll error",err)});this.pollXhr=req};function Request(opts){this.method=opts.method||"GET";this.uri=opts.uri;this.xd=!!opts.xd;this.xs=!!opts.xs;this.async=false!==opts.async;this.data=undefined!=opts.data?opts.data:null;this.agent=opts.agent;this.isBinary=opts.isBinary;this.supportsBinary=opts.supportsBinary;this.enablesXDR=opts.enablesXDR;this.pfx=opts.pfx;this.key=opts.key;this.passphrase=opts.passphrase;this.cert=opts.cert;this.ca=opts.ca;this.ciphers=opts.ciphers;this.rejectUnauthorized=opts.rejectUnauthorized;this.create()}Emitter(Request.prototype);Request.prototype.create=function(){var opts={agent:this.agent,xdomain:this.xd,xscheme:this.xs,enablesXDR:this.enablesXDR};opts.pfx=this.pfx;opts.key=this.key;opts.passphrase=this.passphrase;opts.cert=this.cert;opts.ca=this.ca;opts.ciphers=this.ciphers;opts.rejectUnauthorized=this.rejectUnauthorized;var xhr=this.xhr=new XMLHttpRequest(opts);var self=this;try{debug("xhr open %s: %s",this.method,this.uri);xhr.open(this.method,this.uri,this.async);if(this.supportsBinary){xhr.responseType="arraybuffer"}if("POST"==this.method){try{if(this.isBinary){xhr.setRequestHeader("Content-type","application/octet-stream")}else{xhr.setRequestHeader("Content-type","text/plain;charset=UTF-8")}}catch(e){}}if("withCredentials"in xhr){xhr.withCredentials=true}if(this.hasXDR()){xhr.onload=function(){self.onLoad()};xhr.onerror=function(){self.onError(xhr.responseText)}}else{xhr.onreadystatechange=function(){if(4!=xhr.readyState)return;if(200==xhr.status||1223==xhr.status){self.onLoad()}else{setTimeout(function(){self.onError(xhr.status)},0)}}}debug("xhr data %s",this.data);xhr.send(this.data)}catch(e){setTimeout(function(){self.onError(e)},0);return}if(global.document){this.index=Request.requestsCount++;Request.requests[this.index]=this}};Request.prototype.onSuccess=function(){this.emit("success");this.cleanup()};Request.prototype.onData=function(data){this.emit("data",data);this.onSuccess()};Request.prototype.onError=function(err){this.emit("error",err);this.cleanup(true)};Request.prototype.cleanup=function(fromError){if("undefined"==typeof this.xhr||null===this.xhr){return}if(this.hasXDR()){this.xhr.onload=this.xhr.onerror=empty}else{this.xhr.onreadystatechange=empty}if(fromError){try{this.xhr.abort()}catch(e){}}if(global.document){delete Request.requests[this.index]}this.xhr=null};Request.prototype.onLoad=function(){var data;try{var contentType;try{contentType=this.xhr.getResponseHeader("Content-Type").split(";")[0]}catch(e){}if(contentType==="application/octet-stream"){data=this.xhr.response}else{if(!this.supportsBinary){data=this.xhr.responseText}else{data="ok"}}}catch(e){this.onError(e)}if(null!=data){this.onData(data)}};Request.prototype.hasXDR=function(){return"undefined"!==typeof global.XDomainRequest&&!this.xs&&this.enablesXDR};Request.prototype.abort=function(){this.cleanup()};if(global.document){Request.requestsCount=0;Request.requests={};if(global.attachEvent){global.attachEvent("onunload",unloadHandler)}else if(global.addEventListener){global.addEventListener("beforeunload",unloadHandler,false)}}function unloadHandler(){for(var i in Request.requests){if(Request.requests.hasOwnProperty(i)){Request.requests[i].abort()}}}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./polling":18,"component-emitter":9,"component-inherit":21,debug:22,xmlhttprequest:20}],18:[function(_dereq_,module,exports){var Transport=_dereq_("../transport");var parseqs=_dereq_("parseqs");var parser=_dereq_("engine.io-parser");var inherit=_dereq_("component-inherit");var debug=_dereq_("debug")("engine.io-client:polling");module.exports=Polling;var hasXHR2=function(){var XMLHttpRequest=_dereq_("xmlhttprequest");var xhr=new XMLHttpRequest({xdomain:false});return null!=xhr.responseType}();function Polling(opts){var forceBase64=opts&&opts.forceBase64;if(!hasXHR2||forceBase64){this.supportsBinary=false}Transport.call(this,opts)}inherit(Polling,Transport);Polling.prototype.name="polling";Polling.prototype.doOpen=function(){this.poll()};Polling.prototype.pause=function(onPause){var pending=0;var self=this;this.readyState="pausing";function pause(){debug("paused");self.readyState="paused";onPause()}if(this.polling||!this.writable){var total=0;if(this.polling){debug("we are currently polling - waiting to pause");total++;this.once("pollComplete",function(){debug("pre-pause polling complete");--total||pause()})}if(!this.writable){debug("we are currently writing - waiting to pause");total++;this.once("drain",function(){debug("pre-pause writing complete");--total||pause()})}}else{pause()}};Polling.prototype.poll=function(){debug("polling");this.polling=true;this.doPoll();this.emit("poll")};Polling.prototype.onData=function(data){var self=this;debug("polling got data %s",data);var callback=function(packet,index,total){if("opening"==self.readyState){self.onOpen()}if("close"==packet.type){self.onClose();return false}self.onPacket(packet)};parser.decodePayload(data,this.socket.binaryType,callback);if("closed"!=this.readyState){this.polling=false;this.emit("pollComplete");if("open"==this.readyState){this.poll()}else{debug('ignoring poll - transport state "%s"',this.readyState)}}};Polling.prototype.doClose=function(){var self=this;function close(){debug("writing close packet");self.write([{type:"close"}])}if("open"==this.readyState){debug("transport open - closing");close()}else{debug("transport not open - deferring close");this.once("open",close)}};Polling.prototype.write=function(packets){var self=this;this.writable=false;var callbackfn=function(){self.writable=true;self.emit("drain")};var self=this;parser.encodePayload(packets,this.supportsBinary,function(data){self.doWrite(data,callbackfn)})};Polling.prototype.uri=function(){var query=this.query||{};var schema=this.secure?"https":"http";var port="";if(false!==this.timestampRequests){query[this.timestampParam]=+new Date+"-"+Transport.timestamps++}if(!this.supportsBinary&&!query.sid){query.b64=1}query=parseqs.encode(query);if(this.port&&("https"==schema&&this.port!=443||"http"==schema&&this.port!=80)){port=":"+this.port}if(query.length){query="?"+query}return schema+"://"+this.hostname+port+this.path+query}},{"../transport":14,"component-inherit":21,debug:22,"engine.io-parser":25,parseqs:35,xmlhttprequest:20}],19:[function(_dereq_,module,exports){var Transport=_dereq_("../transport");var parser=_dereq_("engine.io-parser");var parseqs=_dereq_("parseqs");var inherit=_dereq_("component-inherit");var debug=_dereq_("debug")("engine.io-client:websocket");var WebSocket=_dereq_("ws");module.exports=WS;function WS(opts){var forceBase64=opts&&opts.forceBase64;if(forceBase64){this.supportsBinary=false}Transport.call(this,opts)}inherit(WS,Transport);WS.prototype.name="websocket";WS.prototype.supportsBinary=true;WS.prototype.doOpen=function(){if(!this.check()){return}var self=this;var uri=this.uri();var protocols=void 0;var opts={agent:this.agent};opts.pfx=this.pfx;opts.key=this.key;opts.passphrase=this.passphrase;opts.cert=this.cert;opts.ca=this.ca;opts.ciphers=this.ciphers;opts.rejectUnauthorized=this.rejectUnauthorized;this.ws=new WebSocket(uri,protocols,opts);if(this.ws.binaryType===undefined){this.supportsBinary=false}this.ws.binaryType="arraybuffer";this.addEventListeners()};WS.prototype.addEventListeners=function(){var self=this;this.ws.onopen=function(){self.onOpen()};this.ws.onclose=function(){self.onClose()};this.ws.onmessage=function(ev){self.onData(ev.data)};this.ws.onerror=function(e){self.onError("websocket error",e)}};if("undefined"!=typeof navigator&&/iPad|iPhone|iPod/i.test(navigator.userAgent)){WS.prototype.onData=function(data){var self=this;setTimeout(function(){Transport.prototype.onData.call(self,data)},0)}}WS.prototype.write=function(packets){var self=this;this.writable=false;for(var i=0,l=packets.length;i<l;i++){parser.encodePacket(packets[i],this.supportsBinary,function(data){try{self.ws.send(data)}catch(e){debug("websocket closed before onclose event")}})}function ondrain(){self.writable=true;self.emit("drain")}setTimeout(ondrain,0)};WS.prototype.onClose=function(){Transport.prototype.onClose.call(this)};WS.prototype.doClose=function(){if(typeof this.ws!=="undefined"){this.ws.close()}};WS.prototype.uri=function(){var query=this.query||{};var schema=this.secure?"wss":"ws";var port="";if(this.port&&("wss"==schema&&this.port!=443||"ws"==schema&&this.port!=80)){port=":"+this.port}if(this.timestampRequests){query[this.timestampParam]=+new Date}if(!this.supportsBinary){query.b64=1}query=parseqs.encode(query);if(query.length){query="?"+query}return schema+"://"+this.hostname+port+this.path+query};WS.prototype.check=function(){return!!WebSocket&&!("__initialize"in WebSocket&&this.name===WS.prototype.name)}},{"../transport":14,"component-inherit":21,debug:22,"engine.io-parser":25,parseqs:35,ws:37}],20:[function(_dereq_,module,exports){var hasCORS=_dereq_("has-cors");module.exports=function(opts){var xdomain=opts.xdomain;var xscheme=opts.xscheme;var enablesXDR=opts.enablesXDR;try{if("undefined"!=typeof XMLHttpRequest&&(!xdomain||hasCORS)){return new XMLHttpRequest}}catch(e){}try{if("undefined"!=typeof XDomainRequest&&!xscheme&&enablesXDR){return new XDomainRequest}}catch(e){}if(!xdomain){try{return new ActiveXObject("Microsoft.XMLHTTP")}catch(e){}}}},{"has-cors":40}],21:[function(_dereq_,module,exports){module.exports=function(a,b){var fn=function(){};fn.prototype=b.prototype;a.prototype=new fn;a.prototype.constructor=a}},{}],22:[function(_dereq_,module,exports){exports=module.exports=_dereq_("./debug");exports.log=log;exports.formatArgs=formatArgs;exports.save=save;exports.load=load;exports.useColors=useColors;exports.colors=["lightseagreen","forestgreen","goldenrod","dodgerblue","darkorchid","crimson"];function useColors(){return"WebkitAppearance"in document.documentElement.style||window.console&&(console.firebug||console.exception&&console.table)||navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)&&parseInt(RegExp.$1,10)>=31}exports.formatters.j=function(v){return JSON.stringify(v)};function formatArgs(){var args=arguments;var useColors=this.useColors;args[0]=(useColors?"%c":"")+this.namespace+(useColors?" %c":" ")+args[0]+(useColors?"%c ":" ")+"+"+exports.humanize(this.diff);if(!useColors)return args;var c="color: "+this.color;args=[args[0],c,"color: inherit"].concat(Array.prototype.slice.call(args,1));var index=0;var lastC=0;args[0].replace(/%[a-z%]/g,function(match){if("%"===match)return;index++;if("%c"===match){lastC=index}});args.splice(lastC,0,c);return args}function log(){return"object"==typeof console&&"function"==typeof console.log&&Function.prototype.apply.call(console.log,console,arguments)}function save(namespaces){try{if(null==namespaces){localStorage.removeItem("debug")}else{localStorage.debug=namespaces}}catch(e){}}function load(){var r;try{r=localStorage.debug}catch(e){}return r}exports.enable(load())},{"./debug":23}],23:[function(_dereq_,module,exports){exports=module.exports=debug;exports.coerce=coerce;exports.disable=disable;exports.enable=enable;exports.enabled=enabled;exports.humanize=_dereq_("ms");exports.names=[];exports.skips=[];exports.formatters={};var prevColor=0;var prevTime;function selectColor(){return exports.colors[prevColor++%exports.colors.length]}function debug(namespace){function disabled(){}disabled.enabled=false;function enabled(){var self=enabled;var curr=+new Date;var ms=curr-(prevTime||curr);self.diff=ms;self.prev=prevTime;self.curr=curr;prevTime=curr;if(null==self.useColors)self.useColors=exports.useColors();if(null==self.color&&self.useColors)self.color=selectColor();var args=Array.prototype.slice.call(arguments);args[0]=exports.coerce(args[0]);if("string"!==typeof args[0]){args=["%o"].concat(args)}var index=0;args[0]=args[0].replace(/%([a-z%])/g,function(match,format){if(match==="%")return match;index++;var formatter=exports.formatters[format];if("function"===typeof formatter){var val=args[index];match=formatter.call(self,val);args.splice(index,1);index--}return match});if("function"===typeof exports.formatArgs){args=exports.formatArgs.apply(self,args)}var logFn=enabled.log||exports.log||console.log.bind(console);logFn.apply(self,args)}enabled.enabled=true;var fn=exports.enabled(namespace)?enabled:disabled;fn.namespace=namespace;return fn}function enable(namespaces){exports.save(namespaces);var split=(namespaces||"").split(/[\s,]+/);var len=split.length;for(var i=0;i<len;i++){if(!split[i])continue;namespaces=split[i].replace(/\*/g,".*?");if(namespaces[0]==="-"){exports.skips.push(new RegExp("^"+namespaces.substr(1)+"$"))}else{exports.names.push(new RegExp("^"+namespaces+"$"))}}}function disable(){exports.enable("")}function enabled(name){var i,len;for(i=0,len=exports.skips.length;i<len;i++){if(exports.skips[i].test(name)){return false}}for(i=0,len=exports.names.length;i<len;i++){if(exports.names[i].test(name)){return true}}return false}function coerce(val){if(val instanceof Error)return val.stack||val.message;return val}},{ms:24}],24:[function(_dereq_,module,exports){var s=1e3;var m=s*60;var h=m*60;var d=h*24;var y=d*365.25;module.exports=function(val,options){options=options||{};if("string"==typeof val)return parse(val);return options.long?long(val):short(val)};function parse(str){var match=/^((?:\d+)?\.?\d+) *(ms|seconds?|s|minutes?|m|hours?|h|days?|d|years?|y)?$/i.exec(str);if(!match)return;var n=parseFloat(match[1]);var type=(match[2]||"ms").toLowerCase();switch(type){case"years":case"year":case"y":return n*y;case"days":case"day":case"d":return n*d;case"hours":case"hour":case"h":return n*h;case"minutes":case"minute":case"m":return n*m;case"seconds":case"second":case"s":return n*s;case"ms":return n}}function short(ms){if(ms>=d)return Math.round(ms/d)+"d";if(ms>=h)return Math.round(ms/h)+"h";if(ms>=m)return Math.round(ms/m)+"m";if(ms>=s)return Math.round(ms/s)+"s";return ms+"ms"}function long(ms){return plural(ms,d,"day")||plural(ms,h,"hour")||plural(ms,m,"minute")||plural(ms,s,"second")||ms+" ms"}function plural(ms,n,name){if(ms<n)return;if(ms<n*1.5)return Math.floor(ms/n)+" "+name;return Math.ceil(ms/n)+" "+name+"s"}},{}],25:[function(_dereq_,module,exports){(function(global){var keys=_dereq_("./keys");var hasBinary=_dereq_("has-binary");var sliceBuffer=_dereq_("arraybuffer.slice");var base64encoder=_dereq_("base64-arraybuffer");var after=_dereq_("after");var utf8=_dereq_("utf8");var isAndroid=navigator.userAgent.match(/Android/i);var isPhantomJS=/PhantomJS/i.test(navigator.userAgent);var dontSendBlobs=isAndroid||isPhantomJS;exports.protocol=3;var packets=exports.packets={open:0,close:1,ping:2,pong:3,message:4,upgrade:5,noop:6};var packetslist=keys(packets);var err={type:"error",data:"parser error"};var Blob=_dereq_("blob");exports.encodePacket=function(packet,supportsBinary,utf8encode,callback){if("function"==typeof supportsBinary){callback=supportsBinary;supportsBinary=false}if("function"==typeof utf8encode){callback=utf8encode;utf8encode=null}var data=packet.data===undefined?undefined:packet.data.buffer||packet.data;if(global.ArrayBuffer&&data instanceof ArrayBuffer){return encodeArrayBuffer(packet,supportsBinary,callback)}else if(Blob&&data instanceof global.Blob){return encodeBlob(packet,supportsBinary,callback)}if(data&&data.base64){return encodeBase64Object(packet,callback)}var encoded=packets[packet.type];if(undefined!==packet.data){encoded+=utf8encode?utf8.encode(String(packet.data)):String(packet.data)}return callback(""+encoded)};function encodeBase64Object(packet,callback){var message="b"+exports.packets[packet.type]+packet.data.data;return callback(message)}function encodeArrayBuffer(packet,supportsBinary,callback){if(!supportsBinary){return exports.encodeBase64Packet(packet,callback)}var data=packet.data;var contentArray=new Uint8Array(data);var resultBuffer=new Uint8Array(1+data.byteLength);resultBuffer[0]=packets[packet.type];for(var i=0;i<contentArray.length;i++){resultBuffer[i+1]=contentArray[i]}return callback(resultBuffer.buffer)}function encodeBlobAsArrayBuffer(packet,supportsBinary,callback){if(!supportsBinary){return exports.encodeBase64Packet(packet,callback)}var fr=new FileReader;fr.onload=function(){packet.data=fr.result;exports.encodePacket(packet,supportsBinary,true,callback)};return fr.readAsArrayBuffer(packet.data)}function encodeBlob(packet,supportsBinary,callback){if(!supportsBinary){return exports.encodeBase64Packet(packet,callback)}if(dontSendBlobs){return encodeBlobAsArrayBuffer(packet,supportsBinary,callback)}var length=new Uint8Array(1);length[0]=packets[packet.type];var blob=new Blob([length.buffer,packet.data]);return callback(blob)}exports.encodeBase64Packet=function(packet,callback){var message="b"+exports.packets[packet.type];if(Blob&&packet.data instanceof Blob){var fr=new FileReader;fr.onload=function(){var b64=fr.result.split(",")[1];callback(message+b64)};return fr.readAsDataURL(packet.data)}var b64data;try{b64data=String.fromCharCode.apply(null,new Uint8Array(packet.data))}catch(e){var typed=new Uint8Array(packet.data);var basic=new Array(typed.length);for(var i=0;i<typed.length;i++){basic[i]=typed[i]}b64data=String.fromCharCode.apply(null,basic)}message+=global.btoa(b64data);return callback(message)};exports.decodePacket=function(data,binaryType,utf8decode){if(typeof data=="string"||data===undefined){if(data.charAt(0)=="b"){return exports.decodeBase64Packet(data.substr(1),binaryType)}if(utf8decode){try{data=utf8.decode(data)}catch(e){return err}}var type=data.charAt(0);if(Number(type)!=type||!packetslist[type]){return err}if(data.length>1){return{type:packetslist[type],data:data.substring(1)}}else{return{type:packetslist[type]}}}var asArray=new Uint8Array(data);var type=asArray[0];var rest=sliceBuffer(data,1);if(Blob&&binaryType==="blob"){rest=new Blob([rest])}return{type:packetslist[type],data:rest}};exports.decodeBase64Packet=function(msg,binaryType){var type=packetslist[msg.charAt(0)];if(!global.ArrayBuffer){return{type:type,data:{base64:true,data:msg.substr(1)}}}var data=base64encoder.decode(msg.substr(1));if(binaryType==="blob"&&Blob){data=new Blob([data])}return{type:type,data:data}};exports.encodePayload=function(packets,supportsBinary,callback){if(typeof supportsBinary=="function"){callback=supportsBinary;supportsBinary=null}var isBinary=hasBinary(packets);if(supportsBinary&&isBinary){if(Blob&&!dontSendBlobs){return exports.encodePayloadAsBlob(packets,callback)}return exports.encodePayloadAsArrayBuffer(packets,callback)}if(!packets.length){return callback("0:")}function setLengthHeader(message){return message.length+":"+message}function encodeOne(packet,doneCallback){exports.encodePacket(packet,!isBinary?false:supportsBinary,true,function(message){doneCallback(null,setLengthHeader(message))})}map(packets,encodeOne,function(err,results){return callback(results.join(""))})};function map(ary,each,done){var result=new Array(ary.length);var next=after(ary.length,done);var eachWithIndex=function(i,el,cb){each(el,function(error,msg){result[i]=msg;cb(error,result)})};for(var i=0;i<ary.length;i++){eachWithIndex(i,ary[i],next)}}exports.decodePayload=function(data,binaryType,callback){if(typeof data!="string"){return exports.decodePayloadAsBinary(data,binaryType,callback)}if(typeof binaryType==="function"){callback=binaryType;binaryType=null}var packet;if(data==""){return callback(err,0,1)}var length="",n,msg;for(var i=0,l=data.length;i<l;i++){var chr=data.charAt(i);if(":"!=chr){length+=chr}else{if(""==length||length!=(n=Number(length))){return callback(err,0,1)}msg=data.substr(i+1,n);if(length!=msg.length){return callback(err,0,1)}if(msg.length){packet=exports.decodePacket(msg,binaryType,true);if(err.type==packet.type&&err.data==packet.data){return callback(err,0,1)}var ret=callback(packet,i+n,l);if(false===ret)return}i+=n;length=""}}if(length!=""){return callback(err,0,1)}};exports.encodePayloadAsArrayBuffer=function(packets,callback){if(!packets.length){return callback(new ArrayBuffer(0))}function encodeOne(packet,doneCallback){exports.encodePacket(packet,true,true,function(data){return doneCallback(null,data)})}map(packets,encodeOne,function(err,encodedPackets){var totalLength=encodedPackets.reduce(function(acc,p){var len;if(typeof p==="string"){len=p.length}else{len=p.byteLength}return acc+len.toString().length+len+2},0);var resultArray=new Uint8Array(totalLength);var bufferIndex=0;encodedPackets.forEach(function(p){var isString=typeof p==="string";var ab=p;if(isString){var view=new Uint8Array(p.length);for(var i=0;i<p.length;i++){view[i]=p.charCodeAt(i)}ab=view.buffer}if(isString){resultArray[bufferIndex++]=0}else{resultArray[bufferIndex++]=1}var lenStr=ab.byteLength.toString();for(var i=0;i<lenStr.length;i++){resultArray[bufferIndex++]=parseInt(lenStr[i])}resultArray[bufferIndex++]=255;var view=new Uint8Array(ab);for(var i=0;i<view.length;i++){resultArray[bufferIndex++]=view[i]}});return callback(resultArray.buffer)})};exports.encodePayloadAsBlob=function(packets,callback){function encodeOne(packet,doneCallback){exports.encodePacket(packet,true,true,function(encoded){var binaryIdentifier=new Uint8Array(1);binaryIdentifier[0]=1;if(typeof encoded==="string"){var view=new Uint8Array(encoded.length);for(var i=0;i<encoded.length;i++){view[i]=encoded.charCodeAt(i)}encoded=view.buffer;binaryIdentifier[0]=0}var len=encoded instanceof ArrayBuffer?encoded.byteLength:encoded.size;var lenStr=len.toString();var lengthAry=new Uint8Array(lenStr.length+1);for(var i=0;i<lenStr.length;i++){lengthAry[i]=parseInt(lenStr[i])}lengthAry[lenStr.length]=255;if(Blob){var blob=new Blob([binaryIdentifier.buffer,lengthAry.buffer,encoded]);doneCallback(null,blob)}})}map(packets,encodeOne,function(err,results){return callback(new Blob(results))})};exports.decodePayloadAsBinary=function(data,binaryType,callback){if(typeof binaryType==="function"){callback=binaryType;binaryType=null}var bufferTail=data;var buffers=[];var numberTooLong=false;while(bufferTail.byteLength>0){var tailArray=new Uint8Array(bufferTail);var isString=tailArray[0]===0;var msgLength="";for(var i=1;;i++){if(tailArray[i]==255)break;if(msgLength.length>310){numberTooLong=true;break}msgLength+=tailArray[i]}if(numberTooLong)return callback(err,0,1);bufferTail=sliceBuffer(bufferTail,2+msgLength.length);msgLength=parseInt(msgLength);var msg=sliceBuffer(bufferTail,0,msgLength);if(isString){try{msg=String.fromCharCode.apply(null,new Uint8Array(msg))}catch(e){var typed=new Uint8Array(msg);msg="";for(var i=0;i<typed.length;i++){msg+=String.fromCharCode(typed[i])}}}buffers.push(msg);bufferTail=sliceBuffer(bufferTail,msgLength)}var total=buffers.length;buffers.forEach(function(buffer,i){callback(exports.decodePacket(buffer,binaryType,true),i,total)})}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./keys":26,after:27,"arraybuffer.slice":28,"base64-arraybuffer":29,blob:30,"has-binary":31,utf8:33}],26:[function(_dereq_,module,exports){module.exports=Object.keys||function keys(obj){var arr=[];var has=Object.prototype.hasOwnProperty;for(var i in obj){if(has.call(obj,i)){arr.push(i)}}return arr}},{}],27:[function(_dereq_,module,exports){module.exports=after;function after(count,callback,err_cb){var bail=false;err_cb=err_cb||noop;proxy.count=count;return count===0?callback():proxy;function proxy(err,result){if(proxy.count<=0){throw new Error("after called too many times")}--proxy.count;if(err){bail=true;callback(err);callback=err_cb}else if(proxy.count===0&&!bail){callback(null,result)}}}function noop(){}},{}],28:[function(_dereq_,module,exports){module.exports=function(arraybuffer,start,end){var bytes=arraybuffer.byteLength;start=start||0;end=end||bytes;if(arraybuffer.slice){return arraybuffer.slice(start,end)}if(start<0){start+=bytes}if(end<0){end+=bytes}if(end>bytes){end=bytes}if(start>=bytes||start>=end||bytes===0){return new ArrayBuffer(0)}var abv=new Uint8Array(arraybuffer);var result=new Uint8Array(end-start);for(var i=start,ii=0;i<end;i++,ii++){result[ii]=abv[i]}return result.buffer}},{}],29:[function(_dereq_,module,exports){(function(chars){"use strict";exports.encode=function(arraybuffer){var bytes=new Uint8Array(arraybuffer),i,len=bytes.length,base64="";for(i=0;i<len;i+=3){base64+=chars[bytes[i]>>2];base64+=chars[(bytes[i]&3)<<4|bytes[i+1]>>4];base64+=chars[(bytes[i+1]&15)<<2|bytes[i+2]>>6];base64+=chars[bytes[i+2]&63]}if(len%3===2){base64=base64.substring(0,base64.length-1)+"="}else if(len%3===1){base64=base64.substring(0,base64.length-2)+"=="}return base64};exports.decode=function(base64){var bufferLength=base64.length*.75,len=base64.length,i,p=0,encoded1,encoded2,encoded3,encoded4;if(base64[base64.length-1]==="="){bufferLength--;if(base64[base64.length-2]==="="){bufferLength--}}var arraybuffer=new ArrayBuffer(bufferLength),bytes=new Uint8Array(arraybuffer);for(i=0;i<len;i+=4){encoded1=chars.indexOf(base64[i]);encoded2=chars.indexOf(base64[i+1]);encoded3=chars.indexOf(base64[i+2]);encoded4=chars.indexOf(base64[i+3]);bytes[p++]=encoded1<<2|encoded2>>4;bytes[p++]=(encoded2&15)<<4|encoded3>>2;bytes[p++]=(encoded3&3)<<6|encoded4&63}return arraybuffer}})("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")},{}],30:[function(_dereq_,module,exports){(function(global){var BlobBuilder=global.BlobBuilder||global.WebKitBlobBuilder||global.MSBlobBuilder||global.MozBlobBuilder;var blobSupported=function(){try{var b=new Blob(["hi"]);return b.size==2}catch(e){return false}}();var blobBuilderSupported=BlobBuilder&&BlobBuilder.prototype.append&&BlobBuilder.prototype.getBlob;function BlobBuilderConstructor(ary,options){options=options||{};var bb=new BlobBuilder;for(var i=0;i<ary.length;i++){bb.append(ary[i])}return options.type?bb.getBlob(options.type):bb.getBlob()}module.exports=function(){if(blobSupported){return global.Blob}else if(blobBuilderSupported){return BlobBuilderConstructor}else{return undefined}}()}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],31:[function(_dereq_,module,exports){(function(global){var isArray=_dereq_("isarray");module.exports=hasBinary;function hasBinary(data){function _hasBinary(obj){if(!obj)return false;if(global.Buffer&&global.Buffer.isBuffer(obj)||global.ArrayBuffer&&obj instanceof ArrayBuffer||global.Blob&&obj instanceof Blob||global.File&&obj instanceof File){return true}if(isArray(obj)){for(var i=0;i<obj.length;i++){if(_hasBinary(obj[i])){return true}}}else if(obj&&"object"==typeof obj){if(obj.toJSON){obj=obj.toJSON()}for(var key in obj){if(obj.hasOwnProperty(key)&&_hasBinary(obj[key])){return true}}}return false}return _hasBinary(data)}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{isarray:32}],32:[function(_dereq_,module,exports){module.exports=Array.isArray||function(arr){return Object.prototype.toString.call(arr)=="[object Array]"}},{}],33:[function(_dereq_,module,exports){(function(global){(function(root){var freeExports=typeof exports=="object"&&exports;var freeModule=typeof module=="object"&&module&&module.exports==freeExports&&module;var freeGlobal=typeof global=="object"&&global;if(freeGlobal.global===freeGlobal||freeGlobal.window===freeGlobal){root=freeGlobal}var stringFromCharCode=String.fromCharCode;function ucs2decode(string){var output=[];var counter=0;var length=string.length;var value;var extra;while(counter<length){value=string.charCodeAt(counter++);if(value>=55296&&value<=56319&&counter<length){extra=string.charCodeAt(counter++);if((extra&64512)==56320){output.push(((value&1023)<<10)+(extra&1023)+65536)}else{output.push(value);counter--}}else{output.push(value)}}return output}function ucs2encode(array){var length=array.length;var index=-1;var value;var output="";while(++index<length){value=array[index];if(value>65535){value-=65536;
output+=stringFromCharCode(value>>>10&1023|55296);value=56320|value&1023}output+=stringFromCharCode(value)}return output}function createByte(codePoint,shift){return stringFromCharCode(codePoint>>shift&63|128)}function encodeCodePoint(codePoint){if((codePoint&4294967168)==0){return stringFromCharCode(codePoint)}var symbol="";if((codePoint&4294965248)==0){symbol=stringFromCharCode(codePoint>>6&31|192)}else if((codePoint&4294901760)==0){symbol=stringFromCharCode(codePoint>>12&15|224);symbol+=createByte(codePoint,6)}else if((codePoint&4292870144)==0){symbol=stringFromCharCode(codePoint>>18&7|240);symbol+=createByte(codePoint,12);symbol+=createByte(codePoint,6)}symbol+=stringFromCharCode(codePoint&63|128);return symbol}function utf8encode(string){var codePoints=ucs2decode(string);var length=codePoints.length;var index=-1;var codePoint;var byteString="";while(++index<length){codePoint=codePoints[index];byteString+=encodeCodePoint(codePoint)}return byteString}function readContinuationByte(){if(byteIndex>=byteCount){throw Error("Invalid byte index")}var continuationByte=byteArray[byteIndex]&255;byteIndex++;if((continuationByte&192)==128){return continuationByte&63}throw Error("Invalid continuation byte")}function decodeSymbol(){var byte1;var byte2;var byte3;var byte4;var codePoint;if(byteIndex>byteCount){throw Error("Invalid byte index")}if(byteIndex==byteCount){return false}byte1=byteArray[byteIndex]&255;byteIndex++;if((byte1&128)==0){return byte1}if((byte1&224)==192){var byte2=readContinuationByte();codePoint=(byte1&31)<<6|byte2;if(codePoint>=128){return codePoint}else{throw Error("Invalid continuation byte")}}if((byte1&240)==224){byte2=readContinuationByte();byte3=readContinuationByte();codePoint=(byte1&15)<<12|byte2<<6|byte3;if(codePoint>=2048){return codePoint}else{throw Error("Invalid continuation byte")}}if((byte1&248)==240){byte2=readContinuationByte();byte3=readContinuationByte();byte4=readContinuationByte();codePoint=(byte1&15)<<18|byte2<<12|byte3<<6|byte4;if(codePoint>=65536&&codePoint<=1114111){return codePoint}}throw Error("Invalid UTF-8 detected")}var byteArray;var byteCount;var byteIndex;function utf8decode(byteString){byteArray=ucs2decode(byteString);byteCount=byteArray.length;byteIndex=0;var codePoints=[];var tmp;while((tmp=decodeSymbol())!==false){codePoints.push(tmp)}return ucs2encode(codePoints)}var utf8={version:"2.0.0",encode:utf8encode,decode:utf8decode};if(typeof define=="function"&&typeof define.amd=="object"&&define.amd){define(function(){return utf8})}else if(freeExports&&!freeExports.nodeType){if(freeModule){freeModule.exports=utf8}else{var object={};var hasOwnProperty=object.hasOwnProperty;for(var key in utf8){hasOwnProperty.call(utf8,key)&&(freeExports[key]=utf8[key])}}}else{root.utf8=utf8}})(this)}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],34:[function(_dereq_,module,exports){(function(global){var rvalidchars=/^[\],:{}\s]*$/;var rvalidescape=/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;var rvalidtokens=/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;var rvalidbraces=/(?:^|:|,)(?:\s*\[)+/g;var rtrimLeft=/^\s+/;var rtrimRight=/\s+$/;module.exports=function parsejson(data){if("string"!=typeof data||!data){return null}data=data.replace(rtrimLeft,"").replace(rtrimRight,"");if(global.JSON&&JSON.parse){return JSON.parse(data)}if(rvalidchars.test(data.replace(rvalidescape,"@").replace(rvalidtokens,"]").replace(rvalidbraces,""))){return new Function("return "+data)()}}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],35:[function(_dereq_,module,exports){exports.encode=function(obj){var str="";for(var i in obj){if(obj.hasOwnProperty(i)){if(str.length)str+="&";str+=encodeURIComponent(i)+"="+encodeURIComponent(obj[i])}}return str};exports.decode=function(qs){var qry={};var pairs=qs.split("&");for(var i=0,l=pairs.length;i<l;i++){var pair=pairs[i].split("=");qry[decodeURIComponent(pair[0])]=decodeURIComponent(pair[1])}return qry}},{}],36:[function(_dereq_,module,exports){var re=/^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;var parts=["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"];module.exports=function parseuri(str){var src=str,b=str.indexOf("["),e=str.indexOf("]");if(b!=-1&&e!=-1){str=str.substring(0,b)+str.substring(b,e).replace(/:/g,";")+str.substring(e,str.length)}var m=re.exec(str||""),uri={},i=14;while(i--){uri[parts[i]]=m[i]||""}if(b!=-1&&e!=-1){uri.source=src;uri.host=uri.host.substring(1,uri.host.length-1).replace(/;/g,":");uri.authority=uri.authority.replace("[","").replace("]","").replace(/;/g,":");uri.ipv6uri=true}return uri}},{}],37:[function(_dereq_,module,exports){var global=function(){return this}();var WebSocket=global.WebSocket||global.MozWebSocket;module.exports=WebSocket?ws:null;function ws(uri,protocols,opts){var instance;if(protocols){instance=new WebSocket(uri,protocols)}else{instance=new WebSocket(uri)}return instance}if(WebSocket)ws.prototype=WebSocket.prototype},{}],38:[function(_dereq_,module,exports){(function(global){var isArray=_dereq_("isarray");module.exports=hasBinary;function hasBinary(data){function _hasBinary(obj){if(!obj)return false;if(global.Buffer&&global.Buffer.isBuffer(obj)||global.ArrayBuffer&&obj instanceof ArrayBuffer||global.Blob&&obj instanceof Blob||global.File&&obj instanceof File){return true}if(isArray(obj)){for(var i=0;i<obj.length;i++){if(_hasBinary(obj[i])){return true}}}else if(obj&&"object"==typeof obj){if(obj.toJSON){obj=obj.toJSON()}for(var key in obj){if(Object.prototype.hasOwnProperty.call(obj,key)&&_hasBinary(obj[key])){return true}}}return false}return _hasBinary(data)}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{isarray:39}],39:[function(_dereq_,module,exports){module.exports=_dereq_(32)},{}],40:[function(_dereq_,module,exports){var global=_dereq_("global");try{module.exports="XMLHttpRequest"in global&&"withCredentials"in new global.XMLHttpRequest}catch(err){module.exports=false}},{global:41}],41:[function(_dereq_,module,exports){module.exports=function(){return this}()},{}],42:[function(_dereq_,module,exports){var indexOf=[].indexOf;module.exports=function(arr,obj){if(indexOf)return arr.indexOf(obj);for(var i=0;i<arr.length;++i){if(arr[i]===obj)return i}return-1}},{}],43:[function(_dereq_,module,exports){var has=Object.prototype.hasOwnProperty;exports.keys=Object.keys||function(obj){var keys=[];for(var key in obj){if(has.call(obj,key)){keys.push(key)}}return keys};exports.values=function(obj){var vals=[];for(var key in obj){if(has.call(obj,key)){vals.push(obj[key])}}return vals};exports.merge=function(a,b){for(var key in b){if(has.call(b,key)){a[key]=b[key]}}return a};exports.length=function(obj){return exports.keys(obj).length};exports.isEmpty=function(obj){return 0==exports.length(obj)}},{}],44:[function(_dereq_,module,exports){var re=/^(?:(?![^:@]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;var parts=["source","protocol","authority","userInfo","user","password","host","port","relative","path","directory","file","query","anchor"];module.exports=function parseuri(str){var m=re.exec(str||""),uri={},i=14;while(i--){uri[parts[i]]=m[i]||""}return uri}},{}],45:[function(_dereq_,module,exports){(function(global){var isArray=_dereq_("isarray");var isBuf=_dereq_("./is-buffer");exports.deconstructPacket=function(packet){var buffers=[];var packetData=packet.data;function _deconstructPacket(data){if(!data)return data;if(isBuf(data)){var placeholder={_placeholder:true,num:buffers.length};buffers.push(data);return placeholder}else if(isArray(data)){var newData=new Array(data.length);for(var i=0;i<data.length;i++){newData[i]=_deconstructPacket(data[i])}return newData}else if("object"==typeof data&&!(data instanceof Date)){var newData={};for(var key in data){newData[key]=_deconstructPacket(data[key])}return newData}return data}var pack=packet;pack.data=_deconstructPacket(packetData);pack.attachments=buffers.length;return{packet:pack,buffers:buffers}};exports.reconstructPacket=function(packet,buffers){var curPlaceHolder=0;function _reconstructPacket(data){if(data&&data._placeholder){var buf=buffers[data.num];return buf}else if(isArray(data)){for(var i=0;i<data.length;i++){data[i]=_reconstructPacket(data[i])}return data}else if(data&&"object"==typeof data){for(var key in data){data[key]=_reconstructPacket(data[key])}return data}return data}packet.data=_reconstructPacket(packet.data);packet.attachments=undefined;return packet};exports.removeBlobs=function(data,callback){function _removeBlobs(obj,curKey,containingObject){if(!obj)return obj;if(global.Blob&&obj instanceof Blob||global.File&&obj instanceof File){pendingBlobs++;var fileReader=new FileReader;fileReader.onload=function(){if(containingObject){containingObject[curKey]=this.result}else{bloblessData=this.result}if(!--pendingBlobs){callback(bloblessData)}};fileReader.readAsArrayBuffer(obj)}else if(isArray(obj)){for(var i=0;i<obj.length;i++){_removeBlobs(obj[i],i,obj)}}else if(obj&&"object"==typeof obj&&!isBuf(obj)){for(var key in obj){_removeBlobs(obj[key],key,obj)}}}var pendingBlobs=0;var bloblessData=data;_removeBlobs(bloblessData);if(!pendingBlobs){callback(bloblessData)}}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./is-buffer":47,isarray:48}],46:[function(_dereq_,module,exports){var debug=_dereq_("debug")("socket.io-parser");var json=_dereq_("json3");var isArray=_dereq_("isarray");var Emitter=_dereq_("component-emitter");var binary=_dereq_("./binary");var isBuf=_dereq_("./is-buffer");exports.protocol=4;exports.types=["CONNECT","DISCONNECT","EVENT","BINARY_EVENT","ACK","BINARY_ACK","ERROR"];exports.CONNECT=0;exports.DISCONNECT=1;exports.EVENT=2;exports.ACK=3;exports.ERROR=4;exports.BINARY_EVENT=5;exports.BINARY_ACK=6;exports.Encoder=Encoder;exports.Decoder=Decoder;function Encoder(){}Encoder.prototype.encode=function(obj,callback){debug("encoding packet %j",obj);if(exports.BINARY_EVENT==obj.type||exports.BINARY_ACK==obj.type){encodeAsBinary(obj,callback)}else{var encoding=encodeAsString(obj);callback([encoding])}};function encodeAsString(obj){var str="";var nsp=false;str+=obj.type;if(exports.BINARY_EVENT==obj.type||exports.BINARY_ACK==obj.type){str+=obj.attachments;str+="-"}if(obj.nsp&&"/"!=obj.nsp){nsp=true;str+=obj.nsp}if(null!=obj.id){if(nsp){str+=",";nsp=false}str+=obj.id}if(null!=obj.data){if(nsp)str+=",";str+=json.stringify(obj.data)}debug("encoded %j as %s",obj,str);return str}function encodeAsBinary(obj,callback){function writeEncoding(bloblessData){var deconstruction=binary.deconstructPacket(bloblessData);var pack=encodeAsString(deconstruction.packet);var buffers=deconstruction.buffers;buffers.unshift(pack);callback(buffers)}binary.removeBlobs(obj,writeEncoding)}function Decoder(){this.reconstructor=null}Emitter(Decoder.prototype);Decoder.prototype.add=function(obj){var packet;if("string"==typeof obj){packet=decodeString(obj);if(exports.BINARY_EVENT==packet.type||exports.BINARY_ACK==packet.type){this.reconstructor=new BinaryReconstructor(packet);if(this.reconstructor.reconPack.attachments===0){this.emit("decoded",packet)}}else{this.emit("decoded",packet)}}else if(isBuf(obj)||obj.base64){if(!this.reconstructor){throw new Error("got binary data when not reconstructing a packet")}else{packet=this.reconstructor.takeBinaryData(obj);if(packet){this.reconstructor=null;this.emit("decoded",packet)}}}else{throw new Error("Unknown type: "+obj)}};function decodeString(str){var p={};var i=0;p.type=Number(str.charAt(0));if(null==exports.types[p.type])return error();if(exports.BINARY_EVENT==p.type||exports.BINARY_ACK==p.type){var buf="";while(str.charAt(++i)!="-"){buf+=str.charAt(i);if(i==str.length)break}if(buf!=Number(buf)||str.charAt(i)!="-"){throw new Error("Illegal attachments")}p.attachments=Number(buf)}if("/"==str.charAt(i+1)){p.nsp="";while(++i){var c=str.charAt(i);if(","==c)break;p.nsp+=c;if(i==str.length)break}}else{p.nsp="/"}var next=str.charAt(i+1);if(""!==next&&Number(next)==next){p.id="";while(++i){var c=str.charAt(i);if(null==c||Number(c)!=c){--i;break}p.id+=str.charAt(i);if(i==str.length)break}p.id=Number(p.id)}if(str.charAt(++i)){try{p.data=json.parse(str.substr(i))}catch(e){return error()}}debug("decoded %s as %j",str,p);return p}Decoder.prototype.destroy=function(){if(this.reconstructor){this.reconstructor.finishedReconstruction()}};function BinaryReconstructor(packet){this.reconPack=packet;this.buffers=[]}BinaryReconstructor.prototype.takeBinaryData=function(binData){this.buffers.push(binData);if(this.buffers.length==this.reconPack.attachments){var packet=binary.reconstructPacket(this.reconPack,this.buffers);this.finishedReconstruction();return packet}return null};BinaryReconstructor.prototype.finishedReconstruction=function(){this.reconPack=null;this.buffers=[]};function error(data){return{type:exports.ERROR,data:"parser error"}}},{"./binary":45,"./is-buffer":47,"component-emitter":9,debug:10,isarray:48,json3:49}],47:[function(_dereq_,module,exports){(function(global){module.exports=isBuf;function isBuf(obj){return global.Buffer&&global.Buffer.isBuffer(obj)||global.ArrayBuffer&&obj instanceof ArrayBuffer}}).call(this,typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],48:[function(_dereq_,module,exports){module.exports=_dereq_(32)},{}],49:[function(_dereq_,module,exports){(function(window){var getClass={}.toString,isProperty,forEach,undef;var isLoader=typeof define==="function"&&define.amd;var nativeJSON=typeof JSON=="object"&&JSON;var JSON3=typeof exports=="object"&&exports&&!exports.nodeType&&exports;if(JSON3&&nativeJSON){JSON3.stringify=nativeJSON.stringify;JSON3.parse=nativeJSON.parse}else{JSON3=window.JSON=nativeJSON||{}}var isExtended=new Date(-0xc782b5b800cec);try{isExtended=isExtended.getUTCFullYear()==-109252&&isExtended.getUTCMonth()===0&&isExtended.getUTCDate()===1&&isExtended.getUTCHours()==10&&isExtended.getUTCMinutes()==37&&isExtended.getUTCSeconds()==6&&isExtended.getUTCMilliseconds()==708}catch(exception){}function has(name){if(has[name]!==undef){return has[name]}var isSupported;if(name=="bug-string-char-index"){isSupported="a"[0]!="a"}else if(name=="json"){isSupported=has("json-stringify")&&has("json-parse")}else{var value,serialized='{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';if(name=="json-stringify"){var stringify=JSON3.stringify,stringifySupported=typeof stringify=="function"&&isExtended;if(stringifySupported){(value=function(){return 1}).toJSON=value;try{stringifySupported=stringify(0)==="0"&&stringify(new Number)==="0"&&stringify(new String)=='""'&&stringify(getClass)===undef&&stringify(undef)===undef&&stringify()===undef&&stringify(value)==="1"&&stringify([value])=="[1]"&&stringify([undef])=="[null]"&&stringify(null)=="null"&&stringify([undef,getClass,null])=="[null,null,null]"&&stringify({a:[value,true,false,null,"\x00\b\n\f\r	"]})==serialized&&stringify(null,value)==="1"&&stringify([1,2],null,1)=="[\n 1,\n 2\n]"&&stringify(new Date(-864e13))=='"-271821-04-20T00:00:00.000Z"'&&stringify(new Date(864e13))=='"+275760-09-13T00:00:00.000Z"'&&stringify(new Date(-621987552e5))=='"-000001-01-01T00:00:00.000Z"'&&stringify(new Date(-1))=='"1969-12-31T23:59:59.999Z"'}catch(exception){stringifySupported=false}}isSupported=stringifySupported}if(name=="json-parse"){var parse=JSON3.parse;if(typeof parse=="function"){try{if(parse("0")===0&&!parse(false)){value=parse(serialized);var parseSupported=value["a"].length==5&&value["a"][0]===1;if(parseSupported){try{parseSupported=!parse('"	"')}catch(exception){}if(parseSupported){try{parseSupported=parse("01")!==1}catch(exception){}}if(parseSupported){try{parseSupported=parse("1.")!==1}catch(exception){}}}}}catch(exception){parseSupported=false}}isSupported=parseSupported}}return has[name]=!!isSupported}if(!has("json")){var functionClass="[object Function]";var dateClass="[object Date]";var numberClass="[object Number]";var stringClass="[object String]";var arrayClass="[object Array]";var booleanClass="[object Boolean]";var charIndexBuggy=has("bug-string-char-index");if(!isExtended){var floor=Math.floor;var Months=[0,31,59,90,120,151,181,212,243,273,304,334];var getDay=function(year,month){return Months[month]+365*(year-1970)+floor((year-1969+(month=+(month>1)))/4)-floor((year-1901+month)/100)+floor((year-1601+month)/400)}}if(!(isProperty={}.hasOwnProperty)){isProperty=function(property){var members={},constructor;if((members.__proto__=null,members.__proto__={toString:1},members).toString!=getClass){isProperty=function(property){var original=this.__proto__,result=property in(this.__proto__=null,this);this.__proto__=original;return result}}else{constructor=members.constructor;isProperty=function(property){var parent=(this.constructor||constructor).prototype;return property in this&&!(property in parent&&this[property]===parent[property])}}members=null;return isProperty.call(this,property)}}var PrimitiveTypes={"boolean":1,number:1,string:1,undefined:1};var isHostType=function(object,property){var type=typeof object[property];return type=="object"?!!object[property]:!PrimitiveTypes[type]};forEach=function(object,callback){var size=0,Properties,members,property;(Properties=function(){this.valueOf=0}).prototype.valueOf=0;members=new Properties;for(property in members){if(isProperty.call(members,property)){size++}}Properties=members=null;if(!size){members=["valueOf","toString","toLocaleString","propertyIsEnumerable","isPrototypeOf","hasOwnProperty","constructor"];forEach=function(object,callback){var isFunction=getClass.call(object)==functionClass,property,length;var hasProperty=!isFunction&&typeof object.constructor!="function"&&isHostType(object,"hasOwnProperty")?object.hasOwnProperty:isProperty;for(property in object){if(!(isFunction&&property=="prototype")&&hasProperty.call(object,property)){callback(property)}}for(length=members.length;property=members[--length];hasProperty.call(object,property)&&callback(property));}}else if(size==2){forEach=function(object,callback){var members={},isFunction=getClass.call(object)==functionClass,property;for(property in object){if(!(isFunction&&property=="prototype")&&!isProperty.call(members,property)&&(members[property]=1)&&isProperty.call(object,property)){callback(property)}}}}else{forEach=function(object,callback){var isFunction=getClass.call(object)==functionClass,property,isConstructor;for(property in object){if(!(isFunction&&property=="prototype")&&isProperty.call(object,property)&&!(isConstructor=property==="constructor")){callback(property)}}if(isConstructor||isProperty.call(object,property="constructor")){callback(property)}}}return forEach(object,callback)};if(!has("json-stringify")){var Escapes={92:"\\\\",34:'\\"',8:"\\b",12:"\\f",10:"\\n",13:"\\r",9:"\\t"};var leadingZeroes="000000";var toPaddedString=function(width,value){return(leadingZeroes+(value||0)).slice(-width)};var unicodePrefix="\\u00";var quote=function(value){var result='"',index=0,length=value.length,isLarge=length>10&&charIndexBuggy,symbols;if(isLarge){symbols=value.split("")}for(;index<length;index++){var charCode=value.charCodeAt(index);switch(charCode){case 8:case 9:case 10:case 12:case 13:case 34:case 92:result+=Escapes[charCode];break;default:if(charCode<32){result+=unicodePrefix+toPaddedString(2,charCode.toString(16));break}result+=isLarge?symbols[index]:charIndexBuggy?value.charAt(index):value[index]}}return result+'"'};var serialize=function(property,object,callback,properties,whitespace,indentation,stack){var value,className,year,month,date,time,hours,minutes,seconds,milliseconds,results,element,index,length,prefix,result;try{value=object[property]}catch(exception){}if(typeof value=="object"&&value){className=getClass.call(value);if(className==dateClass&&!isProperty.call(value,"toJSON")){if(value>-1/0&&value<1/0){if(getDay){date=floor(value/864e5);for(year=floor(date/365.2425)+1970-1;getDay(year+1,0)<=date;year++);for(month=floor((date-getDay(year,0))/30.42);getDay(year,month+1)<=date;month++);date=1+date-getDay(year,month);time=(value%864e5+864e5)%864e5;hours=floor(time/36e5)%24;minutes=floor(time/6e4)%60;seconds=floor(time/1e3)%60;milliseconds=time%1e3}else{year=value.getUTCFullYear();month=value.getUTCMonth();date=value.getUTCDate();hours=value.getUTCHours();minutes=value.getUTCMinutes();seconds=value.getUTCSeconds();milliseconds=value.getUTCMilliseconds()}value=(year<=0||year>=1e4?(year<0?"-":"+")+toPaddedString(6,year<0?-year:year):toPaddedString(4,year))+"-"+toPaddedString(2,month+1)+"-"+toPaddedString(2,date)+"T"+toPaddedString(2,hours)+":"+toPaddedString(2,minutes)+":"+toPaddedString(2,seconds)+"."+toPaddedString(3,milliseconds)+"Z"}else{value=null}}else if(typeof value.toJSON=="function"&&(className!=numberClass&&className!=stringClass&&className!=arrayClass||isProperty.call(value,"toJSON"))){value=value.toJSON(property)}}if(callback){value=callback.call(object,property,value)}if(value===null){return"null"}className=getClass.call(value);if(className==booleanClass){return""+value}else if(className==numberClass){return value>-1/0&&value<1/0?""+value:"null"}else if(className==stringClass){return quote(""+value)}if(typeof value=="object"){for(length=stack.length;length--;){if(stack[length]===value){throw TypeError()}}stack.push(value);results=[];prefix=indentation;indentation+=whitespace;if(className==arrayClass){for(index=0,length=value.length;index<length;index++){element=serialize(index,value,callback,properties,whitespace,indentation,stack);results.push(element===undef?"null":element)}result=results.length?whitespace?"[\n"+indentation+results.join(",\n"+indentation)+"\n"+prefix+"]":"["+results.join(",")+"]":"[]"}else{forEach(properties||value,function(property){var element=serialize(property,value,callback,properties,whitespace,indentation,stack);if(element!==undef){results.push(quote(property)+":"+(whitespace?" ":"")+element)}});result=results.length?whitespace?"{\n"+indentation+results.join(",\n"+indentation)+"\n"+prefix+"}":"{"+results.join(",")+"}":"{}"}stack.pop();return result}};JSON3.stringify=function(source,filter,width){var whitespace,callback,properties,className;if(typeof filter=="function"||typeof filter=="object"&&filter){if((className=getClass.call(filter))==functionClass){callback=filter}else if(className==arrayClass){properties={};for(var index=0,length=filter.length,value;index<length;value=filter[index++],(className=getClass.call(value),className==stringClass||className==numberClass)&&(properties[value]=1));}}if(width){if((className=getClass.call(width))==numberClass){if((width-=width%1)>0){for(whitespace="",width>10&&(width=10);whitespace.length<width;whitespace+=" ");}}else if(className==stringClass){whitespace=width.length<=10?width:width.slice(0,10)}}return serialize("",(value={},value[""]=source,value),callback,properties,whitespace,"",[])}}if(!has("json-parse")){var fromCharCode=String.fromCharCode;var Unescapes={92:"\\",34:'"',47:"/",98:"\b",116:"	",110:"\n",102:"\f",114:"\r"};var Index,Source;var abort=function(){Index=Source=null;throw SyntaxError()};var lex=function(){var source=Source,length=source.length,value,begin,position,isSigned,charCode;while(Index<length){charCode=source.charCodeAt(Index);switch(charCode){case 9:case 10:case 13:case 32:Index++;break;case 123:case 125:case 91:case 93:case 58:case 44:value=charIndexBuggy?source.charAt(Index):source[Index];Index++;return value;case 34:for(value="@",Index++;Index<length;){charCode=source.charCodeAt(Index);if(charCode<32){abort()}else if(charCode==92){charCode=source.charCodeAt(++Index);switch(charCode){case 92:case 34:case 47:case 98:case 116:case 110:case 102:case 114:value+=Unescapes[charCode];Index++;break;case 117:begin=++Index;for(position=Index+4;Index<position;Index++){charCode=source.charCodeAt(Index);if(!(charCode>=48&&charCode<=57||charCode>=97&&charCode<=102||charCode>=65&&charCode<=70)){abort()}}value+=fromCharCode("0x"+source.slice(begin,Index));break;default:abort()}}else{if(charCode==34){break}charCode=source.charCodeAt(Index);begin=Index;while(charCode>=32&&charCode!=92&&charCode!=34){charCode=source.charCodeAt(++Index)}value+=source.slice(begin,Index)}}if(source.charCodeAt(Index)==34){Index++;return value}abort();default:begin=Index;if(charCode==45){isSigned=true;charCode=source.charCodeAt(++Index)}if(charCode>=48&&charCode<=57){if(charCode==48&&(charCode=source.charCodeAt(Index+1),charCode>=48&&charCode<=57)){abort()}isSigned=false;for(;Index<length&&(charCode=source.charCodeAt(Index),charCode>=48&&charCode<=57);Index++);if(source.charCodeAt(Index)==46){position=++Index;for(;position<length&&(charCode=source.charCodeAt(position),charCode>=48&&charCode<=57);position++);if(position==Index){abort()}Index=position}charCode=source.charCodeAt(Index);if(charCode==101||charCode==69){charCode=source.charCodeAt(++Index);if(charCode==43||charCode==45){Index++}for(position=Index;position<length&&(charCode=source.charCodeAt(position),charCode>=48&&charCode<=57);position++);if(position==Index){abort()}Index=position}return+source.slice(begin,Index)}if(isSigned){abort()}if(source.slice(Index,Index+4)=="true"){Index+=4;return true}else if(source.slice(Index,Index+5)=="false"){Index+=5;return false}else if(source.slice(Index,Index+4)=="null"){Index+=4;return null}abort()}}return"$"};var get=function(value){var results,hasMembers;if(value=="$"){abort()}if(typeof value=="string"){if((charIndexBuggy?value.charAt(0):value[0])=="@"){return value.slice(1)}if(value=="["){results=[];for(;;hasMembers||(hasMembers=true)){value=lex();if(value=="]"){break}if(hasMembers){if(value==","){value=lex();if(value=="]"){abort()}}else{abort()}}if(value==","){abort()}results.push(get(value))}return results}else if(value=="{"){results={};for(;;hasMembers||(hasMembers=true)){value=lex();if(value=="}"){break}if(hasMembers){if(value==","){value=lex();if(value=="}"){abort()}}else{abort()}}if(value==","||typeof value!="string"||(charIndexBuggy?value.charAt(0):value[0])!="@"||lex()!=":"){abort()}results[value.slice(1)]=get(lex())}return results}abort()}return value};var update=function(source,property,callback){var element=walk(source,property,callback);if(element===undef){delete source[property]}else{source[property]=element}};var walk=function(source,property,callback){var value=source[property],length;if(typeof value=="object"&&value){if(getClass.call(value)==arrayClass){for(length=value.length;length--;){update(value,length,callback)}}else{forEach(value,function(property){update(value,property,callback)})}}return callback.call(source,property,value)};JSON3.parse=function(source,callback){var result,value;Index=0;Source=""+source;result=get(lex());if(lex()!="$"){abort()}Index=Source=null;return callback&&getClass.call(callback)==functionClass?walk((value={},value[""]=result,value),"",callback):result}}}if(isLoader){define(function(){return JSON3})}})(this)},{}],50:[function(_dereq_,module,exports){module.exports=toArray;function toArray(list,index){var array=[];index=index||0;for(var i=index||0;i<list.length;i++){array[i-index]=list[i]}return array}},{}]},{},[1])(1)});
define('model/socket',["jquery","underscore","backbone","socketio","util/ajax","model/data","model/token-data"],function(e,t,n,o,c,i,r){var s={},u={},d={},a={};return n.Model.extend({defaults:{room:"",socketUriController:""},socketUriPrefix:Game.baseUri+"socket/uri/",initialize:function(){this.customEvents={},this.connect(),this.pendingEvents=[]},getUuriCount:function(){var e=this.uuri;return t.has(d,e)?d[e]:0},getQuery:function(){var n=this,o=new e.Deferred,c=t.uniqueId();return a[c]=new(i.extend({urlRoot:Game.baseUri+"socket/query"}))().fetch({ignoreError:!0}).done(function(e){o.resolve(t.extend({room:e.prefix+n.get("room"),nickname:encodeURIComponent(e.nickname)},e)),delete a[c]}),o},getSocketUri:function(){var n=new e.Deferred,o=t.uniqueId(),c=this.get("socketUriController"),r=c?Game.baseUri+"socket/"+c+"/uri/":this.socketUriPrefix;return a[o]=new(i.extend({urlRoot:r+this.get("room")}))().fetch({ignoreError:!0}).done(function(e){n.resolve(e),delete a[o]}),n},resetToken:function(){var t=new e.Deferred;return this.getQuery().done(function(e){t.resolve(e)}),t},delayedConnect:function(){var e=this;e.destroySocket(),e.destroyed||(window.clearTimeout(e.connectTimer),e.connectTimer=window.setTimeout(function(){e.connect()},1e4))},delayedReconnect:function(){var e=this;e.destroySocket(),e.destroyed||(window.clearTimeout(e.reconnectTimer),e.reconnectTimer=window.setTimeout(function(){e.reconnect()},1e4))},delayedDisconnect:function(){var e=this,n=e.uuri;t.has(u,n)&&clearTimeout(u[n]),u[n]=setTimeout(function(){0===e.getUuriCount()&&s[n].disconnect(),delete u[n]},5e3)},handleConnect:function(){var e=this;e.resetRetryCount(),e.bindCustomEvents(e.socket),t.each(e.pendingEvents,function(t){e.socket.emit(t.event,t.data)})},tryDelayedConnect:function(){var t=this;t.retryCount=t.retryCount||0,t.retryCount++<5?t.delayedConnect():e(window).one("touchstart",function(){t.resetRetryCount(),t.delayedConnect()})},bindEvents:function(e){var n=this,o=n.ioEvents={connect:[],disconnect:[],connect_error:[],reconnect_error:[],error:[],connect_timeout:[],reconnect_failed:[]};o.connect.push(function(){n.handleConnect()}),o.disconnect.push(function(){n.tryDelayedConnect()}),t.each(["connect_error","reconnect_error","error"],function(e){o[e].push(function(e){n.tryDelayedConnect(),n.triggerSocket("connect_failed")})}),t.each(["connect_timeout","reconnect_failed"],function(e){o[e].push(function(e){})}),t.each(o,function(n,o){t.each(n,function(t){e.once(o,t)})}),n.bindCustomEvents(e)},bindCustomEvents:function(e){(e=e||this.socket)&&t.each(this.customEvents,function(n,o){t.each(n,function(t){e.off?e.off(o,t):e.removeListener&&e.removeListener(o,t),e.on(o,t)})})},incrUuriCount:function(e){d[e]=t.has(d,e)?d[e]+1:1},connect:function(){var n=this;e.when(n.getSocketUri(),n.getQuery()).done(function(e,c){var i,r=n.uuri=e+":"+c.room;!n.destroyed&&(t.has(s,r)?((i=n.socket=s[r]).io.opts.query.token=c.token,i.connect()):(i=n.socket=o.connect(e,{reconnect:!1,"max reconnection attempts":1,reconnection:!1,reconnectionAttempts:1,"force new connection":!0,multiplex:!1,query:c}),s[r]=i),n.bindEvents(i),d[r]=n.getUuriCount()+1,i.connected&&n.triggerSocket("connect"))})},reconnect:function(){var e=this;e.socket&&e.resetToken().done(function(){e.bindEvents(e.socket),e.socket.reconnect()})},resetRetryCount:function(){this.retryCount=0},abortXHR:function(){t.each(a,function(e){c.abortXHR(e)}),a={}},destroySocket:function(){var e=this.socket,n=this.uuri;if(e){var o=function(n){t.each(n,function(n,o){t.each(n,function(t){e.off(o,t)})})};o(this.customEvents),o(this.ioEvents),0==(d[n]=this.getUuriCount()-1)&&this.delayedDisconnect()}},destroy:function(){this.destroyed=!0,window.clearTimeout(this.connectTimer),window.clearTimeout(this.reconnectTimer),this.abortXHR(),this.destroySocket(),delete this.ioEvents,delete this.customEvents,delete this.pendingEvents,delete this.socket,delete this.connectTimer,delete this.reconnectTimer},onSocket:function(e,t){this.socket&&this.socket.on(e,t),this.customEvents[e]||(this.customEvents[e]=[]),this.customEvents[e].push(t)},triggerSocket:function(e,n){var o=this,c=o.customEvents;c&&c[e]&&t.each(c[e],function(e){e.call(o.socket,n)})},emit:function(e,n){n=t.defaults(n||{},{room:this.get("room")}),this.socket?this.socket.emit(e,n):this.pendingEvents.push({event:e,data:n})},emitSocket:function(e,t){this.emit(e,t)}})});
/*! iScroll v5.1.3 ~ (c) 2008-2014 Matteo Spinelli ~ http://cubiq.org/license */
(function (window, document, Math) {
var rAF = window.requestAnimationFrame	||
	window.webkitRequestAnimationFrame	||
	window.mozRequestAnimationFrame		||
	window.oRequestAnimationFrame		||
	window.msRequestAnimationFrame		||
	function (callback) { window.setTimeout(callback, 1000 / 60); };

var utils = (function () {
	var me = {};

	var _elementStyle = document.createElement('div').style;
	var _vendor = (function () {
		var vendors = ['t', 'webkitT', 'MozT', 'msT', 'OT'],
			transform,
			i = 0,
			l = vendors.length;

		for ( ; i < l; i++ ) {
			transform = vendors[i] + 'ransform';
			if ( transform in _elementStyle ) return vendors[i].substr(0, vendors[i].length-1);
		}

		return false;
	})();

	function _prefixStyle (style) {
		if ( _vendor === false ) return false;
		if ( _vendor === '' ) return style;
		return _vendor + style.charAt(0).toUpperCase() + style.substr(1);
	}

	me.getTime = Date.now || function getTime () { return new Date().getTime(); };

	me.extend = function (target, obj) {
		for ( var i in obj ) {
			target[i] = obj[i];
		}
	};

	me.addEvent = function (el, type, fn, capture) {
		el.addEventListener(type, fn, !!capture);
	};

	me.removeEvent = function (el, type, fn, capture) {
		el.removeEventListener(type, fn, !!capture);
	};

	me.prefixPointerEvent = function (pointerEvent) {
		return window.MSPointerEvent ? 
			'MSPointer' + pointerEvent.charAt(9).toUpperCase() + pointerEvent.substr(10):
			pointerEvent;
	};

	me.momentum = function (current, start, time, lowerMargin, wrapperSize, deceleration) {
		var distance = current - start,
			speed = Math.abs(distance) / time,
			destination,
			duration;

		deceleration = deceleration === undefined ? 0.0006 : deceleration;

		destination = current + ( speed * speed ) / ( 2 * deceleration ) * ( distance < 0 ? -1 : 1 );
		duration = speed / deceleration;

		if ( destination < lowerMargin ) {
			destination = wrapperSize ? lowerMargin - ( wrapperSize / 2.5 * ( speed / 8 ) ) : lowerMargin;
			distance = Math.abs(destination - current);
			duration = distance / speed;
		} else if ( destination > 0 ) {
			destination = wrapperSize ? wrapperSize / 2.5 * ( speed / 8 ) : 0;
			distance = Math.abs(current) + destination;
			duration = distance / speed;
		}

		return {
			destination: Math.round(destination),
			duration: duration
		};
	};

	var _transform = _prefixStyle('transform');

	me.extend(me, {
		hasTransform: _transform !== false,
		hasPerspective: _prefixStyle('perspective') in _elementStyle,
		hasTouch: 'ontouchstart' in window,
		hasPointer: window.PointerEvent || window.MSPointerEvent, // IE10 is prefixed
		hasTransition: _prefixStyle('transition') in _elementStyle
	});

	// This should find all Android browsers lower than build 535.19 (both stock browser and webview)
	me.isBadAndroid = /Android /.test(window.navigator.appVersion) && !(/Chrome\/\d/.test(window.navigator.appVersion));

	me.extend(me.style = {}, {
		transform: _transform,
		transitionTimingFunction: _prefixStyle('transitionTimingFunction'),
		transitionDuration: _prefixStyle('transitionDuration'),
		transitionDelay: _prefixStyle('transitionDelay'),
		transformOrigin: _prefixStyle('transformOrigin')
	});

	me.hasClass = function (e, c) {
		var re = new RegExp("(^|\\s)" + c + "(\\s|$)");
		return re.test(e.className);
	};

	me.addClass = function (e, c) {
		if ( me.hasClass(e, c) ) {
			return;
		}

		var newclass = e.className.split(' ');
		newclass.push(c);
		e.className = newclass.join(' ');
	};

	me.removeClass = function (e, c) {
		if ( !me.hasClass(e, c) ) {
			return;
		}

		var re = new RegExp("(^|\\s)" + c + "(\\s|$)", 'g');
		e.className = e.className.replace(re, ' ');
	};

	me.offset = function (el) {
		var left = -el.offsetLeft,
			top = -el.offsetTop;

		// jshint -W084
		while (el = el.offsetParent) {
			left -= el.offsetLeft;
			top -= el.offsetTop;
		}
		// jshint +W084

		return {
			left: left,
			top: top
		};
	};

	me.preventDefaultException = function (el, exceptions) {
		for ( var i in exceptions ) {
			if ( exceptions[i].test(el[i]) ) {
				return true;
			}
		}

		return false;
	};

	me.extend(me.eventType = {}, {
		touchstart: 1,
		touchmove: 1,
		touchend: 1,

		mousedown: 2,
		mousemove: 2,
		mouseup: 2,

		pointerdown: 3,
		pointermove: 3,
		pointerup: 3,

		MSPointerDown: 3,
		MSPointerMove: 3,
		MSPointerUp: 3
	});

	me.extend(me.ease = {}, {
		quadratic: {
			style: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
			fn: function (k) {
				return k * ( 2 - k );
			}
		},
		circular: {
			style: 'cubic-bezier(0.1, 0.57, 0.1, 1)',	// Not properly "circular" but this looks better, it should be (0.075, 0.82, 0.165, 1)
			fn: function (k) {
				return Math.sqrt( 1 - ( --k * k ) );
			}
		},
		back: {
			style: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
			fn: function (k) {
				var b = 4;
				return ( k = k - 1 ) * k * ( ( b + 1 ) * k + b ) + 1;
			}
		},
		bounce: {
			style: '',
			fn: function (k) {
				if ( ( k /= 1 ) < ( 1 / 2.75 ) ) {
					return 7.5625 * k * k;
				} else if ( k < ( 2 / 2.75 ) ) {
					return 7.5625 * ( k -= ( 1.5 / 2.75 ) ) * k + 0.75;
				} else if ( k < ( 2.5 / 2.75 ) ) {
					return 7.5625 * ( k -= ( 2.25 / 2.75 ) ) * k + 0.9375;
				} else {
					return 7.5625 * ( k -= ( 2.625 / 2.75 ) ) * k + 0.984375;
				}
			}
		},
		elastic: {
			style: '',
			fn: function (k) {
				var f = 0.22,
					e = 0.4;

				if ( k === 0 ) { return 0; }
				if ( k == 1 ) { return 1; }

				return ( e * Math.pow( 2, - 10 * k ) * Math.sin( ( k - f / 4 ) * ( 2 * Math.PI ) / f ) + 1 );
			}
		}
	});

	me.tap = function (e, eventName) {
		var ev = document.createEvent('Event');
		ev.initEvent(eventName, true, true);
		ev.pageX = e.pageX;
		ev.pageY = e.pageY;
		e.target.dispatchEvent(ev);
	};

	me.click = function (e) {
		var target = e.target,
			ev;

		if ( !(/(SELECT|INPUT|TEXTAREA)/i).test(target.tagName) ) {
			ev = document.createEvent('MouseEvents');
			ev.initMouseEvent('click', true, true, e.view, 1,
				target.screenX, target.screenY, target.clientX, target.clientY,
				e.ctrlKey, e.altKey, e.shiftKey, e.metaKey,
				0, null);

			ev._constructed = true;
			target.dispatchEvent(ev);
		}
	};

	return me;
})();

function IScroll (el, options) {
	this.wrapper = typeof el == 'string' ? document.querySelector(el) : el;
	this.scroller = this.wrapper.children[0];
	this.scrollerStyle = this.scroller.style;		// cache style for better performance

	this.options = {

		resizeScrollbars: true,

		mouseWheelSpeed: 20,

		snapThreshold: 0.334,

// INSERT POINT: OPTIONS 

		startX: 0,
		startY: 0,
		scrollY: true,
		directionLockThreshold: 5,
		momentum: true,

		bounce: true,
		bounceTime: 600,
		bounceEasing: '',

		preventDefault: true,
		preventDefaultException: { tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT)$/ },

		HWCompositing: true,
		useTransition: true,
		useTransform: true
	};

	for ( var i in options ) {
		this.options[i] = options[i];
	}

	// Normalize options
	this.translateZ = this.options.HWCompositing && utils.hasPerspective ? ' translateZ(0)' : '';

	this.options.useTransition = utils.hasTransition && this.options.useTransition;
	this.options.useTransform = utils.hasTransform && this.options.useTransform;

	this.options.eventPassthrough = this.options.eventPassthrough === true ? 'vertical' : this.options.eventPassthrough;
	this.options.preventDefault = !this.options.eventPassthrough && this.options.preventDefault;

	// If you want eventPassthrough I have to lock one of the axes
	this.options.scrollY = this.options.eventPassthrough == 'vertical' ? false : this.options.scrollY;
	this.options.scrollX = this.options.eventPassthrough == 'horizontal' ? false : this.options.scrollX;

	// With eventPassthrough we also need lockDirection mechanism
	this.options.freeScroll = this.options.freeScroll && !this.options.eventPassthrough;
	this.options.directionLockThreshold = this.options.eventPassthrough ? 0 : this.options.directionLockThreshold;

	this.options.bounceEasing = typeof this.options.bounceEasing == 'string' ? utils.ease[this.options.bounceEasing] || utils.ease.circular : this.options.bounceEasing;

	this.options.resizePolling = this.options.resizePolling === undefined ? 60 : this.options.resizePolling;

	if ( this.options.tap === true ) {
		this.options.tap = 'tap';
	}

	if ( this.options.shrinkScrollbars == 'scale' ) {
		this.options.useTransition = false;
	}

	this.options.invertWheelDirection = this.options.invertWheelDirection ? -1 : 1;

// INSERT POINT: NORMALIZATION

	// Some defaults	
	this.x = 0;
	this.y = 0;
	this.directionX = 0;
	this.directionY = 0;
	this._events = {};

// INSERT POINT: DEFAULTS

	this._init();
	this.refresh();

	this.scrollTo(this.options.startX, this.options.startY);
	this.enable();
}

IScroll.prototype = {
	version: '5.1.3',

	_init: function () {
		this._initEvents();

		if ( this.options.scrollbars || this.options.indicators ) {
			this._initIndicators();
		}

		if ( this.options.mouseWheel ) {
			this._initWheel();
		}

		if ( this.options.snap ) {
			this._initSnap();
		}

		if ( this.options.keyBindings ) {
			this._initKeys();
		}

// INSERT POINT: _init

	},

	destroy: function () {
		this._initEvents(true);

		this._execEvent('destroy');
	},

	_transitionEnd: function (e) {
		if ( e.target != this.scroller || !this.isInTransition ) {
			return;
		}

		this._transitionTime();
		if ( !this.resetPosition(this.options.bounceTime) ) {
			this.isInTransition = false;
			this._execEvent('scrollEnd');
		}
	},

	_start: function (e) {
		// React to left mouse button only
		if ( utils.eventType[e.type] != 1 ) {
			if ( e.button !== 0 ) {
				return;
			}
		}

		if ( !this.enabled || (this.initiated && utils.eventType[e.type] !== this.initiated) ) {
			return;
		}

		if ( this.options.preventDefault && !utils.isBadAndroid && !utils.preventDefaultException(e.target, this.options.preventDefaultException) ) {
			e.preventDefault();
		}

		var point = e.touches ? e.touches[0] : e,
			pos;

		this.initiated	= utils.eventType[e.type];
		this.moved		= false;
		this.distX		= 0;
		this.distY		= 0;
		this.directionX = 0;
		this.directionY = 0;
		this.directionLocked = 0;

		this._transitionTime();

		this.startTime = utils.getTime();

		if ( this.options.useTransition && this.isInTransition ) {
			this.isInTransition = false;
			pos = this.getComputedPosition();
			this._translate(Math.round(pos.x), Math.round(pos.y));
			this._execEvent('scrollEnd');
		} else if ( !this.options.useTransition && this.isAnimating ) {
			this.isAnimating = false;
			this._execEvent('scrollEnd');
		}

		this.startX    = this.x;
		this.startY    = this.y;
		this.absStartX = this.x;
		this.absStartY = this.y;
		this.pointX    = point.pageX;
		this.pointY    = point.pageY;

		this._execEvent('beforeScrollStart');
	},

	_move: function (e) {
		if ( !this.enabled || utils.eventType[e.type] !== this.initiated ) {
			return;
		}

		if ( this.options.preventDefault ) {	// increases performance on Android? TODO: check!
			e.preventDefault();
		}

		var point		= e.touches ? e.touches[0] : e,
			deltaX		= point.pageX - this.pointX,
			deltaY		= point.pageY - this.pointY,
			timestamp	= utils.getTime(),
			newX, newY,
			absDistX, absDistY;

		this.pointX		= point.pageX;
		this.pointY		= point.pageY;

		this.distX		+= deltaX;
		this.distY		+= deltaY;
		absDistX		= Math.abs(this.distX);
		absDistY		= Math.abs(this.distY);

		// We need to move at least 10 pixels for the scrolling to initiate
		if ( timestamp - this.endTime > 300 && (absDistX < 10 && absDistY < 10) ) {
			return;
		}

		// If you are scrolling in one direction lock the other
		if ( !this.directionLocked && !this.options.freeScroll ) {
			if ( absDistX > absDistY + this.options.directionLockThreshold ) {
				this.directionLocked = 'h';		// lock horizontally
			} else if ( absDistY >= absDistX + this.options.directionLockThreshold ) {
				this.directionLocked = 'v';		// lock vertically
			} else {
				this.directionLocked = 'n';		// no lock
			}
		}

		if ( this.directionLocked == 'h' ) {
			if ( this.options.eventPassthrough == 'vertical' ) {
				e.preventDefault();
			} else if ( this.options.eventPassthrough == 'horizontal' ) {
				this.initiated = false;
				return;
			}

			deltaY = 0;
		} else if ( this.directionLocked == 'v' ) {
			if ( this.options.eventPassthrough == 'horizontal' ) {
				e.preventDefault();
			} else if ( this.options.eventPassthrough == 'vertical' ) {
				this.initiated = false;
				return;
			}

			deltaX = 0;
		}

		deltaX = this.hasHorizontalScroll ? deltaX : 0;
		deltaY = this.hasVerticalScroll ? deltaY : 0;

		newX = this.x + deltaX;
		newY = this.y + deltaY;

		// Slow down if outside of the boundaries
		if ( newX > 0 || newX < this.maxScrollX ) {
			newX = this.options.bounce ? this.x + deltaX / 3 : newX > 0 ? 0 : this.maxScrollX;
		}
		if ( newY > 0 || newY < this.maxScrollY ) {
			newY = this.options.bounce ? this.y + deltaY / 3 : newY > 0 ? 0 : this.maxScrollY;
		}

		this.directionX = deltaX > 0 ? -1 : deltaX < 0 ? 1 : 0;
		this.directionY = deltaY > 0 ? -1 : deltaY < 0 ? 1 : 0;

		if ( !this.moved ) {
			this._execEvent('scrollStart');
		}

		this.moved = true;

		this._translate(newX, newY);

/* REPLACE START: _move */

		if ( timestamp - this.startTime > 300 ) {
			this.startTime = timestamp;
			this.startX = this.x;
			this.startY = this.y;
		}

/* REPLACE END: _move */

	},

	_end: function (e) {
		if ( !this.enabled || utils.eventType[e.type] !== this.initiated ) {
			return;
		}

		if ( this.options.preventDefault && !utils.preventDefaultException(e.target, this.options.preventDefaultException) ) {
			e.preventDefault();
		}

		var point = e.changedTouches ? e.changedTouches[0] : e,
			momentumX,
			momentumY,
			duration = utils.getTime() - this.startTime,
			newX = Math.round(this.x),
			newY = Math.round(this.y),
			distanceX = Math.abs(newX - this.startX),
			distanceY = Math.abs(newY - this.startY),
			time = 0,
			easing = '';

		this.isInTransition = 0;
		this.initiated = 0;
		this.endTime = utils.getTime();

		// reset if we are outside of the boundaries
		if ( this.resetPosition(this.options.bounceTime) ) {
			return;
		}

		this.scrollTo(newX, newY);	// ensures that the last position is rounded

		// we scrolled less than 10 pixels
		if ( !this.moved ) {
			if ( this.options.tap ) {
				utils.tap(e, this.options.tap);
			}

			if ( this.options.click ) {
				utils.click(e);
			}

			this._execEvent('scrollCancel');
			return;
		}

		if ( this._events.flick && duration < 200 && distanceX < 100 && distanceY < 100 ) {
			this._execEvent('flick');
			return;
		}

		// start momentum animation if needed
		if ( this.options.momentum && duration < 300 ) {
			momentumX = this.hasHorizontalScroll ? utils.momentum(this.x, this.startX, duration, this.maxScrollX, this.options.bounce ? this.wrapperWidth : 0, this.options.deceleration) : { destination: newX, duration: 0 };
			momentumY = this.hasVerticalScroll ? utils.momentum(this.y, this.startY, duration, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration) : { destination: newY, duration: 0 };
			newX = momentumX.destination;
			newY = momentumY.destination;
			time = Math.max(momentumX.duration, momentumY.duration);
			this.isInTransition = 1;
		}


		if ( this.options.snap ) {
			var snap = this._nearestSnap(newX, newY);
			this.currentPage = snap;
			time = this.options.snapSpeed || Math.max(
					Math.max(
						Math.min(Math.abs(newX - snap.x), 1000),
						Math.min(Math.abs(newY - snap.y), 1000)
					), 300);
			newX = snap.x;
			newY = snap.y;

			this.directionX = 0;
			this.directionY = 0;
			easing = this.options.bounceEasing;
		}

// INSERT POINT: _end

		if ( newX != this.x || newY != this.y ) {
			// change easing function when scroller goes out of the boundaries
			if ( newX > 0 || newX < this.maxScrollX || newY > 0 || newY < this.maxScrollY ) {
				easing = utils.ease.quadratic;
			}

			this.scrollTo(newX, newY, time, easing);
			return;
		}

		this._execEvent('scrollEnd');
	},

	_resize: function () {
		var that = this;

		clearTimeout(this.resizeTimeout);

		this.resizeTimeout = setTimeout(function () {
			that.refresh();
		}, this.options.resizePolling);
	},

	resetPosition: function (time) {
		var x = this.x,
			y = this.y;

		time = time || 0;

		if ( !this.hasHorizontalScroll || this.x > 0 ) {
			x = 0;
		} else if ( this.x < this.maxScrollX ) {
			x = this.maxScrollX;
		}

		if ( !this.hasVerticalScroll || this.y > 0 ) {
			y = 0;
		} else if ( this.y < this.maxScrollY ) {
			y = this.maxScrollY;
		}

		if ( x == this.x && y == this.y ) {
			return false;
		}

		this.scrollTo(x, y, time, this.options.bounceEasing);

		return true;
	},

	disable: function () {
		this.enabled = false;
	},

	enable: function () {
		this.enabled = true;
	},

	refresh: function () {
		var rf = this.wrapper.offsetHeight;		// Force reflow

		this.wrapperWidth	= this.wrapper.clientWidth;
		this.wrapperHeight	= this.wrapper.clientHeight;

/* REPLACE START: refresh */

		this.scrollerWidth	= this.scroller.offsetWidth;
		this.scrollerHeight	= this.scroller.offsetHeight;

		this.maxScrollX		= this.wrapperWidth - this.scrollerWidth;
		this.maxScrollY		= this.wrapperHeight - this.scrollerHeight;

/* REPLACE END: refresh */

		this.hasHorizontalScroll	= this.options.scrollX && this.maxScrollX < 0;
		this.hasVerticalScroll		= this.options.scrollY && this.maxScrollY < 0;

		if ( !this.hasHorizontalScroll ) {
			this.maxScrollX = 0;
			this.scrollerWidth = this.wrapperWidth;
		}

		if ( !this.hasVerticalScroll ) {
			this.maxScrollY = 0;
			this.scrollerHeight = this.wrapperHeight;
		}

		this.endTime = 0;
		this.directionX = 0;
		this.directionY = 0;

		this.wrapperOffset = utils.offset(this.wrapper);

		this._execEvent('refresh');

		this.resetPosition();

// INSERT POINT: _refresh

	},

	on: function (type, fn) {
		if ( !this._events[type] ) {
			this._events[type] = [];
		}

		this._events[type].push(fn);
	},

	off: function (type, fn) {
		if ( !this._events[type] ) {
			return;
		}

		var index = this._events[type].indexOf(fn);

		if ( index > -1 ) {
			this._events[type].splice(index, 1);
		}
	},

	_execEvent: function (type) {
		if ( !this._events[type] ) {
			return;
		}

		var i = 0,
			l = this._events[type].length;

		if ( !l ) {
			return;
		}

		for ( ; i < l; i++ ) {
			this._events[type][i].apply(this, [].slice.call(arguments, 1));
		}
	},

	scrollBy: function (x, y, time, easing) {
		x = this.x + x;
		y = this.y + y;
		time = time || 0;

		this.scrollTo(x, y, time, easing);
	},

	scrollTo: function (x, y, time, easing) {
		easing = easing || utils.ease.circular;

		this.isInTransition = this.options.useTransition && time > 0;

		if ( !time || (this.options.useTransition && easing.style) ) {
			this._transitionTimingFunction(easing.style);
			this._transitionTime(time);
			this._translate(x, y);
		} else {
			this._animate(x, y, time, easing.fn);
		}
	},

	scrollToElement: function (el, time, offsetX, offsetY, easing) {
		el = el.nodeType ? el : this.scroller.querySelector(el);

		if ( !el ) {
			return;
		}

		var pos = utils.offset(el);

		pos.left -= this.wrapperOffset.left;
		pos.top  -= this.wrapperOffset.top;

		// if offsetX/Y are true we center the element to the screen
		if ( offsetX === true ) {
			offsetX = Math.round(el.offsetWidth / 2 - this.wrapper.offsetWidth / 2);
		}
		if ( offsetY === true ) {
			offsetY = Math.round(el.offsetHeight / 2 - this.wrapper.offsetHeight / 2);
		}

		pos.left -= offsetX || 0;
		pos.top  -= offsetY || 0;

		pos.left = pos.left > 0 ? 0 : pos.left < this.maxScrollX ? this.maxScrollX : pos.left;
		pos.top  = pos.top  > 0 ? 0 : pos.top  < this.maxScrollY ? this.maxScrollY : pos.top;

		time = time === undefined || time === null || time === 'auto' ? Math.max(Math.abs(this.x-pos.left), Math.abs(this.y-pos.top)) : time;

		this.scrollTo(pos.left, pos.top, time, easing);
	},

	_transitionTime: function (time) {
		time = time || 0;

		this.scrollerStyle[utils.style.transitionDuration] = time + 'ms';

		if ( !time && utils.isBadAndroid ) {
			this.scrollerStyle[utils.style.transitionDuration] = '0.001s';
		}


		if ( this.indicators ) {
			for ( var i = this.indicators.length; i--; ) {
				this.indicators[i].transitionTime(time);
			}
		}


// INSERT POINT: _transitionTime

	},

	_transitionTimingFunction: function (easing) {
		this.scrollerStyle[utils.style.transitionTimingFunction] = easing;


		if ( this.indicators ) {
			for ( var i = this.indicators.length; i--; ) {
				this.indicators[i].transitionTimingFunction(easing);
			}
		}


// INSERT POINT: _transitionTimingFunction

	},

	_translate: function (x, y) {
		if ( this.options.useTransform ) {

/* REPLACE START: _translate */

			this.scrollerStyle[utils.style.transform] = 'translate(' + x + 'px,' + y + 'px)' + this.translateZ;

/* REPLACE END: _translate */

		} else {
			x = Math.round(x);
			y = Math.round(y);
			this.scrollerStyle.left = x + 'px';
			this.scrollerStyle.top = y + 'px';
		}

		this.x = x;
		this.y = y;


	if ( this.indicators ) {
		for ( var i = this.indicators.length; i--; ) {
			this.indicators[i].updatePosition();
		}
	}


// INSERT POINT: _translate

	},

	_initEvents: function (remove) {
		var eventType = remove ? utils.removeEvent : utils.addEvent,
			target = this.options.bindToWrapper ? this.wrapper : window;

		eventType(window, 'orientationchange', this);
		eventType(window, 'resize', this);

		if ( this.options.click ) {
			eventType(this.wrapper, 'click', this, true);
		}

		if ( !this.options.disableMouse ) {
			eventType(this.wrapper, 'mousedown', this);
			eventType(target, 'mousemove', this);
			eventType(target, 'mousecancel', this);
			eventType(target, 'mouseup', this);
		}

		if ( utils.hasPointer && !this.options.disablePointer ) {
			eventType(this.wrapper, utils.prefixPointerEvent('pointerdown'), this);
			eventType(target, utils.prefixPointerEvent('pointermove'), this);
			eventType(target, utils.prefixPointerEvent('pointercancel'), this);
			eventType(target, utils.prefixPointerEvent('pointerup'), this);
		}

		if ( utils.hasTouch && !this.options.disableTouch ) {
			eventType(this.wrapper, 'touchstart', this);
			eventType(target, 'touchmove', this);
			eventType(target, 'touchcancel', this);
			eventType(target, 'touchend', this);
		}

		eventType(this.scroller, 'transitionend', this);
		eventType(this.scroller, 'webkitTransitionEnd', this);
		eventType(this.scroller, 'oTransitionEnd', this);
		eventType(this.scroller, 'MSTransitionEnd', this);
	},

	getComputedPosition: function () {
		var matrix = window.getComputedStyle(this.scroller, null),
			x, y;

		if ( this.options.useTransform ) {
			matrix = matrix[utils.style.transform].split(')')[0].split(', ');
			x = +(matrix[12] || matrix[4]);
			y = +(matrix[13] || matrix[5]);
		} else {
			x = +matrix.left.replace(/[^-\d.]/g, '');
			y = +matrix.top.replace(/[^-\d.]/g, '');
		}

		return { x: x, y: y };
	},

	_initIndicators: function () {
		var interactive = this.options.interactiveScrollbars,
			customStyle = typeof this.options.scrollbars != 'string',
			indicators = [],
			indicator;

		var that = this;

		this.indicators = [];

		if ( this.options.scrollbars ) {
			// Vertical scrollbar
			if ( this.options.scrollY ) {
				indicator = {
					el: createDefaultScrollbar('v', interactive, this.options.scrollbars),
					interactive: interactive,
					defaultScrollbars: true,
					customStyle: customStyle,
					resize: this.options.resizeScrollbars,
					shrink: this.options.shrinkScrollbars,
					fade: this.options.fadeScrollbars,
					listenX: false
				};

				this.wrapper.appendChild(indicator.el);
				indicators.push(indicator);
			}

			// Horizontal scrollbar
			if ( this.options.scrollX ) {
				indicator = {
					el: createDefaultScrollbar('h', interactive, this.options.scrollbars),
					interactive: interactive,
					defaultScrollbars: true,
					customStyle: customStyle,
					resize: this.options.resizeScrollbars,
					shrink: this.options.shrinkScrollbars,
					fade: this.options.fadeScrollbars,
					listenY: false
				};

				this.wrapper.appendChild(indicator.el);
				indicators.push(indicator);
			}
		}

		if ( this.options.indicators ) {
			// TODO: check concat compatibility
			indicators = indicators.concat(this.options.indicators);
		}

		for ( var i = indicators.length; i--; ) {
			this.indicators.push( new Indicator(this, indicators[i]) );
		}

		// TODO: check if we can use array.map (wide compatibility and performance issues)
		function _indicatorsMap (fn) {
			for ( var i = that.indicators.length; i--; ) {
				fn.call(that.indicators[i]);
			}
		}

		if ( this.options.fadeScrollbars ) {
			this.on('scrollEnd', function () {
				_indicatorsMap(function () {
					this.fade();
				});
			});

			this.on('scrollCancel', function () {
				_indicatorsMap(function () {
					this.fade();
				});
			});

			this.on('scrollStart', function () {
				_indicatorsMap(function () {
					this.fade(1);
				});
			});

			this.on('beforeScrollStart', function () {
				_indicatorsMap(function () {
					this.fade(1, true);
				});
			});
		}


		this.on('refresh', function () {
			_indicatorsMap(function () {
				this.refresh();
			});
		});

		this.on('destroy', function () {
			_indicatorsMap(function () {
				this.destroy();
			});

			delete this.indicators;
		});
	},

	_initWheel: function () {
		utils.addEvent(this.wrapper, 'wheel', this);
		utils.addEvent(this.wrapper, 'mousewheel', this);
		utils.addEvent(this.wrapper, 'DOMMouseScroll', this);

		this.on('destroy', function () {
			utils.removeEvent(this.wrapper, 'wheel', this);
			utils.removeEvent(this.wrapper, 'mousewheel', this);
			utils.removeEvent(this.wrapper, 'DOMMouseScroll', this);
		});
	},

	_wheel: function (e) {
		if ( !this.enabled ) {
			return;
		}

		e.preventDefault();
		e.stopPropagation();

		var wheelDeltaX, wheelDeltaY,
			newX, newY,
			that = this;

		if ( this.wheelTimeout === undefined ) {
			that._execEvent('scrollStart');
		}

		// Execute the scrollEnd event after 400ms the wheel stopped scrolling
		clearTimeout(this.wheelTimeout);
		this.wheelTimeout = setTimeout(function () {
			that._execEvent('scrollEnd');
			that.wheelTimeout = undefined;
		}, 400);

		if ( 'deltaX' in e ) {
			if (e.deltaMode === 1) {
				wheelDeltaX = -e.deltaX * this.options.mouseWheelSpeed;
				wheelDeltaY = -e.deltaY * this.options.mouseWheelSpeed;
			} else {
				wheelDeltaX = -e.deltaX;
				wheelDeltaY = -e.deltaY;
			}
		} else if ( 'wheelDeltaX' in e ) {
			wheelDeltaX = e.wheelDeltaX / 120 * this.options.mouseWheelSpeed;
			wheelDeltaY = e.wheelDeltaY / 120 * this.options.mouseWheelSpeed;
		} else if ( 'wheelDelta' in e ) {
			wheelDeltaX = wheelDeltaY = e.wheelDelta / 120 * this.options.mouseWheelSpeed;
		} else if ( 'detail' in e ) {
			wheelDeltaX = wheelDeltaY = -e.detail / 3 * this.options.mouseWheelSpeed;
		} else {
			return;
		}

		wheelDeltaX *= this.options.invertWheelDirection;
		wheelDeltaY *= this.options.invertWheelDirection;

		if ( !this.hasVerticalScroll ) {
			wheelDeltaX = wheelDeltaY;
			wheelDeltaY = 0;
		}

		if ( this.options.snap ) {
			newX = this.currentPage.pageX;
			newY = this.currentPage.pageY;

			if ( wheelDeltaX > 0 ) {
				newX--;
			} else if ( wheelDeltaX < 0 ) {
				newX++;
			}

			if ( wheelDeltaY > 0 ) {
				newY--;
			} else if ( wheelDeltaY < 0 ) {
				newY++;
			}

			this.goToPage(newX, newY);

			return;
		}

		newX = this.x + Math.round(this.hasHorizontalScroll ? wheelDeltaX : 0);
		newY = this.y + Math.round(this.hasVerticalScroll ? wheelDeltaY : 0);

		if ( newX > 0 ) {
			newX = 0;
		} else if ( newX < this.maxScrollX ) {
			newX = this.maxScrollX;
		}

		if ( newY > 0 ) {
			newY = 0;
		} else if ( newY < this.maxScrollY ) {
			newY = this.maxScrollY;
		}

		this.scrollTo(newX, newY, 0);

// INSERT POINT: _wheel
	},

	_initSnap: function () {
		this.currentPage = {};

		if ( typeof this.options.snap == 'string' ) {
			this.options.snap = this.scroller.querySelectorAll(this.options.snap);
		}

		this.on('refresh', function () {
			var i = 0, l,
				m = 0, n,
				cx, cy,
				x = 0, y,
				stepX = this.options.snapStepX || this.wrapperWidth,
				stepY = this.options.snapStepY || this.wrapperHeight,
				el;

			this.pages = [];

			if ( !this.wrapperWidth || !this.wrapperHeight || !this.scrollerWidth || !this.scrollerHeight ) {
				return;
			}

			if ( this.options.snap === true ) {
				cx = Math.round( stepX / 2 );
				cy = Math.round( stepY / 2 );

				while ( x > -this.scrollerWidth ) {
					this.pages[i] = [];
					l = 0;
					y = 0;

					while ( y > -this.scrollerHeight ) {
						this.pages[i][l] = {
							x: Math.max(x, this.maxScrollX),
							y: Math.max(y, this.maxScrollY),
							width: stepX,
							height: stepY,
							cx: x - cx,
							cy: y - cy
						};

						y -= stepY;
						l++;
					}

					x -= stepX;
					i++;
				}
			} else {
				el = this.options.snap;
				l = el.length;
				n = -1;

				for ( ; i < l; i++ ) {
					if ( i === 0 || el[i].offsetLeft <= el[i-1].offsetLeft ) {
						m = 0;
						n++;
					}

					if ( !this.pages[m] ) {
						this.pages[m] = [];
					}

					x = Math.max(-el[i].offsetLeft, this.maxScrollX);
					y = Math.max(-el[i].offsetTop, this.maxScrollY);
					cx = x - Math.round(el[i].offsetWidth / 2);
					cy = y - Math.round(el[i].offsetHeight / 2);

					this.pages[m][n] = {
						x: x,
						y: y,
						width: el[i].offsetWidth,
						height: el[i].offsetHeight,
						cx: cx,
						cy: cy
					};

					if ( x > this.maxScrollX ) {
						m++;
					}
				}
			}

			this.goToPage(this.currentPage.pageX || 0, this.currentPage.pageY || 0, 0);

			// Update snap threshold if needed
			if ( this.options.snapThreshold % 1 === 0 ) {
				this.snapThresholdX = this.options.snapThreshold;
				this.snapThresholdY = this.options.snapThreshold;
			} else {
				this.snapThresholdX = Math.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].width * this.options.snapThreshold);
				this.snapThresholdY = Math.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].height * this.options.snapThreshold);
			}
		});

		this.on('flick', function () {
			var time = this.options.snapSpeed || Math.max(
					Math.max(
						Math.min(Math.abs(this.x - this.startX), 1000),
						Math.min(Math.abs(this.y - this.startY), 1000)
					), 300);

			this.goToPage(
				this.currentPage.pageX + this.directionX,
				this.currentPage.pageY + this.directionY,
				time
			);
		});
	},

	_nearestSnap: function (x, y) {
		if ( !this.pages.length ) {
			return { x: 0, y: 0, pageX: 0, pageY: 0 };
		}

		var i = 0,
			l = this.pages.length,
			m = 0;

		// Check if we exceeded the snap threshold
		if ( Math.abs(x - this.absStartX) < this.snapThresholdX &&
			Math.abs(y - this.absStartY) < this.snapThresholdY ) {
			return this.currentPage;
		}

		if ( x > 0 ) {
			x = 0;
		} else if ( x < this.maxScrollX ) {
			x = this.maxScrollX;
		}

		if ( y > 0 ) {
			y = 0;
		} else if ( y < this.maxScrollY ) {
			y = this.maxScrollY;
		}

		for ( ; i < l; i++ ) {
			if ( x >= this.pages[i][0].cx ) {
				x = this.pages[i][0].x;
				break;
			}
		}

		l = this.pages[i].length;

		for ( ; m < l; m++ ) {
			if ( y >= this.pages[0][m].cy ) {
				y = this.pages[0][m].y;
				break;
			}
		}

		if ( i == this.currentPage.pageX ) {
			i += this.directionX;

			if ( i < 0 ) {
				i = 0;
			} else if ( i >= this.pages.length ) {
				i = this.pages.length - 1;
			}

			x = this.pages[i][0].x;
		}

		if ( m == this.currentPage.pageY ) {
			m += this.directionY;

			if ( m < 0 ) {
				m = 0;
			} else if ( m >= this.pages[0].length ) {
				m = this.pages[0].length - 1;
			}

			y = this.pages[0][m].y;
		}

		return {
			x: x,
			y: y,
			pageX: i,
			pageY: m
		};
	},

	goToPage: function (x, y, time, easing) {
		easing = easing || this.options.bounceEasing;

		if ( x >= this.pages.length ) {
			x = this.pages.length - 1;
		} else if ( x < 0 ) {
			x = 0;
		}

		if ( y >= this.pages[x].length ) {
			y = this.pages[x].length - 1;
		} else if ( y < 0 ) {
			y = 0;
		}

		var posX = this.pages[x][y].x,
			posY = this.pages[x][y].y;

		time = time === undefined ? this.options.snapSpeed || Math.max(
			Math.max(
				Math.min(Math.abs(posX - this.x), 1000),
				Math.min(Math.abs(posY - this.y), 1000)
			), 300) : time;

		this.currentPage = {
			x: posX,
			y: posY,
			pageX: x,
			pageY: y
		};

		this.scrollTo(posX, posY, time, easing);
	},

	next: function (time, easing) {
		var x = this.currentPage.pageX,
			y = this.currentPage.pageY;

		x++;

		if ( x >= this.pages.length && this.hasVerticalScroll ) {
			x = 0;
			y++;
		}

		this.goToPage(x, y, time, easing);
	},

	prev: function (time, easing) {
		var x = this.currentPage.pageX,
			y = this.currentPage.pageY;

		x--;

		if ( x < 0 && this.hasVerticalScroll ) {
			x = 0;
			y--;
		}

		this.goToPage(x, y, time, easing);
	},

	_initKeys: function (e) {
		// default key bindings
		var keys = {
			pageUp: 33,
			pageDown: 34,
			end: 35,
			home: 36,
			left: 37,
			up: 38,
			right: 39,
			down: 40
		};
		var i;

		// if you give me characters I give you keycode
		if ( typeof this.options.keyBindings == 'object' ) {
			for ( i in this.options.keyBindings ) {
				if ( typeof this.options.keyBindings[i] == 'string' ) {
					this.options.keyBindings[i] = this.options.keyBindings[i].toUpperCase().charCodeAt(0);
				}
			}
		} else {
			this.options.keyBindings = {};
		}

		for ( i in keys ) {
			this.options.keyBindings[i] = this.options.keyBindings[i] || keys[i];
		}

		utils.addEvent(window, 'keydown', this);

		this.on('destroy', function () {
			utils.removeEvent(window, 'keydown', this);
		});
	},

	_key: function (e) {
		if ( !this.enabled ) {
			return;
		}

		var snap = this.options.snap,	// we are using this alot, better to cache it
			newX = snap ? this.currentPage.pageX : this.x,
			newY = snap ? this.currentPage.pageY : this.y,
			now = utils.getTime(),
			prevTime = this.keyTime || 0,
			acceleration = 0.250,
			pos;

		if ( this.options.useTransition && this.isInTransition ) {
			pos = this.getComputedPosition();

			this._translate(Math.round(pos.x), Math.round(pos.y));
			this.isInTransition = false;
		}

		this.keyAcceleration = now - prevTime < 200 ? Math.min(this.keyAcceleration + acceleration, 50) : 0;

		switch ( e.keyCode ) {
			case this.options.keyBindings.pageUp:
				if ( this.hasHorizontalScroll && !this.hasVerticalScroll ) {
					newX += snap ? 1 : this.wrapperWidth;
				} else {
					newY += snap ? 1 : this.wrapperHeight;
				}
				break;
			case this.options.keyBindings.pageDown:
				if ( this.hasHorizontalScroll && !this.hasVerticalScroll ) {
					newX -= snap ? 1 : this.wrapperWidth;
				} else {
					newY -= snap ? 1 : this.wrapperHeight;
				}
				break;
			case this.options.keyBindings.end:
				newX = snap ? this.pages.length-1 : this.maxScrollX;
				newY = snap ? this.pages[0].length-1 : this.maxScrollY;
				break;
			case this.options.keyBindings.home:
				newX = 0;
				newY = 0;
				break;
			case this.options.keyBindings.left:
				newX += snap ? -1 : 5 + this.keyAcceleration>>0;
				break;
			case this.options.keyBindings.up:
				newY += snap ? 1 : 5 + this.keyAcceleration>>0;
				break;
			case this.options.keyBindings.right:
				newX -= snap ? -1 : 5 + this.keyAcceleration>>0;
				break;
			case this.options.keyBindings.down:
				newY -= snap ? 1 : 5 + this.keyAcceleration>>0;
				break;
			default:
				return;
		}

		if ( snap ) {
			this.goToPage(newX, newY);
			return;
		}

		if ( newX > 0 ) {
			newX = 0;
			this.keyAcceleration = 0;
		} else if ( newX < this.maxScrollX ) {
			newX = this.maxScrollX;
			this.keyAcceleration = 0;
		}

		if ( newY > 0 ) {
			newY = 0;
			this.keyAcceleration = 0;
		} else if ( newY < this.maxScrollY ) {
			newY = this.maxScrollY;
			this.keyAcceleration = 0;
		}

		this.scrollTo(newX, newY, 0);

		this.keyTime = now;
	},

	_animate: function (destX, destY, duration, easingFn) {
		var that = this,
			startX = this.x,
			startY = this.y,
			startTime = utils.getTime(),
			destTime = startTime + duration;

		function step () {
			var now = utils.getTime(),
				newX, newY,
				easing;

			if ( now >= destTime ) {
				that.isAnimating = false;
				that._translate(destX, destY);

				if ( !that.resetPosition(that.options.bounceTime) ) {
					that._execEvent('scrollEnd');
				}

				return;
			}

			now = ( now - startTime ) / duration;
			easing = easingFn(now);
			newX = ( destX - startX ) * easing + startX;
			newY = ( destY - startY ) * easing + startY;
			that._translate(newX, newY);

			if ( that.isAnimating ) {
				rAF(step);
			}
		}

		this.isAnimating = true;
		step();
	},
	handleEvent: function (e) {
		switch ( e.type ) {
			case 'touchstart':
			case 'pointerdown':
			case 'MSPointerDown':
			case 'mousedown':
				this._start(e);
				break;
			case 'touchmove':
			case 'pointermove':
			case 'MSPointerMove':
			case 'mousemove':
				this._move(e);
				break;
			case 'touchend':
			case 'pointerup':
			case 'MSPointerUp':
			case 'mouseup':
			case 'touchcancel':
			case 'pointercancel':
			case 'MSPointerCancel':
			case 'mousecancel':
				this._end(e);
				break;
			case 'orientationchange':
			case 'resize':
				this._resize();
				break;
			case 'transitionend':
			case 'webkitTransitionEnd':
			case 'oTransitionEnd':
			case 'MSTransitionEnd':
				this._transitionEnd(e);
				break;
			case 'wheel':
			case 'DOMMouseScroll':
			case 'mousewheel':
				this._wheel(e);
				break;
			case 'keydown':
				this._key(e);
				break;
			case 'click':
				if ( !e._constructed ) {
					e.preventDefault();
					e.stopPropagation();
				}
				break;
		}
	}
};
function createDefaultScrollbar (direction, interactive, type) {
	var scrollbar = document.createElement('div'),
		indicator = document.createElement('div');

	if ( type === true ) {
		scrollbar.style.cssText = 'position:absolute;z-index:9999';
		indicator.style.cssText = '-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);border-radius:3px';
	}

	indicator.className = 'iScrollIndicator';

	if ( direction == 'h' ) {
		if ( type === true ) {
			scrollbar.style.cssText += ';height:7px;left:2px;right:2px;bottom:0';
			indicator.style.height = '100%';
		}
		scrollbar.className = 'iScrollHorizontalScrollbar';
	} else {
		if ( type === true ) {
			scrollbar.style.cssText += ';width:7px;bottom:2px;top:2px;right:1px';
			indicator.style.width = '100%';
		}
		scrollbar.className = 'iScrollVerticalScrollbar';
	}

	scrollbar.style.cssText += ';overflow:hidden';

	if ( !interactive ) {
		scrollbar.style.pointerEvents = 'none';
	}

	scrollbar.appendChild(indicator);

	return scrollbar;
}

function Indicator (scroller, options) {
	this.wrapper = typeof options.el == 'string' ? document.querySelector(options.el) : options.el;
	this.wrapperStyle = this.wrapper.style;
	this.indicator = this.wrapper.children[0];
	this.indicatorStyle = this.indicator.style;
	this.scroller = scroller;

	this.options = {
		listenX: true,
		listenY: true,
		interactive: false,
		resize: true,
		defaultScrollbars: false,
		shrink: false,
		fade: false,
		speedRatioX: 0,
		speedRatioY: 0
	};

	for ( var i in options ) {
		this.options[i] = options[i];
	}

	this.sizeRatioX = 1;
	this.sizeRatioY = 1;
	this.maxPosX = 0;
	this.maxPosY = 0;

	if ( this.options.interactive ) {
		if ( !this.options.disableTouch ) {
			utils.addEvent(this.indicator, 'touchstart', this);
			utils.addEvent(window, 'touchend', this);
		}
		if ( !this.options.disablePointer ) {
			utils.addEvent(this.indicator, utils.prefixPointerEvent('pointerdown'), this);
			utils.addEvent(window, utils.prefixPointerEvent('pointerup'), this);
		}
		if ( !this.options.disableMouse ) {
			utils.addEvent(this.indicator, 'mousedown', this);
			utils.addEvent(window, 'mouseup', this);
		}
	}

	if ( this.options.fade ) {
		this.wrapperStyle[utils.style.transform] = this.scroller.translateZ;
		this.wrapperStyle[utils.style.transitionDuration] = utils.isBadAndroid ? '0.001s' : '0ms';
		this.wrapperStyle.opacity = '0';
	}
}

Indicator.prototype = {
	handleEvent: function (e) {
		switch ( e.type ) {
			case 'touchstart':
			case 'pointerdown':
			case 'MSPointerDown':
			case 'mousedown':
				this._start(e);
				break;
			case 'touchmove':
			case 'pointermove':
			case 'MSPointerMove':
			case 'mousemove':
				this._move(e);
				break;
			case 'touchend':
			case 'pointerup':
			case 'MSPointerUp':
			case 'mouseup':
			case 'touchcancel':
			case 'pointercancel':
			case 'MSPointerCancel':
			case 'mousecancel':
				this._end(e);
				break;
		}
	},

	destroy: function () {
		if ( this.options.interactive ) {
			utils.removeEvent(this.indicator, 'touchstart', this);
			utils.removeEvent(this.indicator, utils.prefixPointerEvent('pointerdown'), this);
			utils.removeEvent(this.indicator, 'mousedown', this);

			utils.removeEvent(window, 'touchmove', this);
			utils.removeEvent(window, utils.prefixPointerEvent('pointermove'), this);
			utils.removeEvent(window, 'mousemove', this);

			utils.removeEvent(window, 'touchend', this);
			utils.removeEvent(window, utils.prefixPointerEvent('pointerup'), this);
			utils.removeEvent(window, 'mouseup', this);
		}

		if ( this.options.defaultScrollbars ) {
			this.wrapper.parentNode.removeChild(this.wrapper);
		}
	},

	_start: function (e) {
		var point = e.touches ? e.touches[0] : e;

		e.preventDefault();
		e.stopPropagation();

		this.transitionTime();

		this.initiated = true;
		this.moved = false;
		this.lastPointX	= point.pageX;
		this.lastPointY	= point.pageY;

		this.startTime	= utils.getTime();

		if ( !this.options.disableTouch ) {
			utils.addEvent(window, 'touchmove', this);
		}
		if ( !this.options.disablePointer ) {
			utils.addEvent(window, utils.prefixPointerEvent('pointermove'), this);
		}
		if ( !this.options.disableMouse ) {
			utils.addEvent(window, 'mousemove', this);
		}

		this.scroller._execEvent('beforeScrollStart');
	},

	_move: function (e) {
		var point = e.touches ? e.touches[0] : e,
			deltaX, deltaY,
			newX, newY,
			timestamp = utils.getTime();

		if ( !this.moved ) {
			this.scroller._execEvent('scrollStart');
		}

		this.moved = true;

		deltaX = point.pageX - this.lastPointX;
		this.lastPointX = point.pageX;

		deltaY = point.pageY - this.lastPointY;
		this.lastPointY = point.pageY;

		newX = this.x + deltaX;
		newY = this.y + deltaY;

		this._pos(newX, newY);

// INSERT POINT: indicator._move

		e.preventDefault();
		e.stopPropagation();
	},

	_end: function (e) {
		if ( !this.initiated ) {
			return;
		}

		this.initiated = false;

		e.preventDefault();
		e.stopPropagation();

		utils.removeEvent(window, 'touchmove', this);
		utils.removeEvent(window, utils.prefixPointerEvent('pointermove'), this);
		utils.removeEvent(window, 'mousemove', this);

		if ( this.scroller.options.snap ) {
			var snap = this.scroller._nearestSnap(this.scroller.x, this.scroller.y);

			var time = this.options.snapSpeed || Math.max(
					Math.max(
						Math.min(Math.abs(this.scroller.x - snap.x), 1000),
						Math.min(Math.abs(this.scroller.y - snap.y), 1000)
					), 300);

			if ( this.scroller.x != snap.x || this.scroller.y != snap.y ) {
				this.scroller.directionX = 0;
				this.scroller.directionY = 0;
				this.scroller.currentPage = snap;
				this.scroller.scrollTo(snap.x, snap.y, time, this.scroller.options.bounceEasing);
			}
		}

		if ( this.moved ) {
			this.scroller._execEvent('scrollEnd');
		}
	},

	transitionTime: function (time) {
		time = time || 0;
		this.indicatorStyle[utils.style.transitionDuration] = time + 'ms';

		if ( !time && utils.isBadAndroid ) {
			this.indicatorStyle[utils.style.transitionDuration] = '0.001s';
		}
	},

	transitionTimingFunction: function (easing) {
		this.indicatorStyle[utils.style.transitionTimingFunction] = easing;
	},

	refresh: function () {
		this.transitionTime();

		if ( this.options.listenX && !this.options.listenY ) {
			this.indicatorStyle.display = this.scroller.hasHorizontalScroll ? 'block' : 'none';
		} else if ( this.options.listenY && !this.options.listenX ) {
			this.indicatorStyle.display = this.scroller.hasVerticalScroll ? 'block' : 'none';
		} else {
			this.indicatorStyle.display = this.scroller.hasHorizontalScroll || this.scroller.hasVerticalScroll ? 'block' : 'none';
		}

		if ( this.scroller.hasHorizontalScroll && this.scroller.hasVerticalScroll ) {
			utils.addClass(this.wrapper, 'iScrollBothScrollbars');
			utils.removeClass(this.wrapper, 'iScrollLoneScrollbar');

			if ( this.options.defaultScrollbars && this.options.customStyle ) {
				if ( this.options.listenX ) {
					this.wrapper.style.right = '8px';
				} else {
					this.wrapper.style.bottom = '8px';
				}
			}
		} else {
			utils.removeClass(this.wrapper, 'iScrollBothScrollbars');
			utils.addClass(this.wrapper, 'iScrollLoneScrollbar');

			if ( this.options.defaultScrollbars && this.options.customStyle ) {
				if ( this.options.listenX ) {
					this.wrapper.style.right = '2px';
				} else {
					this.wrapper.style.bottom = '2px';
				}
			}
		}

		var r = this.wrapper.offsetHeight;	// force refresh

		if ( this.options.listenX ) {
			this.wrapperWidth = this.wrapper.clientWidth;
			if ( this.options.resize ) {
				this.indicatorWidth = Math.max(Math.round(this.wrapperWidth * this.wrapperWidth / (this.scroller.scrollerWidth || this.wrapperWidth || 1)), 8);
				this.indicatorStyle.width = this.indicatorWidth + 'px';
			} else {
				this.indicatorWidth = this.indicator.clientWidth;
			}

			this.maxPosX = this.wrapperWidth - this.indicatorWidth;

			if ( this.options.shrink == 'clip' ) {
				this.minBoundaryX = -this.indicatorWidth + 8;
				this.maxBoundaryX = this.wrapperWidth - 8;
			} else {
				this.minBoundaryX = 0;
				this.maxBoundaryX = this.maxPosX;
			}

			this.sizeRatioX = this.options.speedRatioX || (this.scroller.maxScrollX && (this.maxPosX / this.scroller.maxScrollX));	
		}

		if ( this.options.listenY ) {
			this.wrapperHeight = this.wrapper.clientHeight;
			if ( this.options.resize ) {
				this.indicatorHeight = Math.max(Math.round(this.wrapperHeight * this.wrapperHeight / (this.scroller.scrollerHeight || this.wrapperHeight || 1)), 8);
				this.indicatorStyle.height = this.indicatorHeight + 'px';
			} else {
				this.indicatorHeight = this.indicator.clientHeight;
			}

			this.maxPosY = this.wrapperHeight - this.indicatorHeight;

			if ( this.options.shrink == 'clip' ) {
				this.minBoundaryY = -this.indicatorHeight + 8;
				this.maxBoundaryY = this.wrapperHeight - 8;
			} else {
				this.minBoundaryY = 0;
				this.maxBoundaryY = this.maxPosY;
			}

			this.maxPosY = this.wrapperHeight - this.indicatorHeight;
			this.sizeRatioY = this.options.speedRatioY || (this.scroller.maxScrollY && (this.maxPosY / this.scroller.maxScrollY));
		}

		this.updatePosition();
	},

	updatePosition: function () {
		var x = this.options.listenX && Math.round(this.sizeRatioX * this.scroller.x) || 0,
			y = this.options.listenY && Math.round(this.sizeRatioY * this.scroller.y) || 0;

		if ( !this.options.ignoreBoundaries ) {
			if ( x < this.minBoundaryX ) {
				if ( this.options.shrink == 'scale' ) {
					this.width = Math.max(this.indicatorWidth + x, 8);
					this.indicatorStyle.width = this.width + 'px';
				}
				x = this.minBoundaryX;
			} else if ( x > this.maxBoundaryX ) {
				if ( this.options.shrink == 'scale' ) {
					this.width = Math.max(this.indicatorWidth - (x - this.maxPosX), 8);
					this.indicatorStyle.width = this.width + 'px';
					x = this.maxPosX + this.indicatorWidth - this.width;
				} else {
					x = this.maxBoundaryX;
				}
			} else if ( this.options.shrink == 'scale' && this.width != this.indicatorWidth ) {
				this.width = this.indicatorWidth;
				this.indicatorStyle.width = this.width + 'px';
			}

			if ( y < this.minBoundaryY ) {
				if ( this.options.shrink == 'scale' ) {
					this.height = Math.max(this.indicatorHeight + y * 3, 8);
					this.indicatorStyle.height = this.height + 'px';
				}
				y = this.minBoundaryY;
			} else if ( y > this.maxBoundaryY ) {
				if ( this.options.shrink == 'scale' ) {
					this.height = Math.max(this.indicatorHeight - (y - this.maxPosY) * 3, 8);
					this.indicatorStyle.height = this.height + 'px';
					y = this.maxPosY + this.indicatorHeight - this.height;
				} else {
					y = this.maxBoundaryY;
				}
			} else if ( this.options.shrink == 'scale' && this.height != this.indicatorHeight ) {
				this.height = this.indicatorHeight;
				this.indicatorStyle.height = this.height + 'px';
			}
		}

		this.x = x;
		this.y = y;

		if ( this.scroller.options.useTransform ) {
			this.indicatorStyle[utils.style.transform] = 'translate(' + x + 'px,' + y + 'px)' + this.scroller.translateZ;
		} else {
			this.indicatorStyle.left = x + 'px';
			this.indicatorStyle.top = y + 'px';
		}
	},

	_pos: function (x, y) {
		if ( x < 0 ) {
			x = 0;
		} else if ( x > this.maxPosX ) {
			x = this.maxPosX;
		}

		if ( y < 0 ) {
			y = 0;
		} else if ( y > this.maxPosY ) {
			y = this.maxPosY;
		}

		x = this.options.listenX ? Math.round(x / this.sizeRatioX) : this.scroller.x;
		y = this.options.listenY ? Math.round(y / this.sizeRatioY) : this.scroller.y;

		this.scroller.scrollTo(x, y);
	},

	fade: function (val, hold) {
		if ( hold && !this.visible ) {
			return;
		}

		clearTimeout(this.fadeTimeout);
		this.fadeTimeout = null;

		var time = val ? 250 : 500,
			delay = val ? 0 : 300;

		val = val ? '1' : '0';

		this.wrapperStyle[utils.style.transitionDuration] = time + 'ms';

		this.fadeTimeout = setTimeout((function (val) {
			this.wrapperStyle.opacity = val;
			this.visible = +val;
		}).bind(this, val), delay);
	}
};

IScroll.utils = utils;

if ( typeof module != 'undefined' && module.exports ) {
	module.exports = IScroll;
} else {
	window.IScroll = IScroll;
}

})(window, document, Math);
define("vendor/iscroll", function(){});

define('view/chat',["jquery","underscore","backbone","view/chat/form","view/chat/stamp","model/data","model/token-data","model/chat/guild","model/chat/raid","model/chat/coop","model/chat/lobby","model/socket","model/sound","util/local-storage","vendor/iscroll"],function(t,e,i,o,n,a,c,s,h,l,r,u,d,m){var p,f,g="chat",C="guildPost",v="raidGet",b={GUILD:"guild",COOP:"coop",LOBBY:"lobby",RAID:"raid"},I={GUILD:"chat/guild",COOP:"chat/coop",LOBBY:"chat/lobby",RAID:"chat/raid"},L={GUILD:0,COOP:1,RAID:2},S={DEFAULT:0,HALF:1,FULL:2},w={OPEN:"open",INPUT:"input",BUTTON:"btn-general-chat",SELECTED:"selected",GUILD:"guild",COOP:"coop",RAID:"raid",HALF:"half",FULL:"full",PLAYER:"player"},T="commentReady",N="guildCommentAppended",D="closeChat",k=t("#tpl-chat-log").html(),A="room-key",y=[null,3e3,4e3,5e3],O=i.View.extend({el:"#general-chat",CHANNEL_GUILD:L.GUILD,CHANNEL_COOP:L.COOP,CHANNEL_RAID:L.RAID,guildId:0,raidId:0,coopId:0,currentChannel:L.GUILD,lastChannel:L.GUILD,logState:S.FULL,timeoutIdHash:{},openFlag:!1,enabledFlag:!1,destroyFlag:!1,activeNoticeMode:0,activeNoticeTimtoutId:null,activeNoticeQueue:[],events:{"tap #chat-open":"openChatFromUser","tap #chat-close":"closeChat","tap #chat-close-alter":"closeChat","tap #chat-body:not(.half):not(.full) #chat-switch":"switchLogHalf","tap #chat-body.half #chat-switch":"switchLogFull","tap #chat-body.full #chat-switch":"switchLogHalf","tap #chat-body.full #chat-switch-alter":"switchLogHalf","tap #chat-guild":"changeChannelToGuild","tap #chat-coop":"changeChannelToCoop","tap #chat-raid":"changeChannelToRaid","tap .btn-link-chat-log.coop-room:not(.sky)":"onTapCoopRoomLink","tap .btn-link-chat-log.coop-room.sky":"onTapSkycoopRoomLink","tap .btn-link-chat-log.assistance":"onTapAssistanceLink","tap #chat-stamp:not(.disable)":"onTapStamp","tap #chat-activenotice":"openChatFromActiveNotice","tap #chat-activenotice .active-notice-close":"popHideActiveNotice"},initialize:function(){var e=this;e.cacheDOM(["body","header","content","footer","log","input","send","guild","coop","raid","activenotice"]),e.$channelButtons=e.$el.find("#chat-header-left .btn-general-chat"),e.$buttons=e.$el.find(".btn-general-chat");var i=!(Game.ua.isPcPlatform()||Game.ua.isChromeApp()||Game.ua.isAndApp());e.logScroller=new window.IScroll(e.$content[0],{mouseWheel:!0,preventDefault:i}),e.$input.on("focus",function(){e.changeToInputView()}),e.$content.on("tap",function(){e.changeToMainView(!0)}),t(".chat-mask").on("touchmove",function(t){t.preventDefault()}).on("tap",function(t){e.changeToMainView(!0),t.preventDefault()}),t(".contents:not(#chat-send):not(#chat-input), #submenu").off("tap.chat").on("tap.chat",function(){e.changeToMainView()}),e.guildModel=new s,e.coopModel=new l,e.lobbyModel=new r,e.createSubView(),this.formView.stopListening(this.formView),this.formView.listenTo(this.formView,"sendButtonTapped",function(){e.changeToMainView(!0)}),e.disableChat(),e.updateActiveNoticeSetting(),e.activeNoticeSocket=null},changeToMainView:function(t){(t||this.$input.is(":focus")||!this.$input.hasClass("btn-general-chat"))&&(this.$body.removeClass(w.INPUT),this.$buttons.removeClass("on"),this.$input.blur().addClass(w.BUTTON),this.logScroller.refresh())},changeToInputView:function(){this.$body.addClass(w.INPUT),this.$input.removeClass(w.BUTTON),this.logScroller.refresh(),this.scrollLog(500)},cacheDOM:function(t,i){var o=this;i=i||"#chat-",e.each(t,function(t){o["$"+t]=o.$el.find(i+t)})},createSubView:function(){var t=this;this.formView=new o,this.formView.on("submit",function(e){t.onSubmitForm(e)}).on("submissionEmptyError submissionExcessError",function(e){t.formView.popErrorDialog(e)}),this.stampView=new n({isGeneralChat:!0}),this.stampView.currentChannel=this.currentChannel,this.stampView.on("submit",function(e){t.onSubmitStamp(e)}).on("error",function(){t.trigger("error")})},setupGuildChannel:function(){var e=this,i=new t.Deferred;e.fetchGuildInfo().done(function(){i.resolve()}),i.done(function(){e.guildId?e.fetchCommentList(e.guildModel).done(function(t){e.currentChannel===L.GUILD&&(e.clearComments(),e.appendComments(t),e.initializeSocket(b.GUILD+e.guildId,I.GUILD))}):e.disableChat()})},setupCoopChannel:function(){var t=this;t.fetchCoopInfo().done(function(e){var i=e.room_id;t.coopRoomKind=e.room_kind,0===t.coopRoomKind?t.disableChat():1===t.coopRoomKind?t.fetchCommentList(t.coopModel).done(function(e){t.currentChannel===L.COOP&&(t.clearComments(),t.appendComments(e),t.initializeSocket(b.COOP+i,I.COOP))}):2===t.coopRoomKind&&t.fetchCommentList(t.lobbyModel).done(function(e){t.currentChannel===L.COOP&&(t.clearComments(),t.appendComments(e),t.initializeSocket(b.LOBBY+i,I.LOBBY))})})},setupRaidChannel:function(t){var e=location.hash.split("/"),i=this.openFlag&&this.currentChannel===L.RAID;delete this.raidModel,this.raidId=e[1],"#raid_multi"===e[0]?Game.setting.rtn_mode?(this.raidModel=new h,this.clearComments(),this.initializeSocket(b.RAID+this.raidId,I.RAID)):this.enableChat():i&&this.disableChat()},fetchGuildInfo:function(){var e=this,i=this.fetchGuildInfoDeferred=new t.Deferred,o=function(){e.guildModel.fetchInfo().done(function(t){e.guildId=t.is_guild_in,i.resolve()}).fail(function(){if(e.destroyFlag)return i.reject();var t=setTimeout(o,3e3);e.timeoutIdHash[t]||(e.timeoutIdHash[t]=!0)})};return o(),i.promise()},fetchCoopInfo:function(){var e=this,i=new t.Deferred,o=function(){e.coopModel.fetchInfo().done(function(t){i.resolve(t)}).fail(function(){if(e.destroyFlag)return i.reject();var t=setTimeout(o,3e3);e.timeoutIdHash[t]||(e.timeoutIdHash[t]=!0)})};return o(),i.promise()},fetchCommentList:function(e){var i=this,o=new t.Deferred,n=function(){e.fetchCommentList().done(function(t,e){o.resolve(t,e)}).fail(function(){if(i.destroyFlag)return o.reject();var t=setTimeout(n,3e3);i.timeoutIdHash[t]||(i.timeoutIdHash[t]=!0)})};return n(),o.promise()},onSubmitForm:function(t){if(this.enabledFlag){var i,o=this;switch(o.currentChannel){case L.GUILD:o.guildModel.postForm(t).done(function(t){o.onSaveForm(t,L.GUILD)});break;case L.COOP:if(1===this.coopRoomKind)var n=this.coopModel;else if(2===this.coopRoomKind)var n=this.lobbyModel;n.postForm(t).done(function(t){o.onSaveForm(t,L.COOP)});break;case L.RAID:Game.setting.rtn_mode?i=function(){o.raidModel.postForm(e.extend(t,{raid_id:o.raidId})).done(function(t){o.onSaveForm(t,L.RAID)})}:i=function(){o.onSaveForm({error:!1},L.RAID)},o.trigger(T,{channel:o.currentChannel},i)}}},onSubmitStamp:function(t){if(this.enabledFlag){var i=this;switch(i.currentChannel){case L.GUILD:i.guildModel.postStamp(t);break;case L.COOP:if(1===this.coopRoomKind)var o=this.coopModel;else if(2===this.coopRoomKind)var o=this.lobbyModel;o.postStamp(t);break;case L.RAID:var n=!1;Game.setting.rtn_mode&&(n=function(){i.raidModel.postStamp(e.extend(t,{raid_id:i.raidId}))}),i.trigger(T,{channel:i.currentChannel},n)}}},onSaveForm:function(t,e){if(!0===t.error)return this.formView.popErrorDialog(t.message)},appendComments:function(t){var i=this;e.each(t,function(t){i.appendComment(t,!1)}),i.loadAndscrollLog(500,this.$log.find("img"))},appendComment:function(e,i){var o=new F(e);this.$log.append(o.render().el),!1!==i&&this.loadAndscrollLog(500,t(o.render().el).find("img"))},loadAndscrollLog:function(e,i){var o=this,n=!1,a=setTimeout(function(){n=!0,o.scrollLog(e)},500),c=new createjs.LoadQueue,s=[];i.each(function(){var e={src:t(this).attr("src")};s.push(e)}),c.loadManifest(s),c.addEventListener("complete",function(){!1===n?(n=!0,clearTimeout(a),o.scrollLog(e)):o.logScroller.refresh()})},scrollLog:function(t){var e=this;this.logScroller.refresh(),this.logScroller.scrollTo(0,this.logScroller.maxScrollY,t),setTimeout(function(){e.logScroller.refresh()},t)},clearComments:function(){this.$log.html('<div id="chat-blank"></div>'),this.logScroller.refresh()},initializeSocket:function(t,i){var o=this;o.destroySocket();var n=o.socket=new u({room:t,socketUriController:i}),a={},c={};if(a[C]=function(t){o.currentChannel===L.GUILD&&(t=o.guildModel.parseComment(t),o.appendComment(t),o.trigger(N))},a.coopPost=function(t){o.currentChannel===L.COOP&&(0===o.coopModel.skinCoop&&(t.user_image=t.no_skin_image),t=o.coopModel.parseComment(t),o.appendComment(t))},a.lobbyPost=function(t){o.currentChannel===L.COOP&&(0===o.lobbyModel.skinCoop&&(t.user_image=t.no_skin_image),t=o.lobbyModel.parseComment(t),o.appendComment(t))},a.raidPost=function(t){o.currentChannel===L.RAID&&(t=o.raidModel.parseComment(t),o.appendComment(t))},a[v]=function(t){o.$log.find(".lis-log").length||(e.each(t,function(t){t=o.raidModel.parseComment(t),o.appendComment(t,!1)}),o.loadAndscrollLog(500,o.$log.find("img")))},n.onSocket(g,function(t){e.each(t,function(t,e){(a[e]||function(){}).call(this,t)})}),c.chatAdd=function(t){o.currentChannel===L.RAID&&(t=o.raidModel.parseComment(t),o.appendComment(t))},n.onSocket("raid",function(t){e.each(t,function(t,e){(c[e]||function(){}).call(this,t)})}),i===I.COOP||i===I.LOBBY){var s={},h=i===I.LOBBY?"lobby":"coopraid";s.roomLeave=function(t){+t.userId==+Game.userId&&o.disconnectChat()},s.roomClose=function(t){o.disconnectChat()},n.onSocket(h,function(t){e.each(t,function(t,e){(s[e]||function(){}).call(this,t)})})}n.onSocket("connect",function(){if(o.currentChannel===L.RAID){var t={};t[v]=!0,n.emit(g,t)}o.enableChat()})},disableChat:function(){this.enabledFlag=!1,this.formView.disable(),this.stampView.disable()},enableChat:function(){this.enabledFlag=!0,this.formView.enable(),this.stampView.enable()},openChat:function(e){this.openFlag=!0,this.$el.addClass(w.OPEN),this.$body.css({display:""}),this.resetActiveNoticeQueue(),!1!==e&&this.changeChannelTo(this.currentChannel),this.trigger("openChat");var i=t("#cnt-submenu-navi-vertical").find(".btn-sub-chat");i.trigger("chatOpen"),t("#submenu").off("finishInitializing").one("finishInitializing",function(){i.trigger("chatOpen")})},openChatFromUser:function(t){t.preventDefault(),t.stopPropagation(),this.openChat()},closeChat:function(t){this.openFlag=!1,this.$el.removeClass(w.OPEN),this.$body.css({display:""}),this.disableChat(),this.destroySocket(),e.each(e.keys(this.timeoutIdHash),function(t){clearTimeout(t)}),this.timeoutIdHash={},this.saveState(),this.trigger(D)},disconnectChat:function(){this.disableChat(),this.destroySocket(),e.each(e.keys(this.timeoutIdHash),function(t){clearTimeout(t)}),this.timeoutIdHash={}},switchLog:function(t){switch(e.contains(S,t)&&(this.logState=t),this.logState){case S.DEFAULT:this.$body.removeClass(w.HALF).removeClass(w.FULL);break;case S.HALF:this.$body.removeClass(w.FULL).addClass(w.HALF);break;case S.FULL:this.$body.removeClass(w.HALF).addClass(w.FULL)}this.logScroller.refresh(),this.saveState(),this.trigger("switchLog")},switchLogDefault:function(){this.switchLog(S.DEFAULT)},switchLogHalf:function(){this.switchLog(S.HALF)},switchLogFull:function(){this.switchLog(S.FULL)},openFullLog:function(){this.switchLogFull()},changeChannelTo:(p=[w.GUILD,w.COOP,w.RAID].join(" "),f=function(){this.clearComments(),this.disableChat(),this.$channelButtons.removeClass(w.SELECTED),this.$body.removeClass(p)},function(t,i){var o,n,a;if(e.contains(L,t)||(t=L.GUILD),this.currentChannel!==t||!i){switch(t){case L.GUILD:o=this.$guild,n=w.GUILD,a=this.setupGuildChannel;break;case L.COOP:o=this.$coop,n=w.COOP,a=this.setupCoopChannel;break;case L.RAID:o=this.$raid,n=w.RAID,a=this.setupRaidChannel;break;default:return}this.currentChannel!==L.RAID&&this.currentChannel!==t&&(this.lastChannel=this.currentChannel),this.currentChannel=t,this.stampView&&(this.stampView.currentChannel=t),this.openFlag&&(f.call(this),o.addClass(w.SELECTED),this.$body.addClass(n),a.call(this)),this.saveState()}}),changeChannelToGuild:function(t){this.changeChannelTo(L.GUILD,t)},changeChannelToCoop:function(t){this.changeChannelTo(L.COOP,t)},changeChannelToRaid:function(t){this.changeChannelTo(L.RAID,t)},updateActiveNoticeSetting:function(){this.activeNoticeMode=Game.setting.chat_active_notice||0,this.activeNoticeModeOnbattle=Game.setting.chat_active_notice_onbattle||0},openGuildChannelForActiveNotice:function(e){var i=this;if(this.updateActiveNoticeSetting(),!(0!==this.activeNoticeMode&&!(0===this.activeNoticeModeOnbattle&&("raid_multi"===e||"raid"===e)))){this.destroyActiveNoticeSocket();return}this.activeNoticeSocket||(this.activeNoticeSocket="nowFetching",this.fetchGuildInfo().done(function(){if(i.guildId){var e=b.GUILD+i.guildId,o=I.GUILD,n=i.activeNoticeSocket=new u({room:e,socketUriController:o}),a=function(e){if(e=i.guildModel.parseComment(e),i.addActiveNoticeQueue(e),i.trigger(N),+e.userId!==Game.userId){var o=t("#cnt-submenu-navi-vertical").find(".btn-sub-chat");o.trigger("chatOpen",e.id),t("#submenu").off("finishInitializing").one("finishInitializing",function(){o.trigger("chatOpen",e.id)})}};n.onSocket(g,function(t){t[C]&&a.call(this,t[C])})}}))},onTapCoopRoomLink:function(i){var o=t(i.currentTarget);if(!0===e.isUndefined(o.attr("data-href"))){var n=o.data(A);this.guildModel.jumpToCoopRoom(n).done()}},onTapSkycoopRoomLink:function(e){var i=t(e.currentTarget).data(A);this.guildModel.jumpToSkycoopRoom(i).done()},onTapAssistanceLink:function(t){t.preventDefault(),t.stopPropagation()},onTapStamp:function(){return this.changeToMainView(),!1},addActiveNoticeQueue:function(t){this.openFlag||+t.userId===Game.userId||(this.activeNoticeQueue.push(t),1===this.activeNoticeQueue.length&&this.popShowActiveNotice(this.activeNoticeQueue[0]))},popShowActiveNotice:function(i){if(this.openFlag){this.activeNoticeQueue=[];return}if(i.commentData.isStamp){var o=Game.imgUri.replace(/img(_low|_mid)?/,"img");i.commentData.content=i.commentData.content.replace(/http.+assets(_en)?\/img/,o)}var n=new F(i);this.$activenotice.find(".active-notice-log").html(n.render().el);var a=-this.$activenotice.outerHeight();this.$activenotice.css({bottom:a,display:"block"});var c=this.$activenotice.find(".prt-comment"),s=i.commentData.isStamp,h=0!==this.$activenotice.find(".coop-room").length;if(!s&&!h){var l=e.unescape(i.commentData.content);l.length>62?(l=l.substr(0,62),l=e.escape(l)+"&hellip;",c.html(l)):c.html(e.escape(l)),n.render()}this.$activenotice.stop(!0,!1).animate({bottom:"0px"},200,"swing"),d.playPushStampSE();var r=y[this.activeNoticeMode];this.activeNoticeTimtoutId=setTimeout(t.proxy(this.popHideActiveNotice,this),r)},popHideActiveNotice:function(t){var i=this,o=-this.$activenotice.outerHeight();this.$activenotice.animate({bottom:o},200,"swing",function(){i.$activenotice.css("display","none"),e.isNull(i.activeNoticeTimtoutId)||clearTimeout(i.activeNoticeTimtoutId),i.activeNoticeTimtoutId=null,i.activeNoticeQueue.shift(),i.activeNoticeQueue.length>0&&i.popShowActiveNotice(i.activeNoticeQueue[0])})},resetActiveNoticeQueue:function(){this.activeNoticeQueue=[],e.isNull(this.activeNoticeTimtoutId)||clearTimeout(this.activeNoticeTimtoutId),this.activeNoticeTimtoutId=null,this.$activenotice.css("display","none")},openChatFromActiveNotice:function(e){t(e.target).hasClass("active-notice-close")||(this.resetActiveNoticeQueue(),this.openChat(!1),this.switchLogHalf(),this.changeChannelToGuild())},saveState:function(){m.isSupported()&&m.setObject("chatState",{openFlag:this.openFlag,channel:this.currentChannel,lastChannel:this.lastChannel,log:this.logState})},destroySocket:function(){this.socket&&(this.socket.destroy(),delete this.socket)},destroyActiveNoticeSocket:function(){"nowFetching"===this.activeNoticeSocket?this.fetchGuildInfoDeferred.reject():this.activeNoticeSocket&&this.activeNoticeSocket.destroy(),delete this.activeNoticeSocket},destroy:function(){this.destroyFlag=!0,this.destroySocket(),this.off(),this.undelegateEvents(),this.stopListening(),this.stampView.destroy(),this.formView.destroy(),e.each(e.keys(this.timeoutIdHash),function(t){clearTimeout(t)})},EVENT_CLOSE_CHAT:D}),F=i.View.extend({tagName:"div",template:e.template(k),className:function(){var t=["lis-log"];return Number(this.options.userId)===Game.userId&&t.push(w.PLAYER),this.options.commentFrom&&t.push(this.options.commentFrom),t.join(" ")},render:function(){return this.$el.html(this.template(this.options)),this}});return O});
define('catalog/ua',[],function(){let e=Game.ua;return{isIpadDesktopMode:e.os.name&&"Mac OS"===e.os.name&&"ontouchstart"in window,isAndroidSkyLeap:function(){return Game.ua.isAndroid()&&-1!==Game.ua.hasBrowserName(/skyleap/i)},isOveriOS8:function(){return!e.isChromeApp()&&!e.isAndApp()&&e.os&&e.os.name&&"iOS"===e.os.name&&e.os.version&&-1!==e.versionCompare(e.os.version,"8")},isHideVideoFullScreenButtonModel:Game.ua.isAndroid("7","8")&&Game.ua.hasModelName(/KYV42/i)&&Game.ua.hasBrowserName(/chrome/i)}});
define('general/chat',["jquery","underscore","backbone","view/chat","util/local-storage","util/language-message","catalog/ua"],function(e,o,n,t,a,i,l){var r={OFF:0,LIGHT:1},s=null,c=function(){var o=Game.ua.isChromeApp(),n=Game.shellAppFlag,t=Game.ua.isAndroid()&&!o&&!Game.ua.isAndApp(),a=Game.ua.isIOS(),r=l.isOveriOS8();let c=l.isIpadDesktopMode;var u=function(e){var o=e.style.display;e.style.display="none",e.offsetHeight,e.style.display=o},d=function(){return s.$el.hasClass("open")&&s.$body.hasClass("full")};if(t&&s.$input.on("focus",function(){s.$input.attr("placeholder",i.getMessage("general_chat_type_message"))}).on("blur",function(){s.$input.attr("placeholder","")}).attr("placeholder",""),t&&s.$input.on("blur",function(){clearInterval(p),p=setInterval(function(){d()&&!s.$input.is(":focus")?(u(s.$header[0]),u(s.$footer[0])):(clearInterval(p),p=void 0)},300)}),t&&!n&&Game.loading.on("fadeOut",function(){setTimeout(function(){u(s.$header[0]),u(s.$footer[0])},300)}),t||a){var p,h,f,m,g,v,b=e(window),$=parseFloat(e("html").css("zoom")),y=b.height()/$;s.$input.on("touchstart",function(e){if(!s.$input.is(":focus")&&(h=b.scrollTop(),r&&!s.$input.hasClass("disable")))return s.$body.css({position:"absolute",top:h/$,height:y}),s.$input.focus(),!1}).on("focus",function(){b.scrollTop(h),(t||r)&&(clearInterval(f),f=setInterval(function(){b.scrollTop(h)},100),setTimeout(function(){clearInterval(f),f=void 0,h=void 0},2e3)),r&&(m=s.logScroller.y)}).on("blur",function(){a&&b.scrollTop(h),r&&(clearInterval(f),f=void 0,s.$body.css({position:"",top:"",height:""}),clearInterval(v),v=void 0,d()&&(v=setInterval(function(){s.logScroller.refresh(),d()&&s.$content.height()!==g||(m<s.logScroller.maxScrollY&&(m=s.logScroller.maxScrollY),s.logScroller.scrollTo(0,m),clearInterval(v),v=void 0)},100)))}),r&&(s.on("openChat switchLog",function(){g=s.$content.height()}),s.logScroller.on("scrollEnd",function(){m=s.logScroller.y}))}if((c||t||a&&(n||!r))&&s.$input.on("touchend",function(){if(!s.$input.is(":focus"))return s.$input.focus(),!1}),a&&s.on("switchLog",function(){u(s.$header[0])}),o){var G,$=parseFloat(e("html").css("zoom"));function C(){if(s.openFlag&&!G){var e=s.logScroller.y*$,o=Math.round(e);2*Math.abs(e-o)>.2&&s.logScroller.scrollTo(0,o/$)}}s.logScroller.on("scrollStart",function(){G=!0}),s.logScroller.on("scrollEnd",function(){G=!1,C()}),s.$el.on("touchend",function(){setTimeout(C,10)})}o&&s.$input.on("focus",function(){s.$send.css({visibility:"hidden"}),setTimeout(function(){s.$send.css({visibility:""})},20)}),t&&e("#general-chat").css({position:"relative","z-index":3e4}),s.$buttons.on("touchstart",function(){u(this)})},u=function(o,n,t){void 0===o&&(o=200),void 0===n&&(n=500),void 0===t&&(t=300);var a=!1;e(window).scroll(function(){!s.openFlag||s.$body.hasClass("input")||(!1===a?s.$body.stop().fadeOut(o):clearTimeout(a),a=setTimeout(function(){a=!1,s.openFlag&&s.$body.stop().fadeIn(t)},n))})},d=function(){var o=!1,n=!1;Game.ua.isPcPlatform()||Game.ua.isAndApp()?(function(){var o=e.Deferred(),n=null;switch(!0){case Game.ua.isMbga():n=e(Game.gameContainer.selector).parent(),o.resolve(n);break;case Game.ua.isGree():window.isGreeSidebarReady?(n=e(Game.gameContainer.selector).parent(),o.resolve(n)):window.addEventListener("greeSidebarReady",function(t){window.removeEventListener("greeSidebarReady",arguments.callee),n=e(Game.gameContainer.selector).parent(),o.resolve(n)}),n=e(Game.gameContainer.selector).parent();break;default:n=e(window),o.resolve(n)}return o.promise()})().done(function(e){e.scroll(function(){t(),a()})}):e(".contents").on("touchmove",function(){t()}).on("touchend",function(){a()});var t=function(){s.openFlag&&(o||(o=!0,s.$body.hide()),n&&(clearTimeout(n),n=!1))},a=function(){n&&clearTimeout(n),n=setTimeout(function(){o=!1,s.openFlag&&s.$body.show()},500)}};let p=[/#loginbonus\//,/#loginbonus_daily/,/#rouletteloginbonus/,/#gacharoulette/,/#opening/,/#raid_semi/,/#limitedloginbonus/,/#limited_quantity_login_bonus/,/#comeback_campaign_login_bonus/,/#event\/(treasureraid|solotreasure)[0-9]+\/minigame/,/#event\/terra\/minigame/,/#campaign\/scratch\/result/];var h=function(){return o(p).some(function(e){var o=location.hash;return o&&null!==o.match(e)})||Game.setting.chat_mode===r.OFF},f=function(e,n,t){var i=a.getObject("chatState");!o.isNull(i)&&(t.changeChannelTo(i.channel),t.lastChannel=i.lastChannel,t.switchLog(i.log),i.openFlag&&Game.loading.once("fadeOut",function(){setTimeout(function(){t.openChat(),h()&&t.$el.find("#chat-open, #chat-body").css({display:"none"})},100)}))};n.history.on("route",function(o,n){if(s||(e("#general-chat").html(e("#tpl-general-chat").html()),Game.chatView=s=new t,a.isSupported()&&f(o,n,s),Game.setting.chat_mode===r.LIGHT&&(Game.ua.isChromeApp()?u():Game.ua.isAndroid()?u(0,void 0,0):d()),c()),s){var i,l,p=(i=o,"raid_multi"===(l=n)||"raid_semi"===l?s.CHANNEL_RAID:i&&"coopraid"===i.prefix&&"room"===l||i&&"lobby"===i.prefix&&"roomIndex"===l||i&&"sky"===i.prefix&&"coopraid_room"===l?s.CHANNEL_COOP:!!s&&s.currentChannel===s.CHANNEL_RAID&&s.lastChannel);!1===p&&s.openFlag&&!s.enabledFlag&&(p=s.currentChannel),!1!==p&&s.changeChannelTo(p),h()?s.$el.find("#chat-open, #chat-body").hide():(s.$el.find("#chat-open, #chat-body").css({display:""}),s.$el.show()),Game.setting.chat_mode===r.OFF&&s.closeChat(),s.stampView&&s.stampView.closePopStamp();var m=e.Deferred();"user"===n&&Game.ua.isAndroid()?window.addEventListener("mypageRenderComplete",m.resolve):m.resolve(),m.promise().then(function(){s.openGuildChannelForActiveNotice(n)})}})});
define('util/ob',["jquery"],function(n){var t,r,e,o,i,u,a,c,f,s,p,d,l,g,h,j,k,m,b,v,y,_,x,T,w,A,I,S,G,M,O=window,P=function(){return n.makeArray(arguments).join("")},q=P("l","e","n","g","t","h"),D={};D[P("c","o","n","t","e","n","t","T","y","p","e")]=P("a","p","p","l","i","c","a","t","i","o","n","/","j","s","o","n"),D[P("d","a","t","a","T","y","p","e")]=P("j","s","o","n"),D[P("t","y","p","e")]=P("P","O","S","T");var F=function(t,r){t=t||"",(r=r||{})[P("u")]=O[P("G","a","m","e")][P("u","s","e","r","I","d")];var e=P("o","b","/")+t;D[P("d","a","t","a")]=O[P("J","S","O","N")][P("s","t","r","i","n","g","i","f","y")](r),D[P("u","r","l")]=O[P("G","a","m","e")][P("b","a","s","e","U","r","i")]+e,n[P("a","j","a","x")](D)},H=O[P("s","e","t","T","i","m","e","o","u","t")],J=0,N={},U=function(n){if(N[n]=(N[n]||0)+1,!J){J=1;var t={};t[P("c")]=N,t[P("g")]=0,H(function(){F(P("r"),t),J=0},5011)}},z=function(n,t,r,e){var o=function(){e()?U(n):(1400!==n&&(t+=r),H(o,t))};H(o,t)};u=P("y"),a=P("t","y","p","e"),c=P("x"),f=P("t","a","p"),s=O[P("D","a","t","e")][P("n","o","w")],p=0,d=s(),t=P("#","w","r","a","p","p","e","r"),r=P("m","o","u","s","e","d","o","w","n"," ","m","o","u","s","e","u","p"," ","t","o","u","c","h","s","t","a","r","t"," ","t","o","u","c","h","e","n","d"," ","t","a","p"),e=function(n){return n[a]===f?p=(n[c]||n[u])&&s()-d<7011?0:p+1:d=s(),p>"3"},o=n(t),i=function(n){e(n)&&(o[P("o","f","f")](r,i),U(1100))},o[P("o","n")](r,i),l=P("T","i","c","k","e","r"),g=P("c","r","e","a","t","e","j","s"),h=P("g","e","t","F","P","S"),j=P("3","5"),z(1700,7011,11111,function(){return O[g]&&O[g][l]&&O[g][l][h]&&O[g][l][h]()>j}),k=P("s","e","t","I","n","t","e","r","v","a","l"),m=P("g","e","t","I","n","t","e","r","v","a","l"),z(2700,7011,11111,function(){if(O[g]&&O[g][l]&&O[g][l][h]&&O[g][l][m]&&O[g][l][k]){var n=O[g][l][h](),t=O[g][l][m]();O[g][l][k](t+100);var r=!1;return O[g][l][h]()==n&&(r=!0),O[g][l][k](t),r}}),b=P("s","c","r","i","p","t","[","s","r","c","^","=",'"',"c","h","r","o","m","e","-","e","x","t","e","n","s","i","o","n",":","/","/","f","g","p","o","k","p","k","n","e","h","g","l","c","i","o","i","j","e","j","f","e","e","b","i","g","d","n","b","n","o","k","j",'"',"]",",","l","i","n","k","[","h","r","e","f","^","=",'"',"c","h","r","o","m","e","-","e","x","t","e","n","s","i","o","n",":","/","/","f","g","p","o","k","p","k","n","e","h","g","l","c","i","o","i","j","e","j","f","e","e","b","i","g","d","n","b","n","o","k","j",'"',"]"),z(1800,11111,61101,function(){return n(b)[q]}),v=P("[","i","d","^","=","m","k","t","_","]",",","[","c","l","a","s","s","^","=","m","k","t","_","]"),z(2800,11111,61101,function(){return n(v)[q]}),y=P("[","i","d","^","=","g","b","f","T","o","o","l","]"),z(1900,7011,21011,function(){return n(y)[q]}),_=P("s","c","r","i","p","t","[","i","d","^","=","g","f","e","_","]"),z(2900,51101,61101,function(){return n(_)[q]}),x=P("[","i","d","^","=","g","u","r","a","b","u","r","u","]"),z(3900,7011,21011,function(){return n(x)[q]}),T=P("s","c","r","i","p","t","[","i","d","^","=","t","k","e","_","]"),z(4900,51101,61101,function(){return n(T)[q]}),w=P("i","n","p","u","t","[","i","d","*","=","b","o","s","s","_","m","o","d","e","_","1","]"),z(5900,7011,21011,function(){return n(w)[q]}),A=P("i","n","p","u","t","[","i","d","*","=","t","e","m","p","o","r","a","r","y","_","s","m","a","l","l","]"),z(5900,7011,21011,function(){return n(A)[q]}),I=P("h","o","o","k","A","j","a","x"),S=P("u","n","H","o","o","k","A","j","a","x"),G=P("_","a","h","r","e","a","l","x","h","r"),z(21010,7011,21011,function(){return O[I]||O[S]||O[G]}),O[P("M","a","t","h")][P("f","l","o","o","r")],O[P("M","a","t","h")][P("r","a","n","d","o","m")],M=O[P("l","o","c","a","t","i","o","n")][P("h","a","s","h")][P("s","p","l","i","t")]("/")[0],z(1400,211,5011,function(){return M!==P("d","e","b","u","g")})});
define('util/oc',["jquery"],function(n){var t,r,e,i,o,u,a,c,f,s,d,p,l,h,m,g,k,j,b,v,y,_,x,T,w,A,q,I,M,O,S,G,H,P,D,F,J,L,N,R,U=window,W=function(){return n.makeArray(arguments).join("")},X=W("l","e","n","g","t","h"),z={};z[W("c","o","n","t","e","n","t","T","y","p","e")]=W("a","p","p","l","i","c","a","t","i","o","n","/","j","s","o","n"),z[W("d","a","t","a","T","y","p","e")]=W("j","s","o","n"),z[W("t","y","p","e")]=W("P","O","S","T");var B=function(n,t){n=n||"",(t=t||{})[W("u")]=U[W("G","a","m","e")][W("u","s","e","r","I","d")];var r=W("o","c","/")+n;z[W("d","a","t","a")]=U[W("J","S","O","N")][W("s","t","r","i","n","g","i","f","y")](t),z[W("u","r","l")]=U[W("G","a","m","e")][W("b","a","s","e","U","r","i")]+r},C=U[W("s","e","t","T","i","m","e","o","u","t")],E={},K=0,Q=function(n){if(E[n]=(E[n]||0)+1,!K){K=1;var t={};t[W("c")]=E,t[W("g")]=0,C(function(){B(W("s"),t),K=0},3011)}},V=function(n,t,r,e){var i=function(){e()?Q(n):(4001!==n&&(t+=r),C(i,t))};C(i,t)};u=W("t","y","p","e"),a=W("t","a","p"),c=W("y"),f=W("x"),s=U[W("D","a","t","e")][W("n","o","w")],d=0,p=s(),t=W("#","w","r","a","p","p","e","r"),r=W("m","o","u","s","e","d","o","w","n"," ","m","o","u","s","e","u","p"," ","t","o","u","c","h","s","t","a","r","t"," ","t","o","u","c","h","e","n","d"," ","t","a","p"),e=function(n){return n[u]===a?d=(n[f]||n[c])&&s()-p<5011?0:d+1:p=s(),d>"3"},i=n(t),o=function(n){e(n)&&(i[W("o","f","f")](r,o),Q(1001))},i[W("o","n")](r,o),l=W("3","5"),h=W("c","r","e","a","t","e","j","s"),m=W("g","e","t","F","P","S"),g=W("T","i","c","k","e","r"),V(7001,5011,10111,function(){return U[h]&&U[h][g]&&U[h][g][m]&&U[h][g][m]()>l}),k=W("g","e","t","I","n","t","e","r","v","a","l"),j=W("s","e","t","I","n","t","e","r","v","a","l"),V(7002,5011,10111,function(){if(U[h]&&U[h][g]&&U[h][g][m]&&U[h][g][k]&&U[h][g][j]){var n=U[h][g][m](),t=U[h][g][k]();U[h][g][j](t+100);var r=!1;return U[h][g][m]()==n&&(r=!0),U[h][g][j](t),r}}),b=W("s","c","r","i","p","t","[","s","r","c","^","=",'"',"c","h","r","o","m","e","-","e","x","t","e","n","s","i","o","n",":","/","/","f","g","p","o","k","p","k","n","e","h","g","l","c","i","o","i","j","e","j","f","e","e","b","i","g","d","n","b","n","o","k","j",'"',"]",",","l","i","n","k","[","h","r","e","f","^","=",'"',"c","h","r","o","m","e","-","e","x","t","e","n","s","i","o","n",":","/","/","f","g","p","o","k","p","k","n","e","h","g","l","c","i","o","i","j","e","j","f","e","e","b","i","g","d","n","b","n","o","k","j",'"',"]"),V(8001,10111,60101,function(){return n(b)[X]}),v=W("[","i","d","^","=","m","k","t","_","]",",","[","c","l","a","s","s","^","=","m","k","t","_","]"),V(8002,10111,60101,function(){return n(v)[X]}),y=W("[","i","d","^","=","g","b","f","T","o","o","l","]"),V(9001,5011,20011,function(){return n(y)[X]}),_=W("s","c","r","i","p","t","[","i","d","^","=","g","f","e","_","]"),V(9002,50101,60101,function(){return n(_)[X]}),x=W("[","i","d","^","=","g","u","r","a","b","u","r","u","]"),V(9003,5011,20011,function(){return n(x)[X]}),T=W("s","c","r","i","p","t","[","i","d","^","=","t","k","e","_","]"),V(9004,50101,60101,function(){return n(T)[X]}),w=W("i","n","p","u","t","[","i","d","*","=","b","o","s","s","_","m","o","d","e","_","1","]"),V(9005,5011,20011,function(){return n(w)[X]}),A=W("i","n","p","u","t","[","i","d","*","=","t","e","m","p","o","r","a","r","y","_","s","m","a","l","l","]"),V(9005,5011,20011,function(){return n(A)[X]}),q=W("h","o","o","k","A","j","a","x"),I=W("u","n","H","o","o","k","A","j","a","x"),M=W("_","a","h","r","e","a","l","x","h","r"),V(10102,5011,20011,function(){return U[q]||U[I]||U[M]}),S=(U[O=W("X","M","L","H","t","t","p","R","e","q","u","e","s","t")]+"")[X],V(2002,5011,20011,function(){return S!==(U[O]+"")[X]}),G=W("h","a","s","h"),H=W("i","n","d","e","x","O","f"),P=W("#","r","a","i","d","/"),D=W("#","r","a","i","d","_","m","u","l","t","i","/"),F=W("r","e","q","u","i","r","e"),J=W("m","W","a","i","t","A","l","l"),L=W("l","i","b","/","r","a","i","d","/","m","o","t","i","o","n"),(-1!==(N=location[G])[H](P)||-1!==N[H](D))&&U[F]([L],function(n){var t=(n[J]+"")[X];V(2003,5011,20011,function(){return t!==(n[J]+"")[X]})}),U[W("M","a","t","h")][W("f","l","o","o","r")],U[W("M","a","t","h")][W("r","a","n","d","o","m")],R=U[W("l","o","c","a","t","i","o","n")][W("h","a","s","h")][W("s","p","l","i","t")]("/")[0],V(4001,511,0,function(){return R!==W("d","e","b","u","g")})});
define('general',["jquery","underscore","backbone","constant","setting","model/data","model/data-loader","lib/get-adjust-zoom-value","lib/get-device-ratio","lib/sound","model/sound","util/navigate","constant/mypage_an","util/touch","general/chat","util/ob","util/oc"],function(e,a,n,t,o,s,i,r,l,c,u,d,p){let m=Game.ua.isSteamApp();if(document.createDocumentFragment){var g=document.createDocumentFragment();if(g){a.each(["sp.mbga.jp"],function(e){var a=document.createElement("link");a.setAttribute("rel","dns-prefetch"),a.setAttribute("href","//"+e),g.appendChild(a)});var b=document.head||document.getElementsByTagName("head")[0];b&&b.appendChild(g)}}var h=[],f=function(e){return void 0===h[e]&&(h[e]=r(window.innerWidth/320)),h[e]},v=function(){var e=!1;return Game.ua.isAndroid()&&Game.ua.hasBrowserName(/chrome/i)&&(e=!0),e},A=function(){clearTimeout(null),setTimeout(function(){if(!(e("video").length>0)||!e("video")[0].webkitDisplayingFullscreen){var a=null,n=document.getElementsByTagName("html")[0];a=window.screen.height>window.screen.width&&0==window.orientation?f("vertical"):f("horizontal"),n.style.zoom=a,v()||(a=1,document.getElementById("viewport").content="initial-scale="+a+",  user-scalable=no")}},500)};e(window).on("orientationchange",function(){Game.ua.isAndroid()?A():window.deviceRatio=l()}),Game.ua.isChromeApp()||Game.ua.isAndApp()?e("body").addClass("pc"):Game.ua.isIOS()&&e("body").addClass("ios");var w=e(document),_=e(".wrapper"),G="[class^='btn-'], [class*=' btn-'], [class^='lis-lead-'], .se, [class^='se-'], [class*=' se-']";w.on("cgtouchstart",G,function(){var a=e(this);if(!a.hasClass("lis-summon")){if(a.hasClass("on")||a.hasClass("disable"))return;a.addClass("on"),e("#debug a").css("pointer-events","none")}}).on("cgtouchmove cgtouchend",G,function(a){var n=e(this);n.hasClass("lis-summon")||(n.removeClass("on"),e("#debug a").css("pointer-events","")),"mousemove"!==a.type&&e("input:focus").blur(),"touchmove"!==a.type&&Game.ua.isIOS()&&+Game.ua.os.version.split(".")[0]>=10&&e("#wrapper").find("select:focus").blur()}).on("tap",G,function(a){var n=e(this);u.playButtonSE(n),(Game.ua.isChromeApp()||Game.ua.isAndApp())&&a.preventDefault()}),Game.ua.isIOS()&&+Game.ua.os.version.split(".")[0]>=10&&w.on("change","select:focus",function(){e(this).blur()});var C=e(".pop-global-menu"),E=e(".btn-head-pop"),y=e(".btn-head-close");let S=async()=>{let e=await window.dynamicImport("view/quest/airspace/api/airspace_info.typed.js"),{MAIN_STORY:a}=await window.dynamicImport("view/quest/airspace/constants.typed.js"),n=await e.getAirspaceInfo();if(!n.isOpenAirspaceAct1&&!n.openActIdList.includes(a.ACT_ID.ACT_2))return Game.view.isAn&&(Game.mypageAnz=p.MENU_WORLD),d.hash("quest/world",{refresh:!0});let t=await window.dynamicImport("./view/quest/airspace/components/pop_nav_world.typed.js");Game.view.isAn&&Game.view.getAnz(p.MENU_WORLD),t.popNavWorld(n)};function T(){_.css({minHeight:""})}if(_.on("tap",".btn-head-pop:not(.disable)",function(){var a;C.removeClass("slide_hide").addClass("slide_pop"),_.addClass("global-on"),E.css("display","none"),y.css("display","block"),m&&e(".cnt-global-header").addClass("open-landscape-menu"),_.height()<(a=C.height())&&_.css({minHeight:a}),Game.view.isAn&&Game.view.getAnz(p.MENU)}).on("tap",".btn-head-close",function(){C.removeClass("slide_pop").addClass("slide_hide"),_.removeClass("global-on"),E.css("display","block"),y.css("display","none"),m&&e(".cnt-global-header").removeClass("open-landscape-menu"),T()}).on("tap","div[class *= 'btn-global-'], div[class *= 'btn-footer-']",function(a){var t=e(a.currentTarget);if(e(a.currentTarget).data("location-href")){if(e(a.currentTarget).hasClass("event-select"))d.href(e(a.currentTarget).data("location-href"));else if("coopraid"===t.data("locationHref")&&t.hasClass("disable"))!0===t.hasClass("is-restriction")?Game.view.popRestriction():Game.view.popCoopRank();else if("quest/world"===t.data("location-href"))S();else{n.history.fragment="";var o=e(a.currentTarget).data("location-href");Game.view.isAn&&(t.hasClass("btn-global-party")?Game.mypageAnz=p.MENU_PARTY:t.hasClass("btn-global-enhancement")?Game.mypageAnz=p.MENU_ENHANCE:t.hasClass("btn-global-coopraid")?Game.mypageAnz=p.MENU_COOP:t.hasClass("btn-global-gacha")?Game.mypageAnz=p.MENU_GACHA:t.hasClass("btn-global-quest")?Game.mypageAnz=p.MENU_QUEST:t.hasClass("btn-global-sub")?Game.mypageAnz=({profile:p.MENU_PROFILE,"archive/top":p.MENU_ARCHIVE,item:p.MENU_ITEM,shop:p.MENU_SHOP,present:p.MENU_PRESENT})[o]:t.hasClass("btn-global-ex")?Game.mypageAnz=({list:p.MENU_LIST,container:p.MENU_CONTAINER,friend:p.MENU_FRIEND})[o]:t.hasClass("btn-global-setting")?Game.mypageAnz=p.MENU_SETTING:t.hasClass("btn-global-help")&&(Game.mypageAnz=p.MENU_HELP)),n.history.navigate(o,!0),"setting"===o&&a.preventDefault()}}else e(a.currentTarget).hasClass("btn-global-knights")&&Game.view.globalLink("guild");T()}).on("cgtouchstart",".prt-global-cover div[class *= 'btn-global-']",function(a){var n=e(a.currentTarget).data("cover-name");_.find(".prt-global-main .prt-global-"+n).addClass("on")}).on("cgtouchmove cgtouchend",".prt-global-cover  div[class *= 'btn-global-']",function(){e(".prt-global-main div").removeClass("on")}).on("tap","div[class *= 'btn-treasure-footer-']",function(a){if(e(a.currentTarget).data("location-href")){n.history.fragment="";var t=e(a.currentTarget).data("location-href");n.history.navigate(t,!0)}else if(e(a.currentTarget).hasClass("btn-treasure-footer-back")&&window.history.back(),e(a.currentTarget).hasClass("btn-treasure-footer-reload")&&window.location.reload(),e(a.currentTarget).hasClass("btn-treasure-footer-setting")){var s={},i=e(a.currentTarget).data("size");s=3==i?{is_fixwindowsize:0}:{windowsize:i,is_fixwindowsize:1},o.saveSetting(s).done(function(){window.location.reload()})}}).on("tap","#global-sidestory-disabled",function(){Game.view.popSidestoryUnavailableGlobal()}).on("tap","#global-arcarum-disabled",function(){Game.view.popArcarumUnavailableGlobal()}),e(".btn-head-top").on("tap",function(a){if(Game.view.isAn){Game.view.getAnz(p.TOP).then(function(){location.href=e(a.currentTarget).data("location-href")});return}location.href=e(a.currentTarget).data("location-href")}),w.on("change",".btn-sort",function(){u.playSortSE()}),Game.ua.isSteamApp()){let a=".steamAppRestoreSelectEvents",n="blur".concat(a," change").concat(a);w.on("touchstart","select",function(){let t=e(this);t.css("pointer-events","none"),t.one(n,function(){t.css("pointer-events",""),t.off(a)})})}if(Game.ua.isIOS()&&-1!==Game.ua.versionCompare(Game.ua.os.version,"10")){var N=-300,I=-20,M=-20;window.addEventListener("touchend",function(e){var a=N,n=I,t=M;N=e.timeStamp,I=e.changedTouches[0].pageX,M=e.changedTouches[0].pageY,e.timeStamp-a<300&&20>Math.abs(e.changedTouches[0].pageX-n)&&20>Math.abs(e.changedTouches[0].pageY-t)&&e.preventDefault()},!1)}function L(a,n){var s,i;!(0==Game.setting.effect_mode||!(c.isSupportedWebAudio()||c.isSupportedNativeAudio())||Game.setting.sound_flag==n||"INPUT"===(i=s=function(a){if("LABEL"===a.prop("tagName")){var n=a.attr("for");n&&(a=e("#"+n))}return a}(s=a)).prop("tagName")&&"radio"===i.attr("type")&&!s.prop("checked"))&&((0,o.saveSetting)({sound_flag:n}).done(function(e){var n;void 0!==e&&!0===e.polling_error&&(n="popPollingError","string"==typeof a.attr("id")&&"-sm"===a.attr("id").slice(-3)?Game.submenu.contentView.trigger(n):Game.view.trigger(n))}),o.enableSound(n,!0).done(function(){c.isEnabled()?(a.addClass("enable soundOn"),c.hasAlias(t.BGM_ALIAS)&&c.repeat(t.BGM_ALIAS),c.hasAlias(t.SE_ALIAS)&&c.play(t.SE_ALIAS)):(a.removeClass("enable soundOn"),c.hasAlias(t.BGM_ALIAS)&&c.stop(t.BGM_ALIAS),c.hasAlias(t.SE_ALIAS)&&c.stop(t.SE_ALIAS),c.hasAlias(t.VOICE_ALIAS)&&c.stop(t.VOICE_ALIAS))}))}w.on("tap",".btn-enable-sound",function(a){L(e(a.currentTarget),!0,!0)}),w.on("tap",".btn-disable-sound",function(a){L(e(a.currentTarget),!1,!1)}),w.on("tap",".btn-switch-sound",function(a){var n=e(a.currentTarget),t=!n.hasClass("soundOn");L(n,t,t),Game.view.isAn&&Game.view.getAnz(p.SOUND)}),w.off("change","#sound-setting, #sound-setting-sm").on("change","#sound-setting, #sound-setting-sm",function(a){var n=e(a.currentTarget);!0===n.prop("checked")?L(n,!0):L(n,!1)}),w.on("tap",".btn-bgm-change",function(a){if(0!=Game.setting.effect_mode&&(c.isSupportedWebAudio()||c.isSupportedNativeAudio())){var n=e(a.currentTarget);n.hasClass("btn-switch-sound")||(c.isDisabled()?n.removeClass("enable soundOn"):c.isMuted()?(c.unmute(),c.resume(t.BGM_ALIAS),n.addClass("enable soundOn")):(c.mute(),c.pause(t.BGM_ALIAS),n.removeClass("enable soundOn")))}}),w.find(".cnt-global-header, .cnt-global-footer, .cnt-pc-global-footer").on("tap","[class^='btn-'], [class*=' btn-']",function(){u.stopVoice()});var U=["se/btn_se/btn_se_01.mp3","se/btn_se/btn_se_02.mp3","se/btn_se/btn_se_03.mp3","se/queststart_se_1.mp3","se/stamp_se_1.mp3","se/menu_open_se_1.mp3","se/menu_close_se_1.mp3"];return o.initialize().done(function(){1==+Game.setting.sound_flag&&c.loadFiles(U)}),Game.ua.isJssdkSideMenu()&&Game.ua.isMbga()&&require(["lib/mobage-jssdk"],function(a){a.callAfterReady(function(){if(window.mobage&&"3.10.1"===window.mobage.SDK_VERSION){var a,n='li[data-menubar-listlink="LogoutLink"]',t=e('li[data-menubar-sidebutton="Account"]'),o=function(){e(window).off("focus.mobageMenuLogout"),e(window).one("focus.mobageMenuLogout",function(){e('li[data-menubar-sidebutton="Login"]').length&&location.reload()})};setTimeout(function(){(a=e(n)).length&&a.on("click",o)},300),t.on("click",function(){setTimeout(function(){e('div[data-menubar-content-wrapper="wrapper"]').oneAnimationEnd(function(){a.off("click"),setTimeout(function(){(a=e(n)).length&&a.on("click",o)},300)})},0)})}})}),{hideURLbar:function(){window.scrollTo(0,1)},isTapSelector:function(e){return e.is(G)}}});
define('catalog/user_agent',[],function(){return{model:["SO-04E","SO-01F","P-03E","SOL22","SOL23","LGL22"]}});
define('model/content',["underscore","backbone","model/data","lib/sound","model/sound"],function(t,e,n,o,i){return n.extend({urlRoot:function(){var e=Game.baseUri+(""!==this.get("module")?this.get("module")+"/":"")+this.get("controller")+"/content/"+this.get("action"),n=this.get("param");if(null!=n){var o="";t.each(n,function(t,e){o+="/"+t}),e+=o}return e},initialize:function(t){n.prototype.initialize.apply(this)},defaults:function(){return{module:"",controller:"",action:"index",param:null}},error:function(t,e,o){n.prototype.error.apply(this,[t,e,o])}})});
define('model/pagination',["backbone","underscore","model/data"],function(t,e,n){return n.extend({urlRoot:function(){var t=Game.baseUri+(""!==this.get("module")?this.get("module")+"/":"")+this.get("controller")+"/"+this.get("action")+"/"+this.get("page"),n=this.get("param");if(null!=n){var i="";e.each(n,function(t,e){i+="/"+t}),t+=i}return t},parse:function(i){n.prototype.parse.call(this,i);var o=new(t.Collection.extend());return e.each(i.list,function(t,e){o.add(t)}),{paging:{first:i.first,last:i.last,prev:i.prev,next:i.next,page:this.get("page")},list:o,options:e.isEmpty(i.options)?null:i.options,base:i}},defaults:function(){return{module:"",controller:"",action:"index",param:null,page:1}}})});
define('model/manifest-loader',["underscore","backbone","util/backbone-singleton"],function(e,t){var i=window.images=window.images||{},n={},a=t.Model.extend({initialize:function(){this.loadQueue=new createjs.LoadQueue(!1),this.loadQueue.setMaxConnections(5),this.loadQueue.addEventListener("error",e.bind(this.handleError,this)),this.loadQueue.addEventListener("fileload",e.bind(this.handleFileLoad,this)),this.loadQueue.addEventListener("complete",e.bind(this.handleComplete,this))},setImageAlias:function(e,t){i[t]=i[e],n[t]=n[e]},handleFileLoad:function(e){var t,n=e.item.id;switch(e.item.type){case createjs.LoadQueue.IMAGE:t=e.result,i[n]=t;case createjs.LoadQueue.CSS:}this.trigger("fileload",e)},handleComplete:function(e){this.trigger("complete",e)},handleError:function(e){this.trigger("error",e)},getLoadingTarget:function(t){if(!t)return null;e.isObject(t)||(t={id:t,src:t});var a=t.id;if(e.has(i,a)&&n[a]==t.src)return null;n[a]=t.src;let o=t.src.endsWith(".css")?createjs.LoadQueue.CSS:createjs.LoadQueue.IMAGE;return Object.assign({},t,{type:o})},loadManifest:function(t,i,n){var a=this,o=[];e.each(t,function(t){var i=a.getLoadingTarget(t);i&&(e.defaults(i,{cache:!0}),o.push(i))}),o=e.uniq(o),e.isEmpty(o)?this.loadQueue.dispatchEvent("complete"):this.loadQueue.loadManifest(o,i,n)},loadFile:function(t,i,n){var a=this.getLoadingTarget(t);a&&(e.defaults(a,{cache:!0}),this.loadQueue.loadFile(a,i,n))},load:function(){this.loadQueue.load()},close:function(){this.loadQueue.close()},setMaxConnections:function(e){this.loadQueue.setMaxConnections(e)},addEventListener:function(e,t){this.once(e,t)},clear:function(){e.each(n,function(e,t){delete i[t]}),n={}},reset:function(){this.loadQueue.reset()}});return a.makeSingleton(["loadFile","loadManifest","load","clear","setImageAlias","on","off","once","addEventListener","reset"]),a});
define('model/cjs-loader',["jquery","underscore","backbone","model/manifest-loader","util/backbone-singleton"],function(e,n,t,r){var i=window.lib=window.lib||{},a={},o={},c={},s={},u="cjs/",f="model/manifest/",l=Game.baseUri+"cassets/cache/"+Game.jsUri.replace(/.*\//g,""),d=t.Model.extend({loadFiles:function(t,l){var d=this,m=new e.Deferred,v=n.reject(t,function(e){return n.has(a,e)||n.has(o,e)});n.each(v,function(e){o[e]=1}),v=n.unique(n.sortBy(v));var h=function(){m.resolve();var e=n.difference(n.union(t,n.keys(o)),n.keys(a));n.isEmpty(e)?d.trigger("complete"):1===Game.isSandbox&&d.trigger("failed",e)};if(n.isEmpty(v))h();else{var p=new e.Deferred,w=new createjs.LoadQueue(!1,Game.jsUri+"/",!0);w.setMaxConnections(5),w.on("complete",function(){p.resolve()}),w.on("fileload",function(e){if(e.item){var t=e.item.id;if(t){var r=n.last(t.split("/"));i[r].prototype.playFunc=function(e){createjs.Tween.get().wait(1).call(e)},a[r]=r,c[t]=i[r]}}}),w.on("error",function(e){p.reject()});var j=n.map(v,function(e){var n=u+e;return{id:n,src:n+".js",type:createjs.LoadQueue.JAVASCRIPT,cache:!0}});w.loadManifest(j);var y=new e.Deferred,g=[],b=v.length||n.size(v),M=0;n.each(v,function(e){var n=f+e;requireAMD([n],function(e){s[n]=e.prototype.defaults.manifest,l&&s[n].length>0&&(g=g.concat(s[n])),b===++M&&(g.length>0?(r.once("complete",function(){y.resolve()}),r.loadManifest(g,!0)):y.resolve())})}),e.when(p,y).always(function(){h()})}return m},cjs:function(e){return e?c[u+e]:n.values(c)},manifest:function(e){return e?s[f+e]:n.values(s)},clear:function(){n.each(n.keys(window.requirejs.s.contexts._.defined),function(e){0==e.indexOf(l)&&(requireAMD.undef(e),delete i[e])}),n.each(c,function(e,n){requireAMD.undef(n),delete i[n]}),n.each(s,function(e,n){requireAMD.undef(n),delete i[n]}),a={},o={},c={},s={},r.clear()}});return d.makeSingleton(["loadFiles","cjs","manifest","clear","on","off","once"]),d});
define('view/form',["jquery","underscore","backbone","view/popup"],function(e,t,s,n){var a="#pop-chat",i="submit",r=s.View.extend({el:".frm-group",$frmMessage:null,inputComment:"",events:{"touchstart .frm-message:not(.disable)":"onTouchstartTextarea","touchend .frm-message:not(.disable)":"onTouchendTextarea","focus .frm-message:not(.disable)":"onFocusTextarea","blur .frm-message:not(.disable)":"onBlurTextarea","tap .btn-talk-message:not(.disable)":"checkMessage"},initialize:function(){this.$frmMessage=this.$el.find(".frm-message"),this.$btnTalkMessage=this.$el.find(".btn-talk-message"),this.setupInput()},setupInput:function(e){var t=this;(e=e||this.$frmMessage).keyup(function(e){if(t.textPattern(),13===e.keyCode)return!1}),e.keypress(function(e){if(13===e.keyCode)return!1})},onTouchstartTextarea:function(e){this.trigger("touchstart",e)},onTouchendTextarea:function(e){this.trigger("touchend",e)},onFocusTextarea:function(e){this.trigger("focus",e)},onBlurTextarea:function(t){this.inputComment=e(t.currentTarget).val(),this.trigger("blur",t)},disable:function(){this.disableSubmit(),this.disableInput(),this.trigger("disabled")},disableSubmit:function(){this.$btnTalkMessage.addClass("disable")},disableInput:function(){this.$frmMessage.addClass("disable"),this.$frmMessage.attr("disabled","disabled")},enable:function(){this.$btnTalkMessage.removeClass("disable"),this.enableInput()},enableInput:function(){this.$frmMessage.removeClass("disable"),this.$frmMessage.removeAttr("disabled")},blurInput:function(){this.$frmMessage.blur()},clearInput:function(){this.$frmMessage.val(""),this.blurInput(),this.inputComment=""},textPattern:function(e){var t=this.$frmMessage.val()?this.$frmMessage.val().length:0,s=e||t,n=140-s,a=this.$el.find(".mes-counter");a.html(s<=0?"":n),a.toggleClass("max",n<=10),n<0?(this.$el.find(".ready-chat .btn-usual-send").addClass("btn-chat-disable").removeClass("btn-usual-send"),this.$el.find(".prt-talk-input .btn-talk-message").addClass("prt-talk-message-off").removeClass("btn-talk-message")):(this.$el.find(".ready-chat .btn-chat-disable").addClass("btn-usual-send").removeClass("btn-chat-disable"),this.$el.find(".prt-talk-input .prt-talk-message-off").addClass("btn-talk-message").removeClass("prt-talk-message-off"))},checkMessage:function(){if(this.blurInput(),this.inputComment&&this.checkSpace(this.inputComment)){if(this.inputComment.length>140){var e="140文字以内で入力してください。";this.trigger("submissionExcessError",e);return}}else{var e="1文字以上入力してください。";this.trigger("submissionEmptyError",e);return}this.trigger(i,{comment:this.inputComment}),this.textPattern(),this.clearInput()},checkSpace:function(e){return!!e.match(/\S/)||(this.$frmMessage.val(""),!1)},errorChat:function(t){var s=this,n=new o({err_msg:t});n.on(i,function(e){s.trigger(i,e)}),n.render();var a=e("#frm-message.frm-message");this.setupInput(a),this.textPattern(a)},popErrorDialog:function(e){e||(e="エラーにより送信できませんでした。");var t=new n({el:a,className:"common-pop-error",title:"利用制限",body:e,flagBtnCancel:0,flagBtnOk:1});t.on("ok",function(){t.popRemove()}),t.render(),t.popShow()},popIntervalErrorDialog:function(){this.popErrorDialog("先の利用から5秒経過すると<br>再度利用可能です。")},popCompletionDialog:function(){var e=new n({el:a,className:"send-chat",title:"送信完了",body:"チャットを送りました。",flagBtnCancel:0,flagBtnOk:1});e.on("ok",function(){e.popRemove()}),e.render(),e.popShow()},destroy:function(){this.off(),this.undelegateEvents(),this.stopListening()}}),o=r.extend({el:"",$frmMessage:null,template:t.template(e("#tpl-chat-pop").html()),events:{"blur #frm-message":"onBlurTextarea"},initialize:function(){var e=this.options.err_msg;this.create(e)},render:function(){return this.renderPopup(),this.$frmMessage=e("#frm-message"),this},create:function(e){var t=this;(void 0==e||""==e)&&(e="禁止ワードが含まれています。"),!0==e&&(e="");var s={inputText:this.inputComment,errflag:!0,msg:e,count_max:140};this.popView=new n({el:a,className:"ready-chat",title:"チャット",body:this.template(s),flagBtnCancel:1,flagBtnOk:1}),this.popView.on("ok",function(){t.popView.popOff(),t.popView.popRemove(),t.checkMessage()}),this.popView.on("cancel",function(){t.popView.popRemove()})},renderPopup:function(){this.popView.render(),this.popView.popShow(),this.setElement(".ready-chat")}});return r});
define('view/captcha',["jquery","underscore","backbone","view/form","model/token-data","util/language-message"],function(e,t,i,s,n,o){return i.View.extend({el:"#pop-c-a-i",events:{},initialize:function(){this.$dynamicMessage=this.$el.find(".txt-c-a-i-message"),this.$image=this.$el.find(".image"),this.$frmGroup=this.$el.find("#c-a-i-frm-group"),this.createSubView()},createSubView:function(){var e=this;this.formView=new s({el:this.$frmGroup}),this.formView.on("submit",function(t){e.onSubmitForm(t)}).on("submissionEmptyError",function(){e.$dynamicMessage.html(o.getMessage("pop_captcha_empty"))}).on("submissionExcessError",function(t){e.$dynamicMessage.html(t)})},onSubmitForm:function(e){this.$dynamicMessage.empty();var t=new(n.extend({urlRoot:Game.baseUri+"c/a"}));this.listenToOnce(t,"sync",this.onSaveForm),t.set(e),t.save()},onSaveForm:function(e){e.attributes.is_correct?this.trigger("success"):(this.$dynamicMessage.html(o.getMessage("pop_captcha_incorrect")),this.$image.attr("src","c/i?t="+Math.floor(new Date().getTime()/1e3)),this.trigger("failure"))},destroy:function(){this.off(),this.undelegateEvents(),this.stopListening(),this.destroySubView()},destroySubView:function(){this.formView.destroy()}})});
define('view/submenu/_util',["util/local-storage"],function(e){return{adjustSubmenuHeight:function(){var t=$("#submenu"),g=$("#wrapper").height(),u=t.height(),a="global";!0===e.isSupported()&&e.getObject("gbf_pcsbm")&&(a=e.getObject("gbf_pcsbm").current);var b=g>u,l="global"===a&&b||"global"!==a&&!b;t.toggleClass("auto-height",l)}}});
define('util/string',[],function(){var t=/([^\uD800-\uDFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF])(\uDB40[\uDD00-\uDDEF])?/g,n=function(t,n,r){var e=""+t;if(e.length>=n)return e;var u=n-e.length;return Array(u+1).join(r).slice(0,u)+e},r=function(t,n){var r=+t%100,e=(n||{}).isOnlySuffix?"":t;if(3<r&&r<21)return e+"th";switch(r%10){case 1:return e+"st";case 2:return e+"nd";case 3:return e+"rd";default:return e+"th"}},e=function(n){return n.match(t)||[]},u=function(t){return t&&_.isString(t)?e(t).length:0},i=function(t,n){return _.reduce(t,function(t,r){return Math.max(t,u(r[n]))},0)},c=function(t){return t.replace(/<("[^"]*"|'[^']*'|[^'">])*>/g,"")};let a=function(t){return t.replace(/<(?!ruby|\/ruby|rt|\/rt)(.|\s)*?>/g,"")};var f=function(t){return t[0].toUpperCase()+t.slice(1)},o={};return Object.defineProperties(o,{padStart:{get:function(){return n}},cardinal2Ordinal:{get:function(){return r}},stringToArray:{get:function(){return e}},getLength:{get:function(){return u}},getMaxLengthInCollection:{get:function(){return i}},stripTag:{get:function(){return c}},stripTagExceptForRuby:{get:function(){return a}},capitalize:{get:function(){return f}},REGEX_ALTERNATE_CHAR:{value:t}}),o});
define('view/content',["underscore","backbone","model/content","model/data","model/token-data","lib/shellapp","lib/sound","model/sound","view/popup","view/captcha","util/ajax","util/local-storage","util/language-message","view/submenu/_util","util/string","util/navigate","constant/mypage_an"],function(e,t,i,n,o,a,s,r,l,c,u,d,p,h,m,f,g){var v=function(e,t,i){window.cjsSetCacheManifestCompat?window.cjsSetCacheManifestCompat(e,t,i):createjs.Config&&createjs.Config.setCacheManifest?createjs.Config.setCacheManifest(e,t,i):window.AndroidCacheProxy&&window.AndroidCacheProxy.setCacheManifest&&window.AndroidCacheProxy.setCacheManifest(e,t,i)},w=/^(\S+)\s*(.*)$/,y={READY_FADE_OUT:"readyFadeOut",LOAD_ADDITIONAL_CSS_COMPLETE:"loadAdditionalCssComplete"},b=t.View.extend({el:".contents",enableTutorialMovie:!1,setTimeoutTimerIdObj:{},setIntervalTimerIdObj:{},content_bind:function(){this.on("loadStart",Game.loading.loadStart),this.on("xhrStart",Game.loading.xhrStart),this.on("loadEnd",Game.loading.loadEnd),this.on("xhrEnd",Game.loading.xhrEnd),this.on("page_error",this.page_error),this.on("data_error",this.data_error),this.on("popup_error",this.popup_error),Game.mypageAnz&&(this.getAnz(Game.mypageAnz),Game.mypageAnz=null)},content_render:function(t){if(t.get("redirect"))return!1;this.content_clear(),this.$el.html(decodeURIComponent(t.get("data"))),a.isShellApp()&&new(n.extend({urlRoot:Game.baseUri+"analytics/purchase_info"}))().fetch({ignoreError:!0,success:function(t){t.hasChanged()&&a.sendAdjustRevenueEvent.apply(a,e.map(["adjust_event_id","price","quantity","currency"],e.bind(t.get,t)))},error:function(){}});var i=a.getRemoteNotification();if(i){var s=i.extras||null,r=new(o.extend({urlRoot:Game.baseUri+"user/remote_notification_reward",success:function(e){},error:function(e,t,i){}}));r.set({extras:s}),r.save()}var l=t.get("option");if(void 0===l.isSubView||!l.isSubView){if(e.isEmpty(l.anenounce))$(".anenounce").css("display","none"),this.stopAnenounce(),$(".anenounce").text("");else{var c=l.anenounce.split("\n");$(".anenounce").css("display","block"),this.startAnenounce(c)}!e.isEmpty(l.force_process_ids)&&e.has(l.force_process_ids,1)&&(window.cjsSetCacheManifestCompat?window.cjsSetCacheManifestCompat(Game.modifiedListUri,-1,0):a.isShellAppWKWebView()?webkit.messageHandlers.wkcjs_settings.postMessage({cacheClear:!0}):v(Game.modifiedListUri,0,0))}(!0===Game.ua.isPcPlatform()||Game.ua.isAndApp())&&this.adjustSubmenuHeight(),this.global_initialize()},getAnz:function(e){return new(n.extend({urlRoot:Game.baseUri+"an/z/"+e}))().fetch({ignoreError:!0})},adjustSubmenuHeight:function(){h.adjustSubmenuHeight()},globalLink:function(e){"guild"===e&&new(n.extend({urlRoot:Game.baseUri+"rest/guild/main/guild_info"}))().fetch({success:function(e){var i="";e.get("is_guild_open")?e.get("is_guild_in")?($(".btn-global-knights, .btn-guild-name").attr("data-location-href","guild"),i="guild"):e.get("request_guild_id")?($(".btn-global-knights, .btn-guild-name").attr("data-location-href","guild/reserve/"+e.get("request_guild_id")),i="guild/reserve/"+e.get("request_guild_id")):e.get("invite_guild_id")?($(".btn-global-knights, .btn-guild-name").attr("data-location-href","guild/scout/"+e.get("invite_guild_id")),i="guild/scout/"+e.get("invite_guild_id")):($(".btn-global-knights, .btn-guild-name").attr("data-location-href","guild/notjoin"),i="guild/notjoin"):($(".btn-global-knights, .btn-guild-name").attr("data-location-href","guild/notjoin"),i="guild/notjoin"),Game.view.isAn&&(Game.mypageAnz=g.MENU_GUILD),t.history.fragment="",t.history.navigate(i,!0)},error:function(e,t){if(u.isManuallyAbortedXHR(t))return}})},listenToOnce:function(i,n,o){return o||(o=function(){}),new Promise((function(a){t.View.prototype.listenToOnce.call(this,i,n,e.compose(a,o))}).bind(this))},popCoopRank:function(){this.popDisable("menu_pop_1",$("#tpl-pop-coop").html())},popRestriction:function(){this.popDisable("menu_pop_3",$("#tpl-pop-restriction-coop").html())},popDisable:function(e,t){var i=this,n="";function o(){var e=new l({el:"#pop",className:"pop-disable",title:n,body:t,flagBtnClose:1});e.render().popShow(),i.listenToOnce(e,"close",function(){e.popRemove()})}this.$el.find("#pop").length<=0&&this.$el.append('<div id="pop">'),p.hasMessage(e)?(n=p.getMessage(e),o()):this.getLanguageInfo(e,"common").done(function(t){n=t[e].msg,o()})},renderTextPopup:function(e){var t,i=e.title,n=e.body,o=e.className||null,a=e.flagBtnOk||0,s=e.flagBtnCancel||0,r=e.flagBtnClose||0;let c=+!!e.maskCloseFlag;var u=new l({className:o,title:i,body:n,flagBtnOk:a,flagBtnCancel:s,flagBtnClose:r,showEndCallback:null!==(t=e.showEndCallback)&&void 0!==t?t:null}),d=a?"ok":s?"cancel":"close";return u.render().popShow(),new Promise((function(e){this.listenToOnce(u,d,function(){u.popRemove(c),e()})}).bind(this))},getLanguageInfo:function(e,t){var i=null,o=Game.baseUri+"rest/languageinfo/js_language_info",a=new(n.extend({urlRoot:o+"/"+e+"/"+t}));return this.getLanguageInfo=function(e,t){return i=$.Deferred(),a.urlRoot=o+"/"+e+"/"+t,a.fetch().done(function(e){i.resolve(e)}),i},this.getLanguageInfo(e,t)},popArcarumUnavailableGlobal:function(){this.popView=new l({className:"pop-arcarum-unavailable",title:$("#tpl-pop-arcarum-unavailable").data("popTitle"),body:$("#tpl-pop-arcarum-unavailable").html(),flagBtnClose:1,events:{"tap .btn-usual-close":"popRemove"}}),this.popView.render().popShow()},popSidestoryUnavailableGlobal:function(){this.popView=new l({className:"pop-sidestory-unavailable",title:$("#tpl-pop-sidestory-unavailable").data("popTitle"),body:$("#tpl-pop-sidestory-unavailable").html(),flagBtnClose:1,events:{"tap .btn-usual-close":"popRemove"}}),this.popView.render().popShow()},content_clear:function(){$(".mask").removeClass().addClass("mask")},content_close:function(e){this.off(),this.undelegateEvents(),this.stopListening(),this.timerOff(),this.clearTimeoutAll(),this.clearIntervalAll(),this.removeAddedStyle&&this.removeAddedStyle(),this.destroy&&this.destroy(),this.destroySubViews(),e||this.destroyStage(),this.abortAjax();var t=d.get("model_error_hash")||"",i=location.hash+"_model_error";""!==t&&t!=i&&(d.remove(t),d.remove("model_error_hash"))},destroyImages:function(){if(this.el&&!a.isShellApp()){var e=0,t=this.el.getElementsByTagName("img");for(e=0;e<t.length;++e)t[e].src="";var i=this.el.getElementsByTagName("canvas");for(e=0;e<i.length;++e)i[e].width=0}},resolveReadyFadeOut(){Game.ua.isSteamApp()&&this.initializeClientSidemenu(),$(".contents").css("display","block"),(void 0===this.isStayReadyContentRender||!1===this.isStayReadyContentRender)&&this.hideReady(),this.trigger("readyFadeOut")},async initializeClientSidemenu(){if(!Game.sideView){let{createView:e}=await window.dynamicImport("view/steam-sidemenu/sideview.js");Game.sideView=await e()}await Game.sideView.toggleBlankSideView()},additionalCss(e){this.css||(this.css=[]),this.css=this.css.concat(e)},loadMultipleCss(e){let{skipReadyFadeOut:t}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{skipReadyFadeOut:!1},i=!1,n=[...new Set(e)],o={},a=new createjs.LoadQueue(!0),s=n.map((e,t)=>({index:t,id:e,src:e,name:e,type:"text"}));return a.setMaxConnections(s.length),a.loadManifest(s),a.addEventListener("fileload",e=>{let t=e.result,i=document.createElement("style");i.type="text/css",i.className="page",i.setAttribute("css-id",e.item.name),i.innerHTML=t,o[e.item.index]=i}),new Promise((e,n)=>{a.addEventListener("complete",()=>{if(a.removeAllEventListeners(),!i){for(let[e,t]of Object.entries(o))document.head.appendChild(t);t||this.resolveReadyFadeOut(),e()}}),a.addEventListener("error",e=>{alert("読み込みエラー:c001\nお手数ですが、ページを再読み込みしてください。"),i=!0,n()})})},global_initialize:function(){$(".mask").removeClass().addClass("mask").hide(),$(".wrapper").removeClass("global-on").css({minHeight:""}),$(".btn-head-close").css("display","none"),Game.ua.isSteamApp()&&$(".cnt-global-header").removeClass("open-landscape-menu"),$(".btn-head-pop").css("display","block"),$(".pop-global-menu").removeClass("slide_pop");var e=location.href;!1!=(-1===e.indexOf("setting/mypage")&&-1===e.indexOf("mypage_character")&&(-1!==e.indexOf("tutorial/23")||-1!==e.indexOf("tutorial/28")||-1!==e.indexOf("tutorial/1301")||-1!==e.indexOf("mypage")))?($(".btn-head-top").css("display","block"),$(".btn-head-mypage, .prt-head-mypage-disable").css("display","none")):($(".btn-head-mypage, .prt-head-mypage-disable").css("display","block"),$(".btn-head-top").css("display","none"));var t=this,i=this.$el.find("#asset-css").data("css");if($("head>style.page").remove(),i){var n=Game.cssUri+i,o=new createjs.LoadQueue(!0),a=!1;o.addEventListener("fileload",function(e){e.item.type===createjs.LoadQueue.CSS&&(e.result.className="page")}),o.addEventListener("complete",function(e){o.removeAllEventListeners(),a||t.resolveReadyFadeOut()}),o.addEventListener("error",function(e){alert("読み込みエラー:c001\nお手数ですが、ページを再読み込みしてください。"),a=!0}),o.loadFile(n)}else{let e=$(".require-css").map((e,t)=>$(t).data("css")).get();if(!e.length&&!this.css){this.resolveReadyFadeOut();return}this.css||(this.css=[]);let t=e.concat(this.css).map(e=>"".concat(Game.cssUri,"/").concat(e));this.loadMultipleCss(t)}var r=this.$el.find(".btn-bgm-change");0==window.Game.setting.effect_mode||s.isDisabled()?r.removeClass("enable soundOn"):r.addClass("enable soundOn"),0===Game.setting.effect_mode&&$("#btn-auto").remove();var l=$("#auto_scene_mode").data("auto-scene-mode"),c=$("#btn-auto");"on"===l?(c.removeClass("off"),window.setTimeout(function(){c.css("opacity",.001)},2e3)):c.addClass("off")},hideReady:function(){$("#ready").css("display","none")},setPageTitle:function(e){$("#prt-head-current").html(e)},numRepStatus:function(e,t){e.html(""),e.each(function(){for(var e=$(this).attr("data-title"),i=$(this).attr("additional-stamina"),n=!1,o=0;o<e.length;o++)","==e[o]?$(this).append("<span class='"+t+"-comma' />"):"/"==e[o]?(n=!0,$(this).append("<span class='"+t+"-slash' />")):":"==e[o]?$(this).append("<span class='"+t+"-coron' />"):1==i&&!1==n?$(this).append("<span class='"+t+"-additional"+e[o]+"'></span>"):$(this).append("<span class='"+t+e[o]+"'></span>")})},bp_replace:function(e,t){var i=+e.data("current-bp"),n="",o=0,a=+t>5?5:+t;switch(!0){case i>=10:o=5;break;case i<=5:break;default:o=i-5}e.html("");for(var s=0;s<a;s++)n=s<o?" over-limit":"",e.append("<span class='ico-bp"+n+"'></span>")},getTime:function(e){var e=new Date(1e3*e),t=[];return t.yyyy=e.getFullYear(),t.m=e.getMonth()+1,t.d=e.getDate(),t.hour=e.getHours(),t.min=e.getMinutes(),t.sec=e.getSeconds(),t},limitTime:function(e,t){var i=t-e,n=[];return n.days=Math.floor(i/86400),n.hour=Math.floor(i%86400/3600),n.min=Math.floor(i%86400/60%60),n.sec=Math.floor(i%86400%60),n.differenceSec=i,n},timerOn:function(e,t,i){var n=this;clearInterval(window.timerId),i?window.timerId=setInterval(function(){n.countDownTimeDifferentFomat(e,t)},1e3):window.timerId=setInterval(function(){n.countDownTime(e,t)},1e3)},timerOff:function(){void 0!==window.timerId&&(clearInterval(window.timerId),delete window.timerId),this.trigger("timerOff")},setNamedTimeout:function(e,t,i){this.setTimeoutTimerIdObj[e]=setTimeout(t,i)},clearTimeoutAll:function(){if(!(1>e.size(this.setTimeoutTimerIdObj))){var t=this;e.each(this.setTimeoutTimerIdObj,function(e,i){clearTimeout(e),delete t.setTimeoutTimerIdObj[i]})}},clearTimeoutOne:function(e){this.setTimeoutTimerIdObj[e]&&(clearTimeout(this.setTimeoutTimerIdObj[e]),delete this.setTimeoutTimerIdObj[e])},_hasNamedTimeout:function(t){return e.has(this.setTimeoutTimerIdObj,t)},setNamedInterval:function(e,t,i){this.setIntervalTimerIdObj[e]=setInterval(t,i)},clearIntervalAll:function(){if(!(1>e.size(this.setIntervalTimerIdObj))){var t=this;e.each(this.setIntervalTimerIdObj,function(e,i){clearInterval(e),delete t.setIntervalTimerIdObj[i]})}},clearIntervalOne:function(e){this.setIntervalTimerIdObj[e]&&(clearInterval(this.setIntervalTimerIdObj[e]),delete this.setIntervalTimerIdObj[e])},_hasNamedInterval:function(t){return e.has(this.setIntervalTimerIdObj,t)},countDownTime:function(e,t){if(e.differenceSec--,e.sec>0)e.sec--;else if(e.min>0)e.sec=59,e.min--;else if(e.hour>0)e.sec=59,e.min=59,e.hour--;else{if(!(e.days>0))return t&&t.text("0"),this.timerOff(),null;e.sec=59,e.min=59,e.hour=23,e.days--}var i="";return e.differenceSec>=86400&&(i+=e.days+p.getMessage("user_66")),e.differenceSec>=3600&&(i+=e.hour+p.getMessage("user_67")),e.differenceSec>=60&&(i+=e.min+p.getMessage("user_68")),e.differenceSec>=0&&(i+=e.sec+p.getMessage("user_69")),t&&t.text(i),{baseTime:e}},countDownTimeDifferentFomat:function(e,t){if(e.differenceSec--,e.sec>0)e.sec--;else if(e.min>0)e.sec=59,e.min--;else if(e.hour>0)e.sec=59,e.min=59,e.hour--;else{if(!(e.days>0))return t.text("0"),this.timerOff(),!1;e.sec=59,e.min=59,e.hour=23,e.days--}var i="";e.differenceSec>=3600&&(i+=24*e.days+e.hour+"："),e.differenceSec>=60&&(i+=e.min+"："),e.differenceSec>=0&&(i+=e.sec),t.text(i)},_destroyStage:function(t){if(t){var i=createjs.Ticker;if(i.removeEventListener("tick",t),t.autoClear=!0,t.enableDOMEvents(!1),t.removeAllChildren(),t.update(),a.isShellApp()&&window.cjsAndroidSdk>=21&&(t.canvas=null),1===e.size(i._listeners)){if(i._raf){var n=window.cancelAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame||window.oCancelAnimationFrame||window.msCancelAnimationFrame;n&&n(i._timerId)}else clearTimeout(i._timerId);i._timerId=null}}},destroyStage:function(t){var i=this;t?this._destroyStage(t):(window.stage&&(this._destroyStage(window.stage),a.isShellApp()&&window.cjsAndroidSdk),this.stage&&this._destroyStage(this.stage),window.cjs&&e.each(window.cjs.stage,function(e,t){window.cjs.canvas&&(window.cjs.canvas[t]=null),e&&i._destroyStage(e),window.cjs.stage&&(window.cjs.stage[t]=null)}))},stopEventPropagation:function(e,t){t&&r.playButtonSE($(e.currentTarget)),e.preventDefault(),e.stopPropagation()},listenEventAndCall:function(e,t,i){t.off(e),t.on(e,function(e){i(),$(this).off(e)})},checkMobageConnectStatus:function(e){this.trigger("xhrStart");var t=this;if(!e.state){var i=window.clientData;i&&(e.state=i.state)}mobage.oauth.getConnectedStatus(e,function(e,i){i?t.trigger("checkMobageConnectTrue",i):t.trigger("checkMobageConnectFalse")})},postPurchaseJsSdk:function(e,t,i){this.trigger("xhrStart");var n=this,a=new(o.extend({urlRoot:Game.baseUri+e+"/"+t}));a.set(i),this.stopListening(a),this.listenToOnce(a,"sync",function(e){var t=e.toJSON();mobage.ui.open("payment",{transactionId:t.transaction_id,orderId:t.payment_id,zIndex:999999},function(e,t){e||n.trigger("postPurchaseJsSdkComplete",t)}),setTimeout(function(){n.trigger("xhrEnd")})}),a.save()},postPurchaseResult:function(e,t,i){var n=this,a=new(o.extend({urlRoot:Game.baseUri+e+"/"+t}));a.set(i),this.stopListening(a),this.listenToOnce(a,"sync",function(e){n.trigger("postPurchaseResultComplete",i,e)}),a.save()},postPurchaseGree:function(e,t,i){this.trigger("xhrStart");var n=this,a=new(o.extend({urlRoot:Game.baseUri+e+"/"+t}));a.set(i),this.stopListening(a),this.listenToOnce(a,"sync",function(e){var t=e.toJSON(),i=t.client_id;function o(){GREE.oauth.getConnectedStatus(a)}function a(e,i){e&&GREE.ui.payment.open({payment_id:t.transaction_id,cancel_callback:function(e,t){},submit_callback:function(e,i){e&&window.addEventListener("GreeUIClose",function(e){n.trigger("postPurchaseGreeComplete",t)},!1)}}),n.trigger("xhrEnd")}window.isGreeInitialized?o():(window.addEventListener("GreeReady",o,{once:!0}),GREE.init(i,Game.isSandbox))}),a.save()},postPurchaseGreeResult:function(e,t,i){var n=this,a=new(o.extend({urlRoot:Game.baseUri+e+"/"+t}));a.set(i),this.stopListening(a),this.listenToOnce(a,"sync",function(e){n.trigger("postPurchaseResultComplete",i,e)}),a.save()},openTransactionsGree:function(){window.open("https://id.gree.net/?action=misc_tos_protection&page=aosct_download&app_id=66421")},postPurchaseDmm:function(t,i,n){var a=this,s=new(o.extend({urlRoot:Game.baseUri+t+"/"+i}));a.trigger("xhrStart"),s.set(n),a.stopListening(s),a.listenToOnce(s,"sync",function(t){a.trigger("xhrEnd");var i=t.toJSON();$("#prt-dmm-form").html(e.template($("#tpl-dmm-form").html(),i)),$("#dmm-form").submit()}),s.save()},postPurchaseYahoo:function(e,t,i){var n=this,a=new(o.extend({urlRoot:Game.baseUri+e+"/"+t}));n.trigger("xhrStart"),a.set(i),n.stopListening(a),n.listenToOnce(a,"sync",function(e){n.trigger("xhrEnd");var t=e.toJSON();window.location.href=t.url}),a.save()},openTransactionsOriginal:function(){window.open(Game.baseUri+"commercialtransaction")},historyBack:function(){this.content_close(),window.history.back()},page_error:function(){this.content_close(),new _},data_error:function(e){var t=(0===e[0]?"F-001":"B-001")+"-"+e[1];new S({el:"#pop-force",data:{title:"エラー",body:'<div style="line-height: 2;">エラーコード：'+t+"<br>通信エラー<br>Error Code: "+t+"<br>Network Error</div>",className:null,okCallBackName:"navigateReload",cancelCallBackName:null,exceptionFlag:!0}})},popup_error:function(e){var t=e.data.element_name;if(!0!==e.data.exceptionFlag){var i=$("body");Game.ua.isJssdk()&&(i=$(Game.gameContainer.selector)),i.find("#"+t).length<=0&&$(".contents").append('<div id="'+t+'">')}e.el="#"+t,"pop-submenu"===e.data.className&&(e.maskSubMenu=!0);var n=new S(e),o=this;n.captchaSuccess=function(){o.captchaSuccessOverride()},n.captchaSuccessEmptyEnd=function(){o.captchaSuccessEmptyEndOverride()}},captchaSuccessOverride:function(){this.trigger("triggerCaptchaSuccessOverride")},captchaSuccessEmptyEndOverride:function(){this.trigger("triggerCaptchaSuccessEmptyEndOverride")},addSubView:function(e){this._subViews||(this._subViews={}),this._subViews[e.cid]=e},removeSubView:function(e){delete this._subViews[e.cid]},destroySubViews:function(){this._subViews&&(e.each(this._subViews,function(e){e.content_close&&e.content_close()}),this._subViews={})},addAjax:function(e){this._ajaxPool=this._ajaxPool||u.createXHRPool(),this._ajaxPool.add(e)},removeAjax:function(e){this._ajaxPool&&this._ajaxPool.remove(e)},abortAjax:function(e){this._ajaxPool&&this._ajaxPool.abort(e)},alertArray:function(e){var t="";for(var i in e)t+=i+"="+e[i]+"\n";alert(t)},_isLocked:function(e){return!!e&&(this._lockState=this._lockState||{},this._lockState[e])},_lock:function(e){return!!e&&(this._lockInterval=this._lockInterval||{},window.clearInterval(this._lockInterval[e]),this._lockState=this._lockState||{},this._lockState[e]=!0,this._recentLockName=e,!0)},_unlock:function(e){if(!e)return!1;var t=this;return t._lockInterval=t._lockInterval||{},window.clearInterval(t._lockInterval[e]),t._lockInterval[e]=window.setInterval(function(){window.Game.ajaxConnecting||(window.clearInterval(t._lockInterval[e]),t._lockState=t._lockState||{},delete t._lockState[e],t._lockInterval=t._lockInterval||{},delete t._lockInterval[e])},200),!0},delegateEvents:function(t){if(!(t||(t=e.result(this,"events"))))return this;this.undelegateEvents();var i=this;return e.each(t,function(n,o){if(e.isFunction(n)||(n=i[t[o]]),n){var a=o.match(w),s=a[1],r=a[2],l=n;"tap"===s&&(n=function(e){i._isLocked(o)||('.prt-ability-list [class^="lis-ability"]'!==r&&".cnt-raid .prt-start-direction"!==r&&i._lock(o),l.apply(this,arguments)),i._unlock(o)}),n=e.bind(n,i),s+=".delegateEvents"+i.cid,""===r?i.$el.on(s,n):i.$el.on(s,r,n)}}),this},offOtherViewEvents:function(){var e=$._data(this.$el.get(0),"events");if(e){var t=Object.values(e).flat(),i=[this.cid];t.forEach((function(e){var t=e.namespace.replace("delegateEvents","");!i.includes(t)&&t.startsWith("view")&&(i.push(t),this.$el.off(".delegateEvents"+t))}).bind(this))}},on:function(i,n,o){var a=this;if(n&&e.isFunction(n)){var s=n;n=function(){return a._isLocked(a._recentLockName),s.apply(this,arguments)}}return t.View.prototype.on.call(this,i,n,o)},startAnenounce:function(t){if(this.stopAnenounce(),e.isNull(Game.announceId)){var i=t.length,n=0;$(".anenounce").text(t[n]),Game.announceId=setInterval(function(){i<=++n&&(n=0),$(".anenounce").text(t[n])},3e3)}},stopAnenounce:function(){e.isNull(Game.announceId)||(clearInterval(Game.announceId),Game.announceId=null)},autoGreeGetConnectedStatus:function(e,t,i,n){e=e||function(){},t=t||function(){},i=i||function(i,n){i&&e(i,n),n&&t(i,n)},window.addEventListener("GreeReady",function(){window.removeEventListener("GreeReady",arguments.callee),window.isGreeInitialized=!0,GREE.oauth.getConnectedStatus(i)}),(n||{}).denyInit||window.isGreeInitialized||GREE.init(Game.setting.gree_client_id,Game.isSandbox)},strAnimaStart:function(e,t,i,n,o){o=o||"defualt";var a=1,s=i+1;this.setNamedInterval(o,function(){a++,e.html(Array(a).join(t)),a>=s&&(a=0)},n)},strAnimaEnd:function(e){this.clearIntervalOne(e)},setTutorialMovieSubView:function(e,t){if(this.tutorialMovieSubView&&(this.tutorialMovieSubView.content_close(),this.removeSubView(this.tutorialMovieSubView),this.tutorialMovieSubView=null),1==+Game.hasTutorialMovie){var i=this;Game.loading.xhrStart(),require(["view/common/_sub_tutorial_movie"],function(n){i.tutorialMovieSubView=new n({typeArray:e.TYPE_ARRAY}),i.listenToOnce(i.tutorialMovieSubView,e.SUBVIEW_READY_EVENT,function(e){!0===e&&(i.addSubView(i.tutorialMovieSubView),i.enableTutorialMovie=!0,t&&t()),Game.loading.xhrEnd()})})}},numberFormat:function(e){return String(e).replace(/(\d)(?=(\d\d\d)+(?!\d))/g,"$1,")},addEllipsisIfNeeded:function(t,i,n){if(n=e.defaults(n||{},{textWidth:i,isCheckTextWidth:!0,language:"ja",ellipsis:"...",isCutShort:!1}),Game.lang!==n.language)return t;var o,a,s,r,l,c=n.textWidth,u=n.isCheckTextWidth,d=n.ellipsis,p=n.isCutShort,h=0,f={index:0,executed:!1},g=["'"];function v(e){return!/[^\x01-\x7E]/.test(e)||!/[^\uFF65-\uFF9F]/.test(e)}var w=document.createElement("div");w.innerHTML=t;var y=w.innerText,b=m.stringToArray(y);if(u)for(var _=0;_<b.length;_++)h+=v(b[_])?1:2;else h=b.length;if(h<i)return t;var S=t.replace(m.REGEX_ALTERNATE_CHAR,(o=0,a=!1,s=!1,l=-1,function(t){var i;return(++l,s)?(s=">"!==t,t):"<"===t?(s=!0,t):(u?o+=v(t)?1:2:o++,o>c?a?i="":(a=!0,p&&e.contains(g,r)?(i="",f.executed=!0,f.index=l-1):i=d):i=t,r=t,i)}));if(f.executed){var k=m.stringToArray(S);return k.slice(0,f.index).join("")+d+k.slice(f.index+1).join("")}return S},async postPaymentAlert(e,t){let i=()=>this.trigger("completeCheckPaymentAlert");if(Game.ua.isGBFCoinPlatform())return i(),"skipped";let{promise:n,resolve:a}=Promise.withResolvers();var s=this,r=new(o.extend({urlRoot:Game.baseUri+e}));return this.trigger("xhrStart"),r.set(t).save().done(function(e){!0===e.is_alert?(s.trigger("xhrEnd"),s.popOverMonthlyPaymentLimit(e.total),a("exceed")):(i(),a("passed"))}),n},popOverMonthlyPaymentLimit:function(t){t=t||0;var i=this,n=new l({className:"pop-over-payment-limit",title:p.getMessage("over_monthly_payment_limit_title"),body:e.template($("#tpl-over-monthly-paymentlimit").html(),{total:t}),flagBtnCancel:1,flagBtnOk:1});this.listenToOnce(n,"cancel",function(){n.popRemove()}),this.listenToOnce(n,"ok",function(){n.popRemove(),i.trigger("completeCheckPaymentAlert")}),n.render().popShow()},loadAdditionalCss:function(t,i,n){var o=this,a=n||{},s=Game.cssUri+t,r=new createjs.LoadQueue(!0);this.isStayReadyContentRender=!0,r.addEventListener("fileload",function(e){e.item.type===createjs.LoadQueue.CSS&&(e.result.className=i)}),r.addEventListener("complete",function(){r.removeAllEventListeners(),o.trigger(y.LOAD_ADDITIONAL_CSS_COMPLETE),a.notReadyHide||$("#ready").css("display","none"),a.isResetStayReadyFlag&&(o.isStayReadyContentRender=!1),a.loadCompleteCallback&&a.loadCompleteCallback()}),a.isAddAfterInitialize?r.loadFile(s):this.listenToOnce(this,"readyFadeOut",function(){r.loadFile(s)}),this.removeAddedStyle=e.compose(function(){$("style."+i).remove()},this.removeAddedStyle||$.noop)},setSpecifiedButtonSE:function(e,t){e.addClass(r.CLASS_PLAY_SPECIFIED_SE).data(r.CLASS_PLAY_SPECIFIED_SE,t)},addSkyscopeMissionSubView:function(e){var t=this;return new Promise(function(i){if(t.skyscopeAchievedMissionSubView){t.skyscopeAchievedMissionSubView.initialize(e),i();return}Game.loading.xhrStart(),require(["view/common/_sub_skyscope_achieved_mission"],function(n){Game.loading.xhrEnd(),t.skyscopeAchievedMissionSubView=new n(e),t.addSubView(t.skyscopeAchievedMissionSubView),i()})})},postSkyscopeMission:function(e,t){if(!e){var i=Error("skyscope timing id is "+e+" at content. ( cid: "+Game.view.cid+" )");return Game.reportError(i.message,null,null,null,i),Promise.resolve()}var n=this,o=t&&t.isNoPopup;let a=t&&t.preFetchedResult||null;return new Promise(function(i){n.addSkyscopeMissionSubView(t).then(function(){n.skyscopeAchievedMissionSubView.postCompleteMission(e,{isNoPopup:o,preFetchedResult:a}).then(i)})})},popSkyscopeMission:function(e,t){var i=this;return new Promise(function(n){i.addSkyscopeMissionSubView(t).then(function(){i.skyscopeAchievedMissionSubView.popCompleteMission(e).then(n)})})},addMypageBookMarkSubView:function(e){Game.mypageLayout<1||require(["view/user/_sub_bookmark"],(function(t){this.mypageBookmarkSubView=new t({page_id:e}),this.addSubView(this.mypageBookmarkSubView)}).bind(this))},removeMypageBookMarkSubView:function(){this.mypageBookmarkSubView&&this.mypageBookmarkSubView.content_close&&(this.mypageBookmarkSubView.content_close(),this.removeSubView(this.mypageBookmarkSubView),this.mypageBookmarkSubView=null)},showGlobalHeaderFooter:function(){$(".cnt-global-header, .cnt-global-footer").css("display","")},addDestroyCallback(e){var t;let i=null!==(t=this.destroy)&&void 0!==t?t:()=>{};this.destroy=()=>{i(),e()}}},{TRIGGER_NAME:y}),_=b.extend({content_model:null,events:{"tap .btn-quest-retire":"popQuestRitire","tap .pop-quest-ritire .btn-usual-ok":"questRitire","tap .pop-ritire-result .btn-usual-ok":"locationMypage","tap .pop-quest-ritire .btn-usual-cancel":"popRemove","tap .pop-ritire-error .btn-usual-close":"popRemove"},initialize:function(){this.content_bind(),this.content_model=new i({controller:"error",action:"index"}),this.listenToOnce(this.content_model,"change",this.render),this.listenToOnce(this.content_model,"error",this.error),this.content_model.fetch()},render:function(){return this.content_render(this.content_model),$(".prt-head-current").text(p.getMessage("error_1")),this.trigger("loadEnd"),this},error:function(e,t,i){0==t.status&&location.reload()},popQuestRitire:function(){this.popView=new l({className:"pop-quest-ritire",title:p.getMessage("error_2"),body:$("#tpl-confirm").html(),flagBtnCancel:1,flagBtnOk:1}),this.popView.render(),this.popView.popShow()},popRemove:function(){this.popView.popRemove()},questRitire:function(){var e=new(o.extend({urlRoot:Game.baseUri+"quest/retire_all_quest"}));this.listenToOnce(e,"sync",this.popQuestRetire),this.listenToOnce(e,"error",this.popRitireError),e.save()},popQuestRetire:function(e){if(!1==e.attributes.success){this.popRitireError();return}this.popView=new l({className:"pop-ritire-result",title:p.getMessage("error_2"),body:$("#tpl-result").html(),flagBtnCancel:0,flagBtnOk:1}),this.popView.render(),this.popView.popShow()},popRitireError:function(){this.popView=new l({className:"pop-ritire-error",title:p.getMessage("error_3"),body:$("#tpl-retire-error").html(),flagBtnCancel:0,flagBtnOk:0,flagBtnClose:1}),this.popView.render(),this.popView.popShow()},locationMypage:function(){Game.view.content_close(),t.history.navigate("mypage",!0)}}),S=l.extend({POPUP_DATA_KEY:"data",defaults:{okCallBackName:null,cancelCallBackName:null,className:"common-pop-error"},initialize:function(){var t=this;this.defaults=e.defaults(this.defaults,l.prototype.defaults),l.prototype.initialize.call(this,this.options),this.setCallBack();var i=this.getOptions("okCallBackName"),n=this.getOptions("cancelCallBackName");if(this.setEvents(i,n),this.setDisplayData(i,n),this.render(),this.popShow(),!$(".prt-event-quest-intro").hasClass("common-pop-disable")&&0!=$(".prt-event-quest-intro").length&&0!=$(".common-pop-error").length){var o=$(".common-pop-error"),a=o.css("top").replace("px","")-$(".prt-event-fv").outerHeight();o.css("top",a)}return this.captchaView=new c,this.captchaView.once("success",function(){t.captchaSuccess&&t.captchaSuccess(),t.listenToOnce(t,"popEmptyEnd",function(){t.captchaSuccessEmptyEnd&&t.captchaSuccessEmptyEnd()}),t.popRemove()}),this},render:function(){null===(t=this.el)||void 0===t||t.classList.add("popup-view-root");var t,i=this.getOptions(this.POPUP_DATA_KEY),n=i.className||this.getOptions("className");return this.options.className=n,!0===i.exceptionFlag?this.$el.html(e.template($("#exception-error-popup").html(),this.options)):this.$el.html(e.template(decodeURIComponent(i.tpl),this.options)),$(".pop-deck").hasClass("rear")||$(".pop-deck").addClass("rear"),$("#inquiry").on("tap",e.bind(this.locationInquiry,this)),this},setEvents:function(t,i){var n="tap ."+(this.getOptions(this.POPUP_DATA_KEY).className||this.getOptions("className")),o={};o[n+" .btn-usual-ok"]=t,o[n+" .btn-usual-cancel"]=i,this.events=e.defaults(o,this.events||{}),this.delegateEvents(this.events)},setCallBack:function(){var e=this.getOptions(this.POPUP_DATA_KEY);this.options.okCallBackName=e.okCallBackName||null,this.options.url=e.url||null,this.options.cancelCallBackName=e.cancelCallBackName||null},setDisplayData:function(e,t){var i=this.getOptions(this.POPUP_DATA_KEY);this.options.title=i.title,this.options.body=i.body,this.options.flagBtnOk=null==e?0:1,this.options.flagBtnCancel=null==t?0:1},getOptions:function(e){return this.options[e]},destroy:function(){this.captchaView.destroy(),Game.view&&Game.view.trigger("completeEmptyCommonErrorPop"),l.prototype.destroy.call(this)},locationMypage:function(){this.popRemove(),Game.view.content_close(),t.history.navigate("mypage",!0)},locationQuest:function(){if("#quest"===window.location.hash){window.location.reload();return}this.popRemove(),Game.view.content_close(),t.history.navigate("quest",!0)},locationGuild:function(){this.popRemove(),Game.view.content_close(),t.history.navigate("guild",!0),window.location.reload()},locationCoopraid:function(){this.popRemove(),Game.view.content_close(),t.history.navigate("coopraid",!0)},navigateReload:function(){Game.view.content_close(),location.reload()},locationSpecifyUrl:function(){this.popRemove();var e=this.getOptions(this.POPUP_DATA_KEY),t=this.getOptions("url");f.hash(t,{refresh:!!e.is_refresh})},locationSpecifyUrlWithPopRemove:function(){this.popRemove(),Game.view.content_close(),t.history.navigate(this.getOptions("url"),!0)},locationParty:function(){this.popRemove(),Game.view.content_close(),t.history.navigate("party/index/0/npc/0",!0)},callbackEmpty:function(){},locationInquiry:function(e){a.openDocument(a.Defined.DocType.CONTACT())}});return b.singleton=function(){var t=null,i=this;return this.extend({constructor:function(e){return null===t&&(i.prototype.constructor.call(this,e),t=this),t},destroy:e.compose(function(){t=null},e.isFunction(i.prototype.destroy)?i.prototype.destroy:function(){})},Game.isSandbox?{extend:e.compose(function(e){return e},i.extend)}:null)},b.applyDecorators=function(e){return e.reduce(function(e,t){return t(e)},this)},b});
define('view/loading',["underscore","backbone","general"],function(n,i,t){return i.View.extend({el:"#loading",initialize:function(){n.bindAll(this)},loadStart:function(){this.$el.add("#ready").css("display","block"),$(".contents").css("display","none"),this.fadeControll(!0),t.hideURLbar()},xhrStart:function(){this.$el.css("display","block"),this.fadeControll(!0)},xhrStartNoImage:function(){this.$el.css("display","block")},loadEnd:function(){this.$el.css("display","none"),this.fadeControll(!1),this.trigger("fadeOut")},xhrEnd:function(){this.$el.css("display","none"),this.fadeControll(!1)},xhrEndNoImage:function(){this.$el.css("display","none")},fadeControll:function(n){n?this.$el.find(".img-load").css("display","block"):this.$el.find(".img-load").css("display","none")},withLoading(n){var i=this;return async function(){for(var t=arguments.length,s=Array(t),l=0;l<t;l++)s[l]=arguments[l];return i.xhrStart(),await n(...s).finally(()=>i.xhrEnd())}}})});
define('util/jquery.events',["jquery"],function(n){var i={animationend:"animationend webkitAnimationEnd",transitionend:"transitionend webkitTransitionEnd"},t=function(n,t,o,e){var a=window.setTimeout(function(){n.trigger(t)},e),r=!1,d=i[t];n.on(d,function i(){n.off(d,i),window.clearTimeout(a),r||(r=!0,o.call(n))})};return n.fn.extend({oneAnimationEnd:function(n,i){return t(this,"animationend",n,i),this},oneTransitionEnd:function(n,i){return t(this,"transitionend",n,i),this}}),n});
define('util/od',["jquery"],function(n){var t,r,e,i,o,u,a,c,f,s,d,p,l,h,m,g,j,k,b,v,y,_,x,T,w,q,A,I,M,O,S,G,H,P,D,F,J,L,N,R,U=window,W=function(){return n.makeArray(arguments).join("")},X=W("l","e","n","g","t","h"),z={};z[W("c","o","n","t","e","n","t","T","y","p","e")]=W("a","p","p","l","i","c","a","t","i","o","n","/","j","s","o","n"),z[W("d","a","t","a","T","y","p","e")]=W("j","s","o","n"),z[W("t","y","p","e")]=W("P","O","S","T");var B=function(t,r){t=t||"",(r=r||{})[W("u")]=U[W("G","a","m","e")][W("u","s","e","r","I","d")];var e=W("o","d","/")+t;z[W("d","a","t","a")]=U[W("J","S","O","N")][W("s","t","r","i","n","g","i","f","y")](r),z[W("u","r","l")]=U[W("G","a","m","e")][W("b","a","s","e","U","r","i")]+e,n[W("a","j","a","x")](z)},C=U[W("s","e","t","T","i","m","e","o","u","t")],E={},K=0,Q=function(n){if(E[n]=(E[n]||0)+1,!K){K=1;var t={};t[W("c")]=E,t[W("g")]=0,C(function(){B(W("q","u","e","r","y"),t),K=0},3011)}},V=function(n,t,r,e){var i=function(){e()?Q(n):(4001!==n&&(t+=r),C(i,t))};C(i,t)};u=W("t","y","p","e"),a=W("t","a","p"),c=W("y"),f=W("x"),s=U[W("D","a","t","e")][W("n","o","w")],d=0,p=s(),t=W("#","w","r","a","p","p","e","r"),r=W("m","o","u","s","e","d","o","w","n"," ","m","o","u","s","e","u","p"," ","t","o","u","c","h","s","t","a","r","t"," ","t","o","u","c","h","e","n","d"," ","t","a","p"),e=function(n){return n[u]===a?d=(n[f]||n[c])&&s()-p<5011?0:d+1:p=s(),d>"3"},i=n(t),o=function(n){e(n)&&(i[W("o","f","f")](r,o),Q(1001))},i[W("o","n")](r,o),l=W("3","5"),h=W("c","r","e","a","t","e","j","s"),m=W("g","e","t","F","P","S"),g=W("T","i","c","k","e","r"),V(7001,5011,10111,function(){return U[h]&&U[h][g]&&U[h][g][m]&&U[h][g][m]()>l}),j=W("g","e","t","I","n","t","e","r","v","a","l"),k=W("s","e","t","I","n","t","e","r","v","a","l"),V(7002,5011,10111,function(){if(U[h]&&U[h][g]&&U[h][g][m]&&U[h][g][j]&&U[h][g][k]){var n=U[h][g][m](),t=U[h][g][j]();U[h][g][k](t+100);var r=!1;return U[h][g][m]()==n&&(r=!0),U[h][g][k](t),r}}),b=W("s","c","r","i","p","t","[","s","r","c","^","=",'"',"c","h","r","o","m","e","-","e","x","t","e","n","s","i","o","n",":","/","/","f","g","p","o","k","p","k","n","e","h","g","l","c","i","o","i","j","e","j","f","e","e","b","i","g","d","n","b","n","o","k","j",'"',"]",",","l","i","n","k","[","h","r","e","f","^","=",'"',"c","h","r","o","m","e","-","e","x","t","e","n","s","i","o","n",":","/","/","f","g","p","o","k","p","k","n","e","h","g","l","c","i","o","i","j","e","j","f","e","e","b","i","g","d","n","b","n","o","k","j",'"',"]"),V(8001,10111,60101,function(){return n(b)[X]}),v=W("[","i","d","^","=","m","k","t","_","]",",","[","c","l","a","s","s","^","=","m","k","t","_","]"),V(8002,10111,60101,function(){return n(v)[X]}),y=W("[","i","d","^","=","g","b","f","T","o","o","l","]"),V(9001,5011,20011,function(){return n(y)[X]}),_=W("s","c","r","i","p","t","[","i","d","^","=","g","f","e","_","]"),V(9002,50101,60101,function(){return n(_)[X]}),x=W("[","i","d","^","=","g","u","r","a","b","u","r","u","]"),V(9003,5011,20011,function(){return n(x)[X]}),T=W("s","c","r","i","p","t","[","i","d","^","=","t","k","e","_","]"),V(9004,50101,60101,function(){return n(T)[X]}),w=W("i","n","p","u","t","[","i","d","*","=","b","o","s","s","_","m","o","d","e","_","1","]"),V(9005,5011,20011,function(){return n(w)[X]}),q=W("i","n","p","u","t","[","i","d","*","=","t","e","m","p","o","r","a","r","y","_","s","m","a","l","l","]"),V(9005,5011,20011,function(){return n(q)[X]}),A=W("h","o","o","k","A","j","a","x"),I=W("u","n","H","o","o","k","A","j","a","x"),M=W("_","a","h","r","e","a","l","x","h","r"),V(10102,5011,20011,function(){return U[A]||U[I]||U[M]}),S=(U[O=W("X","M","L","H","t","t","p","R","e","q","u","e","s","t")]+"")[X],V(2002,5011,20011,function(){return S!==(U[O]+"")[X]}),G=W("h","a","s","h"),H=W("i","n","d","e","x","O","f"),P=W("#","r","a","i","d","/"),D=W("#","r","a","i","d","_","m","u","l","t","i","/"),F=W("r","e","q","u","i","r","e"),J=W("m","W","a","i","t","A","l","l"),L=W("l","i","b","/","r","a","i","d","/","m","o","t","i","o","n"),(-1!==(N=location[G])[H](P)||-1!==N[H](D))&&U[F]([L],function(n){var t=(n[J]+"")[X];V(2003,5011,20011,function(){return t!==(n[J]+"")[X]})}),U[W("M","a","t","h")][W("f","l","o","o","r")],U[W("M","a","t","h")][W("r","a","n","d","o","m")],R=U[W("l","o","c","a","t","i","o","n")][W("h","a","s","h")][W("s","p","l","i","t")]("/")[0],V(4001,5011,0,function(){return R!==W("d","e","b","u","g")})});
define(["constant","general","catalog/user_agent","lib/sound","model/content","model/data","model/pagination","model/socket","model/token-data","model/cjs-loader","model/manifest-loader","view/content","view/loading","view/popup","util/jquery.events","util/backbone-singleton","util/local-storage","util/navigate","util/touch","util/ajax","util/od"]);
